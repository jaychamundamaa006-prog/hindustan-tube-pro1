"use client";

import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";

export default function SplashPage() {
  const router = useRouter();
  const [progress, setProgress] = useState(8);

  useEffect(() => {
    const tick = setInterval(() => setProgress((p) => Math.min(100, p + 9)), 90);
    const timer = setTimeout(() => {
      let seen = false;
      try {
        seen = localStorage.getItem("htp-onboarded") === "1";
      } catch {
        seen = false;
      }
      router.replace(seen ? "/home" : "/onboarding");
    }, 1300);
    return () => {
      clearInterval(tick);
      clearTimeout(timer);
    };
  }, [router]);

  return (
    <div className="relative grid min-h-dvh place-items-center overflow-hidden bg-[#0F1115] text-white">
      <div className="absolute -left-24 -top-24 h-72 w-72 rounded-full bg-brand/25 blur-3xl" />
      <div className="absolute -bottom-24 -right-24 h-80 w-80 rounded-full bg-secondary/20 blur-3xl" />
      <div className="fade-up relative flex flex-col items-center gap-6">
        <div className="pop">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src="/logo.png"
            alt="Hindustan Tube Pro"
            width={128}
            height={128}
            className="h-28 w-28 rounded-[1.6rem] object-cover shadow-[0_20px_60px_rgba(0,0,0,0.6)] ring-1 ring-white/10"
          />
        </div>
        <div className="text-center">
          <p className="text-[22px] font-bold tracking-tight text-white">
            HINDUSTAN <span className="text-white/90">TUBE</span>{" "}
            <span className="rounded bg-[#FF3B30] px-1.5 py-0.5 text-sm font-black text-white">PRO</span>
          </p>
          <p className="mt-1 text-sm text-white/60">Watch. Create. Earn.</p>
        </div>
        <div className="h-1 w-44 overflow-hidden rounded-full bg-white/10">
          <div
            className="h-full rounded-full bg-gradient-to-r from-brand to-accent transition-all duration-150"
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>
      <p className="absolute bottom-8 text-[11px] text-white/35">Made in India · v1.0.0</p>
    </div>
  );
}
