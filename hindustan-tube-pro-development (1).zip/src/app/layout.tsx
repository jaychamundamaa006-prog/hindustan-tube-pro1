import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Hindustan Tube Pro — Watch. Create. Earn.",
  description:
    "Hindustan Tube Pro is a premium video sharing platform for long-form videos and vertical shorts, with a full creator studio and admin console.",
  applicationName: "Hindustan Tube Pro",
  icons: {
    icon: [
      { url: "/logo.png", sizes: "512x512", type: "image/png" },
      { url: "/favicon.ico", sizes: "any" },
    ],
    apple: [{ url: "/apple-touch-icon.png", sizes: "180x180", type: "image/png" }],
    shortcut: "/logo.png",
  },
  manifest: "/manifest.webmanifest",
  appleWebApp: {
    capable: true,
    title: "Hindustan Tube Pro",
    statusBarStyle: "black-translucent",
  },
  openGraph: {
    title: "Hindustan Tube Pro",
    description:
      "Watch. Create. Earn. — India's premium video platform for long videos and vertical shorts.",
    siteName: "Hindustan Tube Pro",
    images: [{ url: "/logo.png", width: 512, height: 512, alt: "Hindustan Tube Pro Logo" }],
    type: "website",
    locale: "en_IN",
  },
  twitter: {
    card: "summary",
    title: "Hindustan Tube Pro",
    description: "Watch. Create. Earn.",
    images: ["/logo.png"],
  },
};

export const viewport: Viewport = {
  themeColor: [
    { media: "(prefers-color-scheme: dark)", color: "#0F1115" },
    { media: "(prefers-color-scheme: light)", color: "#FFFFFF" },
  ],
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
};

const themeScript = `(function(){try{var t=localStorage.getItem('htp-theme');if(!t){t=window.matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light';}if(t==='dark'){document.documentElement.classList.add('dark');}}catch(e){document.documentElement.classList.add('dark');}})();`;

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap"
          rel="stylesheet"
        />
        <script dangerouslySetInnerHTML={{ __html: themeScript }} />
      </head>
      <body className="antialiased">{children}</body>
    </html>
  );
}
