"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import Icon from "@/components/Icon";
import { Button } from "@/components/ui";
import { Logo } from "@/components/AppChrome";

const SLIDES = [
  {
    icon: "video",
    title: "Endless video, zero clutter",
    body: "A clean feed tuned to what you love — trending long-form, music, gaming, tech and more.",
    tint: "from-brand/30 to-transparent",
  },
  {
    icon: "shorts",
    title: "Shorts that fly by",
    body: "Full-screen 9:16 shorts with buttery vertical swipes, likes, comments and instant follows.",
    tint: "from-secondary/30 to-transparent",
  },
  {
    icon: "money",
    title: "Create and get paid",
    body: "Creator Studio analytics, audience insights and a transparent, fully configurable payout system.",
    tint: "from-accent/30 to-transparent",
  },
];

export default function OnboardingPage() {
  const [index, setIndex] = useState(0);
  const router = useRouter();
  const slide = SLIDES[index];

  function finish(target: string) {
    try {
      localStorage.setItem("htp-onboarded", "1");
    } catch {
      /* ignore */
    }
    router.replace(target);
  }

  return (
    <div className="flex min-h-dvh flex-col bg-bg px-6 py-8">
      <div className="flex items-center justify-between">
        <Logo />
        <button onClick={() => finish("/home")} className="text-sm font-medium text-muted">
          Skip
        </button>
      </div>

      <div key={index} className="fade-up flex flex-1 flex-col items-center justify-center text-center">
        <div className={`mb-8 grid h-40 w-40 place-items-center rounded-[2rem] bg-gradient-to-br ${slide.tint} ring-1 ring-line`}>
          <Icon name={slide.icon} size={64} className="text-brand" />
        </div>
        <h1 className="max-w-sm text-2xl font-bold leading-tight">{slide.title}</h1>
        <p className="mt-3 max-w-sm text-sm leading-relaxed text-muted">{slide.body}</p>
      </div>

      <div className="mb-6 flex justify-center gap-2">
        {SLIDES.map((_, i) => (
          <span
            key={i}
            className={`h-1.5 rounded-full transition-all ${i === index ? "w-6 bg-brand" : "w-1.5 bg-line"}`}
          />
        ))}
      </div>

      <div className="space-y-3">
        {index < SLIDES.length - 1 ? (
          <Button full size="lg" onClick={() => setIndex(index + 1)}>
            Continue <Icon name="chevronRight" size={18} />
          </Button>
        ) : (
          <Button full size="lg" onClick={() => finish("/signup")}>
            Create your account
          </Button>
        )}
        <Button full size="lg" variant="outline" onClick={() => finish("/home")}>
          Browse as guest
        </Button>
        <p className="pt-1 text-center text-xs text-muted">
          Already have an account?{" "}
          <button onClick={() => finish("/login")} className="font-semibold text-brand">
            Sign in
          </button>
        </p>
      </div>
    </div>
  );
}
