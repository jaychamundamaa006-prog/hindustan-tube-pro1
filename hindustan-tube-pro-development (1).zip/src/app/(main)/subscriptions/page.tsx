import Link from "next/link";
import { getCurrentUser } from "@/lib/auth";
import { getSubscribedChannels, getSubscriptionFeed, listVideos } from "@/lib/queries";
import VideoCard from "@/components/VideoCard";
import { Avatar, Button, StateView } from "@/components/ui";
import Icon from "@/components/Icon";
import { compactNumber } from "@/lib/format";

export const dynamic = "force-dynamic";

export default async function SubscriptionsPage() {
  const user = await getCurrentUser();

  if (!user) {
    const trending = await listVideos({ sort: "views", limit: 6 });
    return (
      <div>
        <StateView
          icon="subs"
          title="Sign in to see subscriptions"
          message="Follow creators and never miss an upload."
          action={
            <Link href="/login">
              <Button>Sign in</Button>
            </Link>
          }
        />
        <h2 className="px-3 text-sm font-bold">Trending right now</h2>
        <div className="grid grid-cols-1 gap-6 p-3 sm:grid-cols-2 lg:grid-cols-3">
          {trending.map((v) => (
            <VideoCard key={v.id} video={v} />
          ))}
        </div>
      </div>
    );
  }

  const [channels, feed] = await Promise.all([
    getSubscribedChannels(user.id),
    getSubscriptionFeed(user.id, 24),
  ]);

  const shorts = feed.filter((v) => v.isShort);
  const longform = feed.filter((v) => !v.isShort);

  return (
    <div className="pb-6">
      <div className="no-scrollbar flex gap-4 overflow-x-auto border-b border-line px-3 py-4">
        {channels.length === 0 ? (
          <p className="text-xs text-muted">You haven&apos;t subscribed to any channel yet.</p>
        ) : (
          channels.map((c) => (
            <Link key={c.id} href={`/channel/${c.handle}`} className="flex w-16 shrink-0 flex-col items-center gap-1">
              <Avatar src={c.avatarUrl} name={c.name} size={54} ring={c.notify} />
              <span className="w-full truncate text-center text-[10px] font-medium">{c.name}</span>
              <span className="text-[9px] text-muted">{compactNumber(c.subscriberCount)}</span>
            </Link>
          ))
        )}
      </div>

      {shorts.length > 0 && (
        <div className="border-b border-line py-4">
          <h2 className="mb-2 flex items-center gap-2 px-3 text-sm font-bold">
            <Icon name="shorts" size={16} className="text-brand" /> New shorts
          </h2>
          <div className="no-scrollbar flex gap-3 overflow-x-auto px-3">
            {shorts.map((s) => (
              <Link key={s.id} href={`/shorts?v=${s.id}`} className="w-28 shrink-0">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={s.thumbnailUrl} alt={s.title} className="aspect-[9/16] w-full rounded-xl object-cover" />
                <p className="mt-1 line-clamp-2x text-[11px] font-medium">{s.title}</p>
              </Link>
            ))}
          </div>
        </div>
      )}

      {longform.length === 0 ? (
        <StateView
          icon="video"
          title="No new uploads"
          message="Videos from channels you subscribe to will appear here."
          action={
            <Link href="/home">
              <Button variant="outline">Discover creators</Button>
            </Link>
          }
        />
      ) : (
        <div className="grid grid-cols-1 gap-6 p-3 sm:grid-cols-2 lg:grid-cols-3">
          {longform.map((v) => (
            <VideoCard key={v.id} video={v} />
          ))}
        </div>
      )}
    </div>
  );
}
