"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import Icon from "@/components/Icon";
import { Button, Skeleton, StateView } from "@/components/ui";
import { timeAgo } from "@/lib/format";

type Item = {
  id: number;
  type: string;
  title: string;
  body: string;
  link: string | null;
  thumbnailUrl: string | null;
  read: boolean;
  createdAt: string;
};

const ICONS: Record<string, string> = {
  subscriber: "users",
  like: "like",
  comment: "comment",
  reply: "comment",
  upload: "video",
  system: "sparkle",
};

export default function NotificationsPage() {
  const [items, setItems] = useState<Item[]>([]);
  const [status, setStatus] = useState<"loading" | "ready" | "error" | "guest">("loading");

  async function load() {
    setStatus("loading");
    try {
      const res = await fetch("/api/notifications");
      if (res.status === 401) return setStatus("guest");
      if (!res.ok) throw new Error();
      const data = await res.json();
      setItems(data.notifications ?? []);
      setStatus("ready");
    } catch {
      setStatus("error");
    }
  }

  useEffect(() => {
    void load();
  }, []);

  async function markAll() {
    setItems((prev) => prev.map((i) => ({ ...i, read: true })));
    await fetch("/api/notifications", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "all" }),
    });
  }

  async function markOne(id: number) {
    setItems((prev) => prev.map((i) => (i.id === id ? { ...i, read: true } : i)));
    await fetch("/api/notifications", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id }),
    });
  }

  async function remove(id: number) {
    setItems((prev) => prev.filter((i) => i.id !== id));
    await fetch(`/api/notifications?id=${id}`, { method: "DELETE" });
  }

  return (
    <div className="pb-6">
      <div className="flex items-center justify-between border-b border-line px-3 py-3">
        <h1 className="text-lg font-bold">Notifications</h1>
        {items.some((i) => !i.read) && (
          <button onClick={markAll} className="text-xs font-semibold text-brand">
            Mark all as read
          </button>
        )}
      </div>

      {status === "loading" && (
        <div className="space-y-3 p-3">
          {Array.from({ length: 5 }).map((_, i) => (
            <div key={i} className="flex gap-3">
              <Skeleton className="h-10 w-10 rounded-full" />
              <div className="flex-1 space-y-2">
                <Skeleton className="h-3 w-2/3" />
                <Skeleton className="h-3 w-1/3" />
              </div>
            </div>
          ))}
        </div>
      )}

      {status === "guest" && (
        <StateView
          icon="bell"
          title="Sign in for notifications"
          message="Get alerts for new uploads, comments, likes and subscribers."
          action={
            <Link href="/login">
              <Button>Sign in</Button>
            </Link>
          }
        />
      )}

      {status === "error" && (
        <StateView
          tone="error"
          icon="wifi"
          title="Couldn't load notifications"
          action={<Button onClick={load}>Retry</Button>}
        />
      )}

      {status === "ready" && items.length === 0 && (
        <StateView icon="bell" title="You're all caught up" message="New activity will show up here." />
      )}

      <ul className="divide-y divide-line/60">
        {items.map((n) => (
          <li key={n.id} className={`flex items-start gap-3 px-3 py-3 ${n.read ? "" : "bg-brand/5"}`}>
            <span className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-surface2 text-brand">
              <Icon name={ICONS[n.type] ?? "info"} size={18} />
            </span>
            <Link href={n.link ?? "#"} onClick={() => markOne(n.id)} className="min-w-0 flex-1">
              <p className="text-[13px] font-semibold leading-snug">{n.title}</p>
              {n.body && <p className="line-clamp-2x text-xs text-muted">{n.body}</p>}
              <p className="mt-0.5 text-[11px] text-muted">{timeAgo(n.createdAt)}</p>
            </Link>
            {n.thumbnailUrl && (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={n.thumbnailUrl} alt="" className="h-12 w-20 rounded-lg object-cover" />
            )}
            <button onClick={() => remove(n.id)} className="text-muted hover:text-danger">
              <Icon name="close" size={16} />
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}
