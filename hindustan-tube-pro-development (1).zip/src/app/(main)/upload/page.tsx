"use client";

import { useRef, useState } from "react";
import { useRouter } from "next/navigation";
import Icon from "@/components/Icon";
import { Button, StateView, Toggle } from "@/components/ui";
import { CATEGORIES } from "@/lib/constants";

const inputCls =
  "w-full rounded-2xl border border-line bg-surface px-4 py-3 text-sm outline-none transition-colors focus:border-brand";

type Phase = "idle" | "uploading" | "processing" | "done" | "error";

export default function UploadPage() {
  const router = useRouter();
  const videoInput = useRef<HTMLInputElement | null>(null);
  const thumbInput = useRef<HTMLInputElement | null>(null);
  const xhrRef = useRef<XMLHttpRequest | null>(null);

  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState("");
  const [videoUrl, setVideoUrl] = useState("");
  const [thumbUrl, setThumbUrl] = useState("");
  const [durationSec, setDurationSec] = useState(0);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState("trending");
  const [tags, setTags] = useState("");
  const [visibility, setVisibility] = useState("public");
  const [isShort, setIsShort] = useState(false);
  const [audioTitle, setAudioTitle] = useState("");
  const [progress, setProgress] = useState(0);
  const [phase, setPhase] = useState<Phase>("idle");
  const [error, setError] = useState("");

  function pickVideo(f: File | null) {
    if (!f) return;
    if (!f.type.startsWith("video/")) {
      setError("Please choose a video file (MP4, WEBM or MOV).");
      return;
    }
    if (f.size > 60 * 1024 * 1024) {
      setError("Video exceeds the 60 MB limit for this build.");
      return;
    }
    setError("");
    setFile(f);
    setVideoUrl("");
    const url = URL.createObjectURL(f);
    setPreview(url);
    const probe = document.createElement("video");
    probe.preload = "metadata";
    probe.onloadedmetadata = () => {
      const duration = Math.round(probe.duration || 0);
      const maxDuration = 50 * 60 * 60; // 50 hours in seconds
      if (duration > maxDuration) {
        setError(`Video duration exceeds 50 hours (${Math.round(duration / 3600)} hours). Maximum allowed is 50 hours.`);
        setFile(null);
        return;
      }
      setDurationSec(duration);
      setIsShort(duration > 0 && duration <= 90 && probe.videoHeight >= probe.videoWidth);
    };
    probe.src = url;
    if (!title) setTitle(f.name.replace(/\.[^.]+$/, "").slice(0, 100));
  }

  function uploadFile(target: File, onDone: (url: string) => void) {
    return new Promise<void>((resolve, reject) => {
      const form = new FormData();
      form.append("file", target);
      const xhr = new XMLHttpRequest();
      xhrRef.current = xhr;
      xhr.open("POST", "/api/media");
      xhr.upload.onprogress = (e) => {
        if (e.lengthComputable) setProgress(Math.round((e.loaded / e.total) * 92));
      };
      xhr.onload = () => {
        try {
          const data = JSON.parse(xhr.responseText);
          if (xhr.status >= 200 && xhr.status < 300) {
            onDone(data.url);
            resolve();
          } else reject(new Error(data.error ?? "Upload failed"));
        } catch {
          reject(new Error("Upload failed"));
        }
      };
      xhr.onerror = () => reject(new Error("Network error while uploading"));
      xhr.onabort = () => reject(new Error("Upload cancelled"));
      xhr.send(form);
    });
  }

  async function submit() {
    if (!navigator.onLine) {
      setError("You are offline. Reconnect to publish your video.");
      setPhase("error");
      return;
    }
    if (title.trim().length < 3) {
      setError("Give your video a title of at least 3 characters.");
      return;
    }
    if (!file && !videoUrl.trim()) {
      setError("Select a video file or paste a hosted video URL.");
      return;
    }

    setPhase("uploading");
    setError("");
    setProgress(4);

    try {
      let finalVideoUrl = videoUrl.trim();
      if (file) {
        await uploadFile(file, (url) => {
          finalVideoUrl = url;
        });
      }
      let finalThumb = thumbUrl.trim();
      const thumbFile = thumbInput.current?.files?.[0];
      if (thumbFile) {
        await uploadFile(thumbFile, (url) => {
          finalThumb = url;
        });
      }
      if (!finalThumb) {
        finalThumb = `https://picsum.photos/seed/htp${Date.now()}/1280/720`;
      }

      setPhase("processing");
      setProgress(96);

      const res = await fetch("/api/videos", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title,
          description,
          category,
          tags,
          visibility,
          isShort,
          audioTitle,
          durationSec,
          videoUrl: finalVideoUrl,
          thumbnailUrl: finalThumb,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Publishing failed");
      setProgress(100);
      setPhase("done");
      setTimeout(() => router.push(`/video/${data.video.id}`), 900);
    } catch (e) {
      setPhase("error");
      setError(e instanceof Error ? e.message : "Upload failed");
    }
  }

  if (phase === "done") {
    return (
      <StateView
        icon="check"
        title="Published!"
        message="Your video is live. Redirecting you to the watch page…"
      />
    );
  }

  return (
    <div className="px-3 py-4">
      <h1 className="text-lg font-bold">Upload</h1>
      <p className="text-xs text-muted">Share a long-form video or a vertical short.</p>

      <div className="mt-4 space-y-4">
        <div
          onClick={() => videoInput.current?.click()}
          className="grid cursor-pointer place-items-center gap-2 rounded-2xl border-2 border-dashed border-line bg-surface p-6 text-center transition-colors hover:border-brand"
        >
          {preview ? (
            <div>
              <video src={preview} className="max-h-56 rounded-xl" controls playsInline />
              {durationSec > 0 && (
                <p className="mt-2 text-center text-xs text-muted">
                  Duration: {Math.floor(durationSec / 3600)}h {Math.floor((durationSec % 3600) / 60)}m
                </p>
              )}
            </div>
          ) : (
            <>
              <span className="grid h-14 w-14 place-items-center rounded-2xl bg-brand/10 text-brand">
                <Icon name="upload" size={26} />
              </span>
              <p className="text-sm font-semibold">Select a video</p>
              <p className="text-[11px] text-muted">MP4, WEBM or MOV · up to 60 MB · max 50 hours</p>
            </>
          )}
          <input
            ref={videoInput}
            type="file"
            accept="video/*"
            hidden
            onChange={(e) => pickVideo(e.target.files?.[0] ?? null)}
          />
        </div>

        {!file && (
          <input
            className={inputCls}
            placeholder="…or paste a hosted video URL (.mp4)"
            value={videoUrl}
            onChange={(e) => setVideoUrl(e.target.value)}
          />
        )}

        <div className="flex items-center gap-3">
          <button
            onClick={() => thumbInput.current?.click()}
            className="flex flex-1 items-center gap-2 rounded-2xl border border-line bg-surface px-4 py-3 text-sm"
          >
            <Icon name="video" size={18} className="text-muted" />
            {thumbInput.current?.files?.[0]?.name ?? "Custom thumbnail (optional)"}
          </button>
          <input ref={thumbInput} type="file" accept="image/*" hidden onChange={() => setThumbUrl("")} />
        </div>
        <input
          className={inputCls}
          placeholder="…or thumbnail image URL"
          value={thumbUrl}
          onChange={(e) => setThumbUrl(e.target.value)}
        />

        <input className={inputCls} placeholder="Title" value={title} onChange={(e) => setTitle(e.target.value)} />
        <textarea
          className={inputCls}
          rows={4}
          placeholder="Description"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
        />

        <div className="grid grid-cols-2 gap-3">
          <select className={inputCls} value={category} onChange={(e) => setCategory(e.target.value)}>
            {CATEGORIES.filter((c) => c.slug !== "all" && c.slug !== "shorts").map((c) => (
              <option key={c.slug} value={c.slug}>
                {c.name}
              </option>
            ))}
          </select>
          <select className={inputCls} value={visibility} onChange={(e) => setVisibility(e.target.value)}>
            <option value="public">Public</option>
            <option value="unlisted">Unlisted</option>
            <option value="private">Private</option>
          </select>
        </div>

        <input
          className={inputCls}
          placeholder="Tags (comma separated)"
          value={tags}
          onChange={(e) => setTags(e.target.value)}
        />

        <div className="flex items-center justify-between rounded-2xl bg-surface px-4 py-3">
          <div>
            <p className="text-sm font-semibold">Publish as a Short</p>
            <p className="text-[11px] text-muted">Vertical 9:16, up to 90 seconds</p>
          </div>
          <Toggle checked={isShort} onChange={setIsShort} />
        </div>

        {isShort && (
          <input
            className={inputCls}
            placeholder="Audio / music credit"
            value={audioTitle}
            onChange={(e) => setAudioTitle(e.target.value)}
          />
        )}

        {(phase === "uploading" || phase === "processing") && (
          <div className="rounded-2xl bg-surface p-4">
            <div className="flex items-center justify-between text-xs font-medium">
              <span>{phase === "processing" ? "Processing video…" : `Uploading… ${progress}%`}</span>
              <button
                onClick={() => {
                  xhrRef.current?.abort();
                  setPhase("error");
                  setError("Upload cancelled.");
                }}
                className="text-danger"
              >
                Cancel
              </button>
            </div>
            <div className="mt-2 h-2 overflow-hidden rounded-full bg-surface2">
              <div
                className="h-full rounded-full bg-gradient-to-r from-brand to-accent transition-all"
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>
        )}

        {error && (
          <div className="flex items-center justify-between gap-3 rounded-2xl bg-danger/10 px-4 py-3 text-xs text-danger">
            <span className="flex items-center gap-2">
              <Icon name="info" size={14} /> {error}
            </span>
            {phase === "error" && (
              <button onClick={submit} className="font-bold underline">
                Retry
              </button>
            )}
          </div>
        )}

        <Button full size="lg" onClick={submit} disabled={phase === "uploading" || phase === "processing"}>
          {phase === "uploading" || phase === "processing" ? "Publishing…" : "Publish video"}
        </Button>
      </div>
    </div>
  );
}
