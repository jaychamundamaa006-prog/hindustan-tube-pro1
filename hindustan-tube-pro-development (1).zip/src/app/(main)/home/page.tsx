import VideoFeed from "@/components/VideoFeed";
import ShortsRail from "@/components/ShortsRail";
import { StateView } from "@/components/ui";
import { listVideos } from "@/lib/queries";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  try {
    const [videos, shorts] = await Promise.all([
      listVideos({ limit: 8, sort: "latest" }),
      listVideos({ shorts: true, limit: 10, sort: "views" }),
    ]);

    return <VideoFeed initial={videos} rail={<ShortsRail shorts={shorts} />} />;
  } catch {
    return (
      <StateView
        tone="error"
        icon="wifi"
        title="Feed unavailable"
        message="We couldn't reach the servers. Pull to refresh or try again shortly."
      />
    );
  }
}
