import Link from "next/link";
import Icon from "@/components/Icon";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/db";
import { chatMembers, chats, messages, users } from "@/db/schema";
import { and, eq, isNull, desc } from "drizzle-orm";
import { ChatListItem } from "@/components/ChatListItem";
import { Button, StateView } from "@/components/ui";

export const dynamic = "force-dynamic";

export default async function ChatPage() {
  const user = await getCurrentUser();

  if (!user) {
    return (
      <div className="mx-auto max-w-2xl px-3 py-10">
        <StateView
          icon="chat"
          title="Messages"
          message="Sign in to start messaging with other creators and viewers."
          action={
            <Link href="/login">
              <Button>Sign in</Button>
            </Link>
          }
        />
      </div>
    );
  }

  const chatList = await db
    .select({
      id: chats.id,
      type: chats.type,
      name: chats.name,
      photoUrl: chats.photoUrl,
      lastMessage: messages.body,
      lastMessageTime: chats.lastMessageTime,
      lastSenderName: users.name,
    })
    .from(chats)
    .innerJoin(chatMembers, and(eq(chatMembers.chatId, chats.id), eq(chatMembers.userId, user.id), isNull(chatMembers.leftAt)))
    .leftJoin(messages, eq(messages.id, chats.lastMessageId))
    .leftJoin(users, eq(users.id, messages.senderId))
    .orderBy(desc(chats.lastMessageTime));
  
  const rows = chatList.map(r => ({ ...r, memberCount: 0, unreadCount: 0 }));

  return (
    <div className="mx-auto max-w-2xl">
      <div className="border-b border-line bg-surface p-3 sticky top-14 z-20 sm:p-4">
        <h1 className="text-lg font-bold">Messages</h1>
        <p className="text-xs text-muted">Direct chats and groups</p>
      </div>

      {rows.length === 0 ? (
        <StateView
          icon="chat"
          title="No messages yet"
          message="Start a conversation with another user."
          action={
            <Link href="/home">
              <Button variant="outline">Back to home</Button>
            </Link>
          }
        />
      ) : (
        <div className="divide-y divide-line">
          {rows.map((row) => (
            <ChatListItem
              key={row.id}
              id={row.id}
              type={row.type as "direct" | "group"}
              name={row.name}
              photoUrl={row.photoUrl}
              lastMessage={row.lastMessage}
              lastMessageTime={row.lastMessageTime}
              lastSenderName={row.lastSenderName}
              memberCount={0} // TODO: get actual count
              unreadCount={row.unreadCount}
            />
          ))}
        </div>
      )}
    </div>
  );
}
