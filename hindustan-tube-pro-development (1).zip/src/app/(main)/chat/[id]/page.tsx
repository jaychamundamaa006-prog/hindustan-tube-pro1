import { and, eq, isNull } from "drizzle-orm";
import Link from "next/link";
import { db } from "@/db";
import { chatMembers, chats, messages, users, videos } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import ChatView from "@/components/ChatView";
import { Button, StateView } from "@/components/ui";

export const dynamic = "force-dynamic";

export default async function ChatDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const chatId = Number(id);
  const user = await getCurrentUser();

  if (!user) {
    return (
      <StateView
        icon="lock"
        title="Sign in required"
        message="You need to be signed in to view messages."
        action={
          <Link href="/login">
            <Button>Sign in</Button>
          </Link>
        }
      />
    );
  }

  const member = await db
    .select()
    .from(chatMembers)
    .where(and(eq(chatMembers.chatId, chatId), eq(chatMembers.userId, user.id)))
    .limit(1);

  if (!member[0]) {
    return (
      <StateView
        tone="error"
        icon="lock"
        title="Access denied"
        message="You don't have permission to view this chat."
        action={
          <Link href="/chat">
            <Button variant="outline">Back to messages</Button>
          </Link>
        }
      />
    );
  }

  const chatRow = await db
    .select()
    .from(chats)
    .where(eq(chats.id, chatId))
    .limit(1);

  if (!chatRow[0]) {
    return (
      <StateView
        icon="chat"
        title="Chat not found"
        action={
          <Link href="/chat">
            <Button variant="outline">Back to messages</Button>
          </Link>
        }
      />
    );
  }

  let title = chatRow[0].name || "Chat";
  let subtitle: string | undefined;

  if (chatRow[0].type === "direct") {
    const otherMember = await db
      .select({ id: chatMembers.userId, name: users.name, avatar: users.avatarUrl })
      .from(chatMembers)
      .innerJoin(users, eq(users.id, chatMembers.userId))
      .where(
        and(eq(chatMembers.chatId, chatId), ne(chatMembers.userId, user.id)),
      )
      .limit(1);
    if (otherMember[0]) {
      title = otherMember[0].name || "User";
      subtitle = "Online";
    }
  } else {
    const countRows = await db.select().from(chatMembers).where(and(eq(chatMembers.chatId, chatId), isNull(chatMembers.leftAt)));
    subtitle = `${countRows.length} members`;
  }

    const messageRows = await db
    .select({
      id: messages.id,
      chatId: messages.chatId,
      senderId: messages.senderId,
      senderName: users.name,
      senderAvatar: users.avatarUrl,
      type: messages.type,
      body: messages.body,
      mediaUrl: messages.mediaUrl,
      videoId: messages.videoId,
      videoTitle: videos.title,
      videoThumbnail: videos.thumbnailUrl,
      replyToId: messages.replyToId,
      deletedAt: messages.deletedAt,
      createdAt: messages.createdAt,
    })
    .from(messages)
    .innerJoin(users, eq(users.id, messages.senderId))
    .leftJoin(videos, eq(videos.id, messages.videoId))
    .where(and(eq(messages.chatId, chatId), isNull(messages.deletedAt)))
    .orderBy(messages.createdAt)
    .limit(50);

  return (
    <ChatView
      chatId={chatId}
      title={title}
      subtitle={subtitle}
      photoUrl={chatRow[0].photoUrl}
      messages={messageRows.map((m: any) => ({ 
        ...m,
        readAt: null,
        createdAt: typeof m.createdAt === "string" ? m.createdAt : new Date(m.createdAt).toISOString()
      } as any))}
      viewer={{
        id: user.id,
        name: user.name,
        avatarUrl: user.avatarUrl,
      }}
    />
  );
}

import { ne } from "drizzle-orm";
