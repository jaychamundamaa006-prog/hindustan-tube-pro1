import { and, eq } from "drizzle-orm";
import Link from "next/link";
import { db } from "@/db";
import { watchHistory } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { getRelatedVideos, getVideoById, getViewerReaction, isSubscribed } from "@/lib/queries";
import WatchScreen from "@/components/WatchScreen";
import { Button, StateView } from "@/components/ui";

export const dynamic = "force-dynamic";

export default async function WatchPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const videoId = Number(id);
  if (!Number.isFinite(videoId)) {
    return <StateView icon="video" title="Video not found" />;
  }

  const [video, user] = await Promise.all([getVideoById(videoId), getCurrentUser()]);

  if (!video || video.status === "removed") {
    return (
      <StateView
        icon="video"
        title="This video is unavailable"
        message="It may have been removed by the creator or by moderation."
        action={
          <Link href="/home">
            <Button variant="outline">Back to home</Button>
          </Link>
        }
      />
    );
  }

  const isOwner = user?.channelId === video.channelId;
  if (video.visibility === "private" && !isOwner && user?.role !== "admin") {
    return (
      <StateView
        icon="lock"
        title="This video is private"
        message="Only the creator can watch this video."
        action={
          <Link href="/home">
            <Button variant="outline">Back to home</Button>
          </Link>
        }
      />
    );
  }

  const related = await getRelatedVideos(video, 10);
  let reaction: string | null = null;
  let subscribed = false;
  let startAt = 0;
  if (user) {
    [reaction, subscribed] = await Promise.all([
      getViewerReaction(user.id, video.id),
      isSubscribed(user.id, video.channelId),
    ]);
    const rows = await db
      .select({ progressSec: watchHistory.progressSec })
      .from(watchHistory)
      .where(and(eq(watchHistory.userId, user.id), eq(watchHistory.videoId, video.id)))
      .limit(1);
    startAt = rows[0]?.progressSec ?? 0;
  }

  return (
    <WatchScreen
      video={video}
      related={related}
      initialReaction={reaction}
      initialSubscribed={subscribed}
      startAt={startAt}
      viewer={user ? { id: user.id, name: user.name, avatarUrl: user.avatarUrl, role: user.role } : null}
    />
  );
}
