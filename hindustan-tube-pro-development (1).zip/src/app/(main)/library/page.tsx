import Link from "next/link";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { playlists } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import {
  getLikedVideos,
  getPlaylistItems,
  getPlaylists,
  getWatchHistory,
  listVideos,
} from "@/lib/queries";
import LibraryView from "@/components/LibraryView";
import { Button, StateView } from "@/components/ui";

export const dynamic = "force-dynamic";

export default async function LibraryPage() {
  const user = await getCurrentUser();
  if (!user) {
    return (
      <StateView
        icon="library"
        title="Your library lives here"
        message="Sign in to keep your history, playlists, liked videos and uploads in sync."
        action={
          <Link href="/login">
            <Button>Sign in</Button>
          </Link>
        }
      />
    );
  }

  const [history, lists, liked, yourVideos] = await Promise.all([
    getWatchHistory(user.id, 30),
    getPlaylists(user.id),
    getLikedVideos(user.id, 30),
    user.channelId
      ? listVideos({ channelId: user.channelId, shorts: "any", limit: 30, includeAllVisibility: true })
      : Promise.resolve([]),
  ]);

  const watchLaterRow = await db
    .select({ id: playlists.id })
    .from(playlists)
    .where(and(eq(playlists.userId, user.id), eq(playlists.system, "watch_later")))
    .limit(1);
  const watchLater = watchLaterRow[0] ? await getPlaylistItems(watchLaterRow[0].id) : [];

  return (
    <LibraryView
      history={history}
      playlists={lists}
      liked={liked}
      watchLater={watchLater}
      yourVideos={yourVideos}
    />
  );
}
