import { and, eq, sql } from "drizzle-orm";
import Link from "next/link";
import { db } from "@/db";
import { playlists, videos } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { getChannelByHandleOrId, isSubscribed, listVideos } from "@/lib/queries";
import ChannelView from "@/components/ChannelView";
import { Button, StateView } from "@/components/ui";

export const dynamic = "force-dynamic";

export default async function ChannelPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const channel = await getChannelByHandleOrId(decodeURIComponent(id));

  if (!channel) {
    return (
      <StateView
        icon="user"
        title="Channel not found"
        message="This creator may have changed their handle or been removed."
        action={
          <Link href="/home">
            <Button variant="outline">Back to home</Button>
          </Link>
        }
      />
    );
  }

  const user = await getCurrentUser();
  const [longform, shorts, stats, ownerPlaylists] = await Promise.all([
    listVideos({ channelId: channel.id, shorts: false, limit: 20 }),
    listVideos({ channelId: channel.id, shorts: true, limit: 20 }),
    db
      .select({
        totalViews: sql<number>`coalesce(sum(${videos.views}), 0)::int`,
        videoCount: sql<number>`count(*)::int`,
      })
      .from(videos)
      .where(eq(videos.channelId, channel.id)),
    db
      .select({
        id: playlists.id,
        title: playlists.title,
        count: sql<number>`(select count(*)::int from playlist_items pit where pit.playlist_id = playlists.id)`,
        cover: sql<
          string | null
        >`(select v.thumbnail_url from playlist_items pit join videos v on v.id = pit.video_id where pit.playlist_id = playlists.id limit 1)`,
      })
      .from(playlists)
      .where(and(eq(playlists.userId, channel.userId), eq(playlists.visibility, "public"))),
  ]);

  const subscribed = user ? await isSubscribed(user.id, channel.id) : false;

  return (
    <ChannelView
      channel={{
        id: channel.id,
        name: channel.name,
        handle: channel.handle,
        description: channel.description,
        avatarUrl: channel.avatarUrl,
        bannerUrl: channel.bannerUrl,
        country: channel.country,
        verified: channel.verified,
        subscriberCount: channel.subscriberCount,
        createdAt: new Date(channel.createdAt).toISOString(),
        totalViews: stats[0]?.totalViews ?? 0,
        videoCount: stats[0]?.videoCount ?? 0,
      }}
      videos={longform}
      shorts={shorts}
      playlists={ownerPlaylists}
      subscribed={subscribed}
      isOwner={user?.channelId === channel.id}
      signedIn={Boolean(user)}
    />
  );
}
