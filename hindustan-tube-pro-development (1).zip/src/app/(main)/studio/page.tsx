import Link from "next/link";
import { and, desc, eq, gte, sql } from "drizzle-orm";
import { db } from "@/db";
import { analyticsDaily, channels, videos, withdrawals } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { listVideos } from "@/lib/queries";
import { computeEarnings, getMonetizationConfig } from "@/lib/settings";
import StudioView from "@/components/StudioView";
import { Button, StateView } from "@/components/ui";

export const dynamic = "force-dynamic";

export default async function StudioPage() {
  const user = await getCurrentUser();
  if (!user) {
    return (
      <StateView
        icon="chart"
        title="Creator Studio"
        message="Sign in with a creator account to view analytics and earnings."
        action={
          <Link href="/login">
            <Button>Sign in</Button>
          </Link>
        }
      />
    );
  }
  if (!user.channelId) {
    return (
      <StateView
        icon="upload"
        title="Create your channel"
        message="Publish your first video and your studio dashboard will unlock."
        action={
          <Link href="/upload">
            <Button>Upload a video</Button>
          </Link>
        }
      />
    );
  }

  const channelId = user.channelId;
  const since = new Date(Date.now() - 29 * 24 * 60 * 60 * 1000).toISOString().slice(0, 10);

  const [myVideos, totals, series, channelRow, payouts, config] = await Promise.all([
    listVideos({ channelId, shorts: "any", limit: 50, includeAllVisibility: true }),
    db
      .select({
        views: sql<number>`coalesce(sum(${videos.views}),0)::int`,
        watch: sql<number>`coalesce(sum(${videos.watchMinutes}),0)::int`,
        likes: sql<number>`coalesce(sum(${videos.likeCount}),0)::int`,
        comments: sql<number>`coalesce(sum(${videos.commentCount}),0)::int`,
      })
      .from(videos)
      .where(eq(videos.channelId, channelId)),
    db
      .select()
      .from(analyticsDaily)
      .where(and(eq(analyticsDaily.channelId, channelId), gte(analyticsDaily.day, since)))
      .orderBy(analyticsDaily.day),
    db.select().from(channels).where(eq(channels.id, channelId)).limit(1),
    db
      .select()
      .from(withdrawals)
      .where(eq(withdrawals.channelId, channelId))
      .orderBy(desc(withdrawals.requestedAt))
      .limit(20),
    getMonetizationConfig(),
  ]);

  const total = totals[0] ?? { views: 0, watch: 0, likes: 0, comments: 0 };
  const subscribers = channelRow[0]?.subscriberCount ?? 0;
  const eligibleViews = series.reduce((sum, s) => sum + s.eligibleViews, 0) || Math.round(total.views * 0.8);
  const estimatedCents = computeEarnings(config, eligibleViews);
  const withdrawnCents = payouts
    .filter((p) => p.status === "paid")
    .reduce((s, p) => s + p.amountCents, 0);
  const pendingCents = payouts
    .filter((p) => p.status === "pending" || p.status === "approved")
    .reduce((s, p) => s + p.amountCents, 0);

  const eligible =
    config.enabled &&
    subscribers >= config.minSubscribers &&
    eligibleViews >= config.minEligibleViews &&
    total.watch >= config.minWatchMinutes;

  return (
    <StudioView
      data={{
        channelName: channelRow[0]?.name ?? user.name,
        channelHandle: channelRow[0]?.handle ?? user.username,
        subscribers,
        totalViews: total.views,
        watchMinutes: total.watch,
        likes: total.likes,
        comments: total.comments,
        videos: myVideos,
        series: series.map((s) => ({
          day: String(s.day),
          views: s.views,
          watchMinutes: s.watchMinutes,
          subs: s.subscribersGained,
        })),
        earnings: {
          eligibleViews,
          estimatedCents,
          totalCents: estimatedCents,
          pendingCents,
          withdrawnCents,
          availableCents: Math.max(0, estimatedCents - withdrawnCents - pendingCents),
          minWithdrawalCents: config.minWithdrawalCents,
          eligible,
          requirements: [
            { label: "Subscribers", current: subscribers, target: config.minSubscribers },
            { label: "Eligible views", current: eligibleViews, target: config.minEligibleViews },
            { label: "Watch minutes", current: total.watch, target: config.minWatchMinutes },
          ],
        },
        withdrawals: payouts.map((p) => ({
          id: p.id,
          amountCents: p.amountCents,
          status: p.status,
          method: p.method,
          requestedAt: new Date(p.requestedAt).toISOString(),
        })),
      }}
    />
  );
}
