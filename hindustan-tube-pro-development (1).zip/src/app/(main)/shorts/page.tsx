import { eq } from "drizzle-orm";
import { db } from "@/db";
import { subscriptions } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { listVideos } from "@/lib/queries";
import ShortsPlayer from "@/components/ShortsPlayer";
import { StateView } from "@/components/ui";

export const dynamic = "force-dynamic";

export default async function ShortsPage({
  searchParams,
}: {
  searchParams: Promise<{ v?: string }>;
}) {
  const params = await searchParams;
  try {
    const [shorts, user] = await Promise.all([
      listVideos({ shorts: true, limit: 20, sort: "views" }),
      getCurrentUser(),
    ]);
    let subscribedIds: number[] = [];
    if (user) {
      const rows = await db
        .select({ channelId: subscriptions.channelId })
        .from(subscriptions)
        .where(eq(subscriptions.userId, user.id));
      subscribedIds = rows.map((r) => r.channelId);
    }

    return (
      <ShortsPlayer
        shorts={shorts}
        subscribedIds={subscribedIds}
        startId={params.v ? Number(params.v) : undefined}
        viewer={
          user ? { id: user.id, name: user.name, avatarUrl: user.avatarUrl, role: user.role } : null
        }
      />
    );
  } catch {
    return (
      <div className="grid h-[100dvh] place-items-center bg-black">
        <StateView tone="error" icon="wifi" title="Shorts unavailable" message="Please try again." />
      </div>
    );
  }
}
