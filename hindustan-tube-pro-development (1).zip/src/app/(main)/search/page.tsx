"use client";

import Link from "next/link";
import { useCallback, useEffect, useState } from "react";
import Icon from "@/components/Icon";
import VideoCard from "@/components/VideoCard";
import { Avatar, Button, Chip, StateView, VideoCardSkeleton } from "@/components/ui";
import { SORT_OPTIONS } from "@/lib/constants";
import { compactNumber } from "@/lib/format";
import type { VideoCard as VideoCardType } from "@/lib/queries";

type ChannelResult = {
  id: number;
  name: string;
  handle: string;
  avatarUrl: string | null;
  verified: boolean;
  subscriberCount: number;
  description: string;
};

const TYPES = [
  { value: "videos", label: "Videos" },
  { value: "shorts", label: "Shorts" },
  { value: "channels", label: "Channels" },
];

export default function SearchPage() {
  const [query, setQuery] = useState("");
  const [submitted, setSubmitted] = useState("");
  const [type, setType] = useState("videos");
  const [sort, setSort] = useState("latest");
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [history, setHistory] = useState<{ id: number; query: string }[]>([]);
  const [videos, setVideos] = useState<VideoCardType[]>([]);
  const [channels, setChannels] = useState<ChannelResult[]>([]);
  const [status, setStatus] = useState<"idle" | "loading" | "ready" | "error">("idle");

  const loadHistory = useCallback(async () => {
    const res = await fetch("/api/search?mode=history");
    const data = await res.json();
    setHistory(data.history ?? []);
  }, []);

  useEffect(() => {
    void loadHistory();
  }, [loadHistory]);

  useEffect(() => {
    if (!query.trim() || query === submitted) {
      setSuggestions([]);
      return;
    }
    const id = setTimeout(async () => {
      try {
        const res = await fetch(`/api/search?q=${encodeURIComponent(query)}`);
        const data = await res.json();
        setSuggestions(data.suggestions ?? []);
      } catch {
        setSuggestions([]);
      }
    }, 220);
    return () => clearTimeout(id);
  }, [query, submitted]);

  const runSearch = useCallback(
    async (term: string, nextType = type, nextSort = sort) => {
      const q = term.trim();
      if (!q) return;
      setSubmitted(q);
      setSuggestions([]);
      setStatus("loading");
      try {
        const res = await fetch(
          `/api/search?mode=results&q=${encodeURIComponent(q)}&type=${nextType}&sort=${nextSort}`,
        );
        if (!res.ok) throw new Error();
        const data = await res.json();
        setVideos(data.videos ?? []);
        setChannels(data.channels ?? []);
        setStatus("ready");
        void fetch("/api/search", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ query: q }),
        }).then(loadHistory);
      } catch {
        setStatus("error");
      }
    },
    [type, sort, loadHistory],
  );

  return (
    <div className="min-h-[60vh]">
      <div className="sticky top-14 z-40 border-b border-line bg-bg/95 px-3 py-3 glass">
        <div className="flex items-center gap-2 rounded-full bg-surface2 px-4 py-2.5">
          <Icon name="search" size={18} className="text-muted" />
          <input
            autoFocus
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && runSearch(query)}
            placeholder="Search videos, shorts, channels…"
            className="flex-1 bg-transparent text-sm outline-none"
          />
          {query && (
            <button onClick={() => setQuery("")} className="text-muted">
              <Icon name="close" size={16} />
            </button>
          )}
        </div>

        {submitted && (
          <div className="no-scrollbar mt-3 flex gap-2 overflow-x-auto">
            {TYPES.map((t) => (
              <Chip
                key={t.value}
                active={type === t.value}
                onClick={() => {
                  setType(t.value);
                  void runSearch(submitted, t.value, sort);
                }}
              >
                {t.label}
              </Chip>
            ))}
            <span className="mx-1 w-px shrink-0 bg-line" />
            {SORT_OPTIONS.map((s) => (
              <Chip
                key={s.value}
                active={sort === s.value}
                onClick={() => {
                  setSort(s.value);
                  void runSearch(submitted, type, s.value);
                }}
              >
                {s.label}
              </Chip>
            ))}
          </div>
        )}
      </div>

      {suggestions.length > 0 && (
        <ul className="border-b border-line">
          {suggestions.map((s) => (
            <li key={s}>
              <button
                onClick={() => {
                  setQuery(s);
                  void runSearch(s);
                }}
                className="flex w-full items-center gap-3 px-4 py-3 text-left text-sm hover:bg-surface2"
              >
                <Icon name="search" size={16} className="text-muted" /> {s}
              </button>
            </li>
          ))}
        </ul>
      )}

      {!submitted && (
        <div className="px-4 py-5">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold">Recent searches</h2>
            {history.length > 0 && (
              <button
                onClick={async () => {
                  await fetch("/api/search", { method: "DELETE" });
                  setHistory([]);
                }}
                className="text-xs font-semibold text-brand"
              >
                Clear history
              </button>
            )}
          </div>
          {history.length === 0 ? (
            <StateView
              icon="search"
              title="Search Hindustan Tube Pro"
              message="Find videos, shorts, creators and topics across the platform."
            />
          ) : (
            <ul className="mt-3 space-y-1">
              {history.map((h) => (
                <li key={h.id}>
                  <button
                    onClick={() => {
                      setQuery(h.query);
                      void runSearch(h.query);
                    }}
                    className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left text-sm hover:bg-surface2"
                  >
                    <Icon name="clock" size={16} className="text-muted" /> {h.query}
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
      )}

      {status === "loading" && (
        <div className="space-y-6 p-3">
          {Array.from({ length: 3 }).map((_, i) => (
            <VideoCardSkeleton key={i} />
          ))}
        </div>
      )}

      {status === "error" && (
        <StateView
          tone="error"
          icon="wifi"
          title="Search failed"
          message="Something went wrong while searching."
          action={<Button onClick={() => runSearch(submitted)}>Retry</Button>}
        />
      )}

      {status === "ready" && (
        <div className="p-3">
          {channels.length > 0 && (
            <div className="mb-4 divide-y divide-line/60 rounded-2xl bg-surface">
              {channels.map((c) => (
                <Link key={c.id} href={`/channel/${c.handle}`} className="flex items-center gap-3 p-3">
                  <Avatar src={c.avatarUrl} name={c.name} size={48} />
                  <div className="min-w-0 flex-1">
                    <p className="flex items-center gap-1 truncate text-sm font-semibold">
                      {c.name}
                      {c.verified && <Icon name="check" size={12} className="text-secondary" />}
                    </p>
                    <p className="truncate text-xs text-muted">
                      @{c.handle} · {compactNumber(c.subscriberCount)} subscribers
                    </p>
                  </div>
                  <Icon name="chevronRight" size={16} className="text-muted" />
                </Link>
              ))}
            </div>
          )}

          {videos.length === 0 && channels.length === 0 ? (
            <StateView
              icon="search"
              title={`No results for "${submitted}"`}
              message="Try different keywords or remove filters."
              action={<Button variant="outline" onClick={() => setSort("latest")}>Reset filters</Button>}
            />
          ) : (
            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {videos.map((v) => (
                <VideoCard key={v.id} video={v} />
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
