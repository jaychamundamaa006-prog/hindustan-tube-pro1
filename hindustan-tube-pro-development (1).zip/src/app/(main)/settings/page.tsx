import Link from "next/link";
import { getCurrentUser } from "@/lib/auth";
import SettingsView from "@/components/SettingsView";
import { Button, StateView } from "@/components/ui";

export const dynamic = "force-dynamic";

export default async function SettingsPage() {
  const user = await getCurrentUser();
  if (!user) {
    return (
      <StateView
        icon="settings"
        title="Settings"
        message="Sign in to manage your account, playback and privacy preferences."
        action={
          <Link href="/login">
            <Button>Sign in</Button>
          </Link>
        }
      />
    );
  }
  return (
    <SettingsView
      user={{
        name: user.name,
        username: user.username,
        email: user.email,
        phone: user.phone,
        avatarUrl: user.avatarUrl,
        role: user.role,
        verified: user.verified,
        channelHandle: user.channelHandle,
      }}
    />
  );
}
