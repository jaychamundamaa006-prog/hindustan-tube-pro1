import type { ReactNode } from "react";
import { and, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { notifications } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import AppChrome from "@/components/AppChrome";

export default async function MainLayout({ children }: { children: ReactNode }) {
  const user = await getCurrentUser();
  let unread = 0;
  if (user) {
    try {
      const rows = await db
        .select({ count: sql<number>`count(*)::int` })
        .from(notifications)
        .where(and(eq(notifications.userId, user.id), eq(notifications.read, false)));
      unread = rows[0]?.count ?? 0;
    } catch {
      unread = 0;
    }
  }

  return (
    <AppChrome
      user={
        user
          ? {
              id: user.id,
              name: user.name,
              username: user.username,
              avatarUrl: user.avatarUrl,
              role: user.role,
              channelHandle: user.channelHandle,
            }
          : null
      }
      unread={unread}
    >
      {children}
    </AppChrome>
  );
}
