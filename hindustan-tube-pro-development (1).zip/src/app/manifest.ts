import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "Hindustan Tube Pro",
    short_name: "Hindustan Tube",
    description: "Watch. Create. Earn. — Premium video sharing for long videos and vertical shorts.",
    start_url: "/splash",
    display: "standalone",
    background_color: "#0F1115",
    theme_color: "#FF3B30",
    orientation: "portrait",
    icons: [
      { src: "/logo.png", sizes: "512x512", type: "image/png", purpose: "any" },
      { src: "/icon-512.png", sizes: "512x512", type: "image/png", purpose: "maskable" },
      { src: "/icon-192.png", sizes: "192x192", type: "image/png", purpose: "any" },
      { src: "/apple-touch-icon.png", sizes: "180x180", type: "image/png" },
    ],
    categories: ["entertainment", "video", "social"],
    lang: "en-IN",
  };
}
