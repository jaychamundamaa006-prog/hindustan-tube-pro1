import { and, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { playlistItems, playlists } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { fail, num, ok, str, unauthorized } from "@/lib/api";
import { getPlaylists } from "@/lib/queries";

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return unauthorized();
  return ok({ playlists: await getPlaylists(user.id) });
}

async function assertOwner(userId: number, playlistId: number) {
  const rows = await db
    .select({ id: playlists.id })
    .from(playlists)
    .where(and(eq(playlists.id, playlistId), eq(playlists.userId, userId)))
    .limit(1);
  return Boolean(rows[0]);
}

export async function POST(req: Request) {
  const user = await getCurrentUser();
  if (!user) return unauthorized();
  const body = await req.json().catch(() => null);
  if (!body) return fail("Invalid payload.");
  const action = str(body.action, 20) || "create";

  if (action === "create") {
    const title = str(body.title, 100);
    if (title.length < 2) return fail("Playlist name is too short.");
    const created = await db
      .insert(playlists)
      .values({
        userId: user.id,
        title,
        visibility: body.visibility === "private" ? "private" : "public",
      })
      .returning({ id: playlists.id });
    return ok({ id: created[0].id, message: "Playlist created" }, 201);
  }

  if (action === "add") {
    const playlistId = num(body.playlistId);
    if (!(await assertOwner(user.id, playlistId))) return fail("Not allowed.", 403);
    const max = await db
      .select({ m: sql<number>`coalesce(max(${playlistItems.position}), 0)::int` })
      .from(playlistItems)
      .where(eq(playlistItems.playlistId, playlistId));
    await db
      .insert(playlistItems)
      .values({ playlistId, videoId: num(body.videoId), position: (max[0]?.m ?? 0) + 1 })
      .onConflictDoNothing();
    return ok({ success: true, message: "Added to playlist" });
  }

  if (action === "remove") {
    const playlistId = num(body.playlistId);
    if (!(await assertOwner(user.id, playlistId))) return fail("Not allowed.", 403);
    await db
      .delete(playlistItems)
      .where(
        and(eq(playlistItems.playlistId, playlistId), eq(playlistItems.videoId, num(body.videoId))),
      );
    return ok({ success: true, message: "Removed from playlist" });
  }

  if (action === "reorder") {
    const playlistId = num(body.playlistId);
    if (!(await assertOwner(user.id, playlistId))) return fail("Not allowed.", 403);
    const order: number[] = Array.isArray(body.order) ? body.order.map(Number) : [];
    await Promise.all(
      order.map((videoId, index) =>
        db
          .update(playlistItems)
          .set({ position: index })
          .where(and(eq(playlistItems.playlistId, playlistId), eq(playlistItems.videoId, videoId))),
      ),
    );
    return ok({ success: true });
  }

  return fail("Unsupported action.");
}

export async function PATCH(req: Request) {
  const user = await getCurrentUser();
  if (!user) return unauthorized();
  const body = await req.json().catch(() => null);
  if (!body) return fail("Invalid payload.");
  const id = num(body.id);
  if (!(await assertOwner(user.id, id))) return fail("Not allowed.", 403);
  await db
    .update(playlists)
    .set({
      title: str(body.title, 100) || undefined,
      visibility: body.visibility === "private" ? "private" : body.visibility === "public" ? "public" : undefined,
    })
    .where(eq(playlists.id, id));
  return ok({ success: true, message: "Playlist updated" });
}

export async function DELETE(req: Request) {
  const user = await getCurrentUser();
  if (!user) return unauthorized();
  const id = Number(new URL(req.url).searchParams.get("id"));
  if (!(await assertOwner(user.id, id))) return fail("Not allowed.", 403);
  await db.delete(playlists).where(eq(playlists.id, id));
  return ok({ success: true, message: "Playlist deleted" });
}
