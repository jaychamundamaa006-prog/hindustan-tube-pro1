import { and, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { channels, comments, notifications, videos } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { clientKey, fail, num, ok, rateLimit, str, unauthorized } from "@/lib/api";
import { getComments } from "@/lib/queries";

export async function GET(req: Request) {
  const url = new URL(req.url);
  const videoId = Number(url.searchParams.get("videoId"));
  const sort = url.searchParams.get("sort") === "new" ? "new" : "top";
  if (!videoId) return fail("Missing video id.");
  const tree = await getComments(videoId, sort);
  const page = Math.max(1, Number(url.searchParams.get("page") ?? 1));
  const limit = 10;
  return ok({
    comments: tree.slice((page - 1) * limit, page * limit),
    total: tree.length,
    hasMore: tree.length > page * limit,
  });
}

export async function POST(req: Request) {
  if (!rateLimit(clientKey(req, "comment"), 20, 60_000)) return fail("Too many comments.", 429);
  const user = await getCurrentUser();
  if (!user) return unauthorized();
  const body = await req.json().catch(() => null);
  if (!body) return fail("Invalid payload.");
  const videoId = num(body.videoId);
  const text = str(body.body, 1200);
  const parentId = body.parentId ? num(body.parentId) : null;
  if (text.length < 1) return fail("Comment cannot be empty.");

  const inserted = await db
    .insert(comments)
    .values({ videoId, userId: user.id, body: text, parentId })
    .returning({ id: comments.id, createdAt: comments.createdAt });

  await db
    .update(videos)
    .set({ commentCount: sql`${videos.commentCount} + 1` })
    .where(eq(videos.id, videoId));

  const owner = await db
    .select({ ownerId: channels.userId, title: videos.title, thumb: videos.thumbnailUrl })
    .from(videos)
    .innerJoin(channels, eq(channels.id, videos.channelId))
    .where(eq(videos.id, videoId))
    .limit(1);
  if (owner[0] && owner[0].ownerId !== user.id) {
    await db.insert(notifications).values({
      userId: owner[0].ownerId,
      type: parentId ? "reply" : "comment",
      title: `${user.name} ${parentId ? "replied on" : "commented on"} your video`,
      body: text.slice(0, 120),
      link: `/video/${videoId}`,
      thumbnailUrl: owner[0].thumb,
    });
  }

  return ok(
    {
      comment: {
        id: inserted[0].id,
        body: text,
        likeCount: 0,
        createdAt: new Date(inserted[0].createdAt).toISOString(),
        status: "visible",
        parentId,
        userId: user.id,
        userName: user.name,
        userAvatar: user.avatarUrl,
        replies: [],
      },
    },
    201,
  );
}

export async function PATCH(req: Request) {
  const user = await getCurrentUser();
  if (!user) return unauthorized();
  const body = await req.json().catch(() => null);
  if (!body) return fail("Invalid payload.");
  const id = num(body.id);
  if (str(body.action, 20) === "like") {
    await db
      .update(comments)
      .set({ likeCount: sql`${comments.likeCount} + 1` })
      .where(eq(comments.id, id));
    return ok({ success: true });
  }
  return fail("Unsupported action.");
}

export async function DELETE(req: Request) {
  const user = await getCurrentUser();
  if (!user) return unauthorized();
  const id = Number(new URL(req.url).searchParams.get("id"));
  if (!id) return fail("Missing comment id.");
  const rows = await db.select().from(comments).where(eq(comments.id, id)).limit(1);
  const comment = rows[0];
  if (!comment) return fail("Comment not found.", 404);
  if (comment.userId !== user.id && user.role !== "admin") return fail("Not allowed.", 403);
  await db.update(comments).set({ status: "removed" }).where(eq(comments.id, id));
  await db
    .update(videos)
    .set({ commentCount: sql`GREATEST(${videos.commentCount} - 1, 0)` })
    .where(and(eq(videos.id, comment.videoId)));
  return ok({ success: true });
}
