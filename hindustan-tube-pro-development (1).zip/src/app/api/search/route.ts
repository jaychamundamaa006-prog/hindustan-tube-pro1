import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { searchHistory } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { fail, ok, str } from "@/lib/api";
import { getSuggestions, listVideos, searchChannels } from "@/lib/queries";

export async function GET(req: Request) {
  const url = new URL(req.url);
  const q = (url.searchParams.get("q") ?? "").trim();
  const mode = url.searchParams.get("mode") ?? "suggest";
  const user = await getCurrentUser();

  if (mode === "history") {
    if (!user) return ok({ history: [] });
    const rows = await db
      .select({ id: searchHistory.id, query: searchHistory.query })
      .from(searchHistory)
      .where(eq(searchHistory.userId, user.id))
      .orderBy(desc(searchHistory.createdAt))
      .limit(12);
    const seen = new Set<string>();
    return ok({ history: rows.filter((r) => !seen.has(r.query) && seen.add(r.query)) });
  }

  if (mode === "results") {
    const sort = url.searchParams.get("sort") ?? "latest";
    const type = url.searchParams.get("type") ?? "videos";
    if (type === "channels") {
      return ok({ channels: await searchChannels(q, 12), videos: [] });
    }
    const shorts = type === "shorts" ? true : ("any" as const);
    const videos = await listVideos({ query: q, sort, shorts, limit: 20 });
    return ok({ videos, channels: type === "videos" ? await searchChannels(q, 3) : [] });
  }

  return ok({ suggestions: await getSuggestions(q) });
}

export async function POST(req: Request) {
  const user = await getCurrentUser();
  const body = await req.json().catch(() => null);
  if (!body) return fail("Invalid payload.");
  const query = str(body.query, 120);
  if (!user || !query) return ok({ success: true });
  await db.insert(searchHistory).values({ userId: user.id, query });
  return ok({ success: true });
}

export async function DELETE() {
  const user = await getCurrentUser();
  if (!user) return ok({ success: true });
  await db.delete(searchHistory).where(eq(searchHistory.userId, user.id));
  return ok({ success: true });
}
