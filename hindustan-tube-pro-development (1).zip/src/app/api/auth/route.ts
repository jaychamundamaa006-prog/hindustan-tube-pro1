import { eq, or } from "drizzle-orm";
import { db } from "@/db";
import { channels, notifications, playlists, users } from "@/db/schema";
import { createSession, destroySession, hashPassword, verifyPassword } from "@/lib/auth";
import { clientKey, fail, isEmail, ok, rateLimit, str } from "@/lib/api";

const otpStore = new Map<string, { code: string; expires: number }>();

async function bootstrapAccount(userId: number, name: string, username: string, avatarUrl: string | null) {
  await db.insert(channels).values({
    userId,
    name: `${name.split(" ")[0]}'s Channel`,
    handle: username,
    description: "New creator on Hindustan Tube Pro.",
    avatarUrl,
  });
  await db.insert(playlists).values([
    { userId, title: "Watch Later", visibility: "private", system: "watch_later" },
    { userId, title: "Liked Videos", visibility: "private", system: "liked" },
  ]);
  await db.insert(notifications).values({
    userId,
    type: "system",
    title: "Welcome to Hindustan Tube Pro 🎉",
    body: "Your channel is ready. Upload your first video to start growing.",
    link: "/upload",
  });
}

export async function POST(req: Request) {
  if (!rateLimit(clientKey(req, "auth"), 40, 60_000)) {
    return fail("Too many attempts. Please wait a moment.", 429);
  }
  const body = await req.json().catch(() => null);
  if (!body) return fail("Invalid request.");
  const action = str(body.action, 30);

  if (action === "logout") {
    await destroySession();
    return ok({ success: true });
  }

  if (action === "signup") {
    const name = str(body.name, 80);
    const username = str(body.username, 30).toLowerCase().replace(/[^a-z0-9_.]/g, "");
    const email = str(body.email, 120).toLowerCase();
    const password = str(body.password, 200);
    const phone = str(body.phone, 20);
    if (name.length < 2) return fail("Please enter your full name.");
    if (username.length < 3) return fail("Username must be at least 3 characters.");
    if (!isEmail(email)) return fail("Enter a valid email address.");
    if (password.length < 6) return fail("Password must be at least 6 characters.");

    const existing = await db
      .select({ id: users.id })
      .from(users)
      .where(or(eq(users.email, email), eq(users.username, username)))
      .limit(1);
    if (existing.length) return fail("An account with that email or username already exists.");

    const avatarUrl = str(body.avatarUrl, 500) || null;
    const created = await db
      .insert(users)
      .values({
        name,
        username,
        email,
        phone: phone || null,
        passwordHash: hashPassword(password),
        avatarUrl,
        role: "creator",
      })
      .returning({ id: users.id });

    await bootstrapAccount(created[0].id, name, username, avatarUrl);
    await createSession(created[0].id);
    return ok({ success: true, redirect: "/home" });
  }

  if (action === "login") {
    const identifier = str(body.email, 120).toLowerCase();
    const password = str(body.password, 200);
    const rows = await db
      .select()
      .from(users)
      .where(or(eq(users.email, identifier), eq(users.username, identifier)))
      .limit(1);
    const user = rows[0];
    if (!user || !verifyPassword(password, user.passwordHash)) {
      return fail("Incorrect email or password.", 401);
    }
    if (user.status === "suspended") return fail("This account is suspended. Contact support.", 403);
    await createSession(user.id);
    return ok({ success: true, redirect: user.role === "admin" ? "/admin" : "/home" });
  }

  if (action === "google") {
    const email = (str(body.email, 120) || "google.creator@htp.app").toLowerCase();
    const rows = await db.select().from(users).where(eq(users.email, email)).limit(1);
    let userId = rows[0]?.id;
    if (!userId) {
      const username = email.split("@")[0].replace(/[^a-z0-9_.]/g, "");
      const created = await db
        .insert(users)
        .values({
          name: str(body.name, 80) || "Google User",
          username,
          email,
          passwordHash: hashPassword(crypto.randomUUID()),
          provider: "google",
          role: "creator",
          avatarUrl: null,
        })
        .returning({ id: users.id });
      userId = created[0].id;
      await bootstrapAccount(userId, "Google User", username, null);
    }
    await createSession(userId);
    return ok({ success: true, redirect: "/home" });
  }

  if (action === "otp-request") {
    const phone = str(body.phone, 20);
    if (phone.replace(/\D/g, "").length < 10) return fail("Enter a valid 10-digit phone number.");
    const code = String(Math.floor(100000 + Math.random() * 900000));
    otpStore.set(phone, { code, expires: Date.now() + 5 * 60_000 });
    // In production this dispatches through an SMS gateway; in the sandbox we echo it back.
    return ok({ success: true, devCode: code, message: "OTP sent to " + phone });
  }

  if (action === "otp-verify") {
    const phone = str(body.phone, 20);
    const code = str(body.code, 10);
    const entry = otpStore.get(phone);
    if (!entry || entry.expires < Date.now()) return fail("OTP expired. Request a new code.");
    if (entry.code !== code) return fail("Incorrect OTP code.");
    otpStore.delete(phone);

    const rows = await db.select().from(users).where(eq(users.phone, phone)).limit(1);
    let userId = rows[0]?.id;
    if (!userId) {
      const username = `user${phone.replace(/\D/g, "").slice(-6)}`;
      const created = await db
        .insert(users)
        .values({
          name: `Creator ${phone.slice(-4)}`,
          username,
          email: `${username}@phone.htp.app`,
          phone,
          passwordHash: hashPassword(crypto.randomUUID()),
          provider: "phone",
          role: "creator",
        })
        .returning({ id: users.id });
      userId = created[0].id;
      await bootstrapAccount(userId, `Creator ${phone.slice(-4)}`, username, null);
    }
    await createSession(userId);
    return ok({ success: true, redirect: "/home" });
  }

  if (action === "forgot") {
    const email = str(body.email, 120).toLowerCase();
    if (!isEmail(email)) return fail("Enter a valid email address.");
    return ok({
      success: true,
      message: "If an account exists for that email, a reset link is on its way.",
    });
  }

  return fail("Unsupported action.");
}
