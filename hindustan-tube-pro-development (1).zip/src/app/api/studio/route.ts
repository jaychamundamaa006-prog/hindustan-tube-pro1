import { and, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { videos, withdrawals } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { fail, num, ok, str, unauthorized } from "@/lib/api";
import { getMonetizationConfig } from "@/lib/settings";

export async function PATCH(req: Request) {
  const user = await getCurrentUser();
  if (!user?.channelId) return unauthorized();
  const body = await req.json().catch(() => null);
  if (!body) return fail("Invalid payload.");
  const id = num(body.id);
  const owned = await db
    .select({ id: videos.id })
    .from(videos)
    .where(and(eq(videos.id, id), eq(videos.channelId, user.channelId)))
    .limit(1);
  if (!owned[0]) return fail("Video not found on your channel.", 403);

  const title = str(body.title, 140);
  await db
    .update(videos)
    .set({
      title: title || undefined,
      description: typeof body.description === "string" ? str(body.description, 5000) : undefined,
      thumbnailUrl: str(body.thumbnailUrl, 1000) || undefined,
      category: str(body.category, 40) || undefined,
      visibility: ["public", "unlisted", "private"].includes(String(body.visibility))
        ? String(body.visibility)
        : undefined,
    })
    .where(eq(videos.id, id));
  return ok({ success: true, message: "Video updated" });
}

export async function DELETE(req: Request) {
  const user = await getCurrentUser();
  if (!user?.channelId) return unauthorized();
  const id = Number(new URL(req.url).searchParams.get("id"));
  const result = await db
    .delete(videos)
    .where(and(eq(videos.id, id), eq(videos.channelId, user.channelId)))
    .returning({ id: videos.id });
  if (!result[0]) return fail("Video not found.", 404);
  return ok({ success: true, message: "Video deleted" });
}

export async function POST(req: Request) {
  const user = await getCurrentUser();
  if (!user?.channelId) return unauthorized();
  const body = await req.json().catch(() => null);
  if (!body) return fail("Invalid payload.");
  if (str(body.action, 20) !== "withdraw") return fail("Unsupported action.");

  const config = await getMonetizationConfig();
  const amountCents = Math.round(num(body.amountCents));
  if (amountCents < config.minWithdrawalCents) {
    return fail(
      `Minimum withdrawal is ₹${(config.minWithdrawalCents / 100).toLocaleString("en-IN")}.`,
    );
  }
  const pending = await db
    .select({ total: sql<number>`coalesce(sum(${withdrawals.amountCents}), 0)::int` })
    .from(withdrawals)
    .where(and(eq(withdrawals.channelId, user.channelId), eq(withdrawals.status, "pending")));
  if ((pending[0]?.total ?? 0) > 0) {
    return fail("You already have a withdrawal in review.");
  }
  await db.insert(withdrawals).values({
    channelId: user.channelId,
    amountCents,
    method: str(body.method, 20) || "upi",
    account: str(body.account, 120),
  });
  return ok({ success: true, message: "Withdrawal request submitted" });
}
