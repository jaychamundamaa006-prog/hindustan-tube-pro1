import { eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { channels, comments, reports, users, videos, withdrawals } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { fail, num, ok, str, unauthorized } from "@/lib/api";
import { DEFAULT_MONETIZATION, saveMonetizationConfig, type MonetizationConfig } from "@/lib/settings";

async function requireAdmin() {
  const user = await getCurrentUser();
  if (!user || user.role !== "admin") return null;
  return user;
}

export async function POST(req: Request) {
  const admin = await requireAdmin();
  if (!admin) return unauthorized();
  const body = await req.json().catch(() => null);
  if (!body) return fail("Invalid payload.");
  const action = str(body.action, 30);
  const id = num(body.id);

  switch (action) {
    case "user-status": {
      const status = str(body.status, 20);
      if (!["active", "suspended", "deleted"].includes(status)) return fail("Invalid status.");
      await db.update(users).set({ status }).where(eq(users.id, id));
      return ok({ success: true, message: `User marked ${status}` });
    }
    case "user-verify": {
      await db.update(users).set({ verified: Boolean(body.value) }).where(eq(users.id, id));
      await db.update(channels).set({ verified: Boolean(body.value) }).where(eq(channels.userId, id));
      return ok({ success: true, message: "Creator verification updated" });
    }
    case "user-delete": {
      await db.delete(users).where(eq(users.id, id));
      return ok({ success: true, message: "User deleted" });
    }
    case "video-status": {
      const status = str(body.status, 20);
      if (!["published", "rejected", "removed", "processing"].includes(status)) {
        return fail("Invalid status.");
      }
      await db.update(videos).set({ status }).where(eq(videos.id, id));
      return ok({ success: true, message: `Video ${status}` });
    }
    case "comment-remove": {
      await db.update(comments).set({ status: "removed" }).where(eq(comments.id, id));
      return ok({ success: true, message: "Comment removed" });
    }
    case "report-status": {
      const status = str(body.status, 20);
      if (!["open", "resolved", "dismissed"].includes(status)) return fail("Invalid status.");
      await db.update(reports).set({ status }).where(eq(reports.id, id));
      return ok({ success: true, message: `Report ${status}` });
    }
    case "withdrawal-status": {
      const status = str(body.status, 20);
      if (!["pending", "approved", "rejected", "paid"].includes(status)) return fail("Invalid status.");
      await db
        .update(withdrawals)
        .set({ status, processedAt: new Date(), note: str(body.note, 300) })
        .where(eq(withdrawals.id, id));
      return ok({ success: true, message: `Withdrawal ${status}` });
    }
    case "monetization": {
      const incoming = (body.config ?? {}) as Partial<MonetizationConfig>;
      const next: MonetizationConfig = {
        ...DEFAULT_MONETIZATION,
        ...incoming,
        minSubscribers: Math.max(0, num(incoming.minSubscribers)),
        minEligibleViews: Math.max(0, num(incoming.minEligibleViews)),
        minWatchMinutes: Math.max(0, num(incoming.minWatchMinutes)),
        cpmCents: Math.max(0, num(incoming.cpmCents)),
        shortsCpmCents: Math.max(0, num(incoming.shortsCpmCents)),
        creatorSharePercent: Math.min(100, Math.max(0, num(incoming.creatorSharePercent))),
        minWithdrawalCents: Math.max(0, num(incoming.minWithdrawalCents)),
        enabled: Boolean(incoming.enabled),
        adsEnabled: Boolean(incoming.adsEnabled),
      };
      await saveMonetizationConfig(next);
      return ok({ success: true, message: "Monetization rules saved", config: next });
    }
    case "channel-monetize": {
      await db.update(channels).set({ monetized: Boolean(body.value) }).where(eq(channels.id, id));
      return ok({ success: true, message: "Channel monetization updated" });
    }
    default:
      return fail("Unsupported action.");
  }
}

export async function GET(req: Request) {
  const admin = await requireAdmin();
  if (!admin) return unauthorized();
  const q = (new URL(req.url).searchParams.get("q") ?? "").trim();
  const like = `%${q}%`;

  const [userRows, videoRows] = await Promise.all([
    db
      .select({
        id: users.id,
        name: users.name,
        username: users.username,
        email: users.email,
        role: users.role,
        status: users.status,
        verified: users.verified,
      })
      .from(users)
      .where(q ? sql`${users.name} ILIKE ${like} OR ${users.email} ILIKE ${like}` : undefined)
      .limit(25),
    db
      .select({
        id: videos.id,
        title: videos.title,
        status: videos.status,
        views: videos.views,
        channelName: channels.name,
        thumbnailUrl: videos.thumbnailUrl,
      })
      .from(videos)
      .innerJoin(channels, eq(channels.id, videos.channelId))
      .where(q ? sql`${videos.title} ILIKE ${like}` : undefined)
      .limit(25),
  ]);

  return ok({ users: userRows, videos: videoRows });
}
