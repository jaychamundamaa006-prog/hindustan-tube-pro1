import { eq } from "drizzle-orm";
import { db } from "@/db";
import { media } from "@/db/schema";

export async function GET(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const mediaId = Number(id);
  if (!Number.isFinite(mediaId)) return new Response("Not found", { status: 404 });

  const rows = await db.select().from(media).where(eq(media.id, mediaId)).limit(1);
  const item = rows[0];
  if (!item) return new Response("Not found", { status: 404 });

  const buffer = Buffer.from(item.data);
  const range = req.headers.get("range");
  const headers = new Headers({
    "Content-Type": item.mime,
    "Accept-Ranges": "bytes",
    "Cache-Control": "public, max-age=31536000, immutable",
  });

  if (range) {
    const match = /bytes=(\d*)-(\d*)/.exec(range);
    const start = match?.[1] ? Number(match[1]) : 0;
    const end = match?.[2] ? Number(match[2]) : buffer.length - 1;
    const safeEnd = Math.min(end, buffer.length - 1);
    const chunk = buffer.subarray(start, safeEnd + 1);
    headers.set("Content-Range", `bytes ${start}-${safeEnd}/${buffer.length}`);
    headers.set("Content-Length", String(chunk.length));
    return new Response(new Uint8Array(chunk), { status: 206, headers });
  }

  headers.set("Content-Length", String(buffer.length));
  return new Response(new Uint8Array(buffer), { status: 200, headers });
}
