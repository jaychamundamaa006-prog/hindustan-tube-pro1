import { db } from "@/db";
import { media } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { clientKey, fail, ok, rateLimit, unauthorized } from "@/lib/api";

const MAX_VIDEO = 60 * 1024 * 1024; // 60 MB
const MAX_IMAGE = 8 * 1024 * 1024; // 8 MB
const ALLOWED = [
  "video/mp4",
  "video/webm",
  "video/quicktime",
  "image/jpeg",
  "image/png",
  "image/webp",
  "image/gif",
];

export async function POST(req: Request) {
  if (!rateLimit(clientKey(req, "media"), 20, 60_000)) return fail("Too many uploads.", 429);
  const user = await getCurrentUser();
  if (!user) return unauthorized();

  let form: FormData;
  try {
    form = await req.formData();
  } catch {
    return fail("Upload failed — the file could not be read.");
  }
  const file = form.get("file");
  if (!(file instanceof File)) return fail("No file provided.");
  if (!ALLOWED.includes(file.type)) {
    return fail(`Unsupported file type "${file.type || "unknown"}". Use MP4, WEBM, MOV, JPG or PNG.`);
  }
  const limit = file.type.startsWith("video/") ? MAX_VIDEO : MAX_IMAGE;
  if (file.size > limit) {
    return fail(`File is too large. Maximum size is ${Math.round(limit / 1024 / 1024)} MB.`);
  }

  const buffer = Buffer.from(await file.arrayBuffer());
  const rows = await db
    .insert(media)
    .values({
      ownerId: user.id,
      filename: file.name.slice(0, 200) || "upload",
      mime: file.type,
      size: buffer.length,
      data: buffer,
    })
    .returning({ id: media.id });

  return ok({ id: rows[0].id, url: `/api/media/${rows[0].id}` }, 201);
}
