import { eq } from "drizzle-orm";
import { db } from "@/db";
import { channels, notifications, subscriptions, videos } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { clientKey, fail, num, ok, rateLimit, str, unauthorized } from "@/lib/api";
import { listVideos } from "@/lib/queries";

export async function GET(req: Request) {
  const url = new URL(req.url);
  const category = url.searchParams.get("category") ?? "all";
  const query = url.searchParams.get("q") ?? undefined;
  const sort = url.searchParams.get("sort") ?? "latest";
  const shortsParam = url.searchParams.get("shorts");
  const page = Math.max(1, Number(url.searchParams.get("page") ?? 1));
  const limit = Math.min(24, Math.max(1, Number(url.searchParams.get("limit") ?? 8)));

  const shorts =
    category === "shorts" ? true : shortsParam === "any" ? ("any" as const) : shortsParam === "true";

  try {
    const results = await listVideos({ category, query, sort, shorts, page, limit });
    return ok({ videos: results, page, hasMore: results.length === limit });
  } catch {
    return fail("Unable to load videos right now.", 500);
  }
}

export async function POST(req: Request) {
  if (!rateLimit(clientKey(req, "upload"), 12, 60_000)) {
    return fail("Too many uploads. Please wait a minute.", 429);
  }
  const user = await getCurrentUser();
  if (!user) return unauthorized();

  const body = await req.json().catch(() => null);
  if (!body) return fail("Invalid payload.");

  const title = str(body.title, 140);
  const videoUrl = str(body.videoUrl, 1000);
  const thumbnailUrl = str(body.thumbnailUrl, 1000) || "https://picsum.photos/seed/htp/1280/720";
  const durationSec = num(body.durationSec) || 0;
  const maxDurationSec = 50 * 60 * 60; // 50 hours
  
  if (title.length < 3) return fail("Title must be at least 3 characters.");
  if (durationSec > maxDurationSec) {
    return fail(`Video duration exceeds 50-hour limit (${Math.round(durationSec / 3600)} hours provided).`);
  }
  
  const isInternal = videoUrl.startsWith("/api/media/");
  if (!isInternal && !/^https?:\/\//.test(videoUrl)) {
    return fail("A valid video file or URL is required.");
  }
  if (!isInternal && !/\.(mp4|webm|mov|m3u8)(\?.*)?$/i.test(videoUrl)) {
    return fail("Unsupported file type. Use MP4, WEBM, MOV or HLS.");
  }

  let channelId = user.channelId;
  if (!channelId) {
    const created = await db
      .insert(channels)
      .values({
        userId: user.id,
        name: `${user.name}'s Channel`,
        handle: user.username,
        description: "New creator on Hindustan Tube Pro.",
        avatarUrl: user.avatarUrl,
      })
      .returning({ id: channels.id });
    channelId = created[0].id;
  }

  const isShort = Boolean(body.isShort);
  const inserted = await db
    .insert(videos)
    .values({
      channelId,
      title,
      description: str(body.description, 5000),
      videoUrl,
      thumbnailUrl,
      category: str(body.category, 40) || "trending",
      tags: String(body.tags ?? "")
        .split(",")
        .map((t: string) => t.trim())
        .filter(Boolean)
        .slice(0, 12),
      durationSec: durationSec || (isShort ? 30 : 300),
      isShort,
      audioTitle: isShort ? str(body.audioTitle, 120) || "Original audio" : null,
      visibility: ["public", "unlisted", "private"].includes(String(body.visibility))
        ? String(body.visibility)
        : "public",
      status: "published",
    })
    .returning({ id: videos.id, title: videos.title, thumbnailUrl: videos.thumbnailUrl });

  const video = inserted[0];

  // Notify subscribers of the new upload.
  const subs = await db
    .select({ userId: subscriptions.userId })
    .from(subscriptions)
    .where(eq(subscriptions.channelId, channelId));
  if (subs.length) {
    await db.insert(notifications).values(
      subs.slice(0, 500).map((s) => ({
        userId: s.userId,
        type: "upload",
        title: `${user.channelName ?? user.name} uploaded a new video`,
        body: video.title,
        link: `/video/${video.id}`,
        thumbnailUrl: video.thumbnailUrl,
      })),
    );
  }

  return ok({ video }, 201);
}
