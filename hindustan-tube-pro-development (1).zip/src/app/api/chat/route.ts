import { and, desc, eq, gt, isNull, lte, ne, or, sql } from "drizzle-orm";
import { db } from "@/db";
import { blockedUsers, chatMembers, chats, messages, messageReads, users, videos } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { clientKey, fail, num, ok, rateLimit, str, unauthorized } from "@/lib/api";

export async function GET(req: Request) {
  const user = await getCurrentUser();
  if (!user) return unauthorized();

  const url = new URL(req.url);
  const mode = url.searchParams.get("mode") ?? "list";
  const chatId = num(url.searchParams.get("chatId"));
  const limit = Math.min(50, Math.max(1, num(url.searchParams.get("limit")) || 20));
  const offset = Math.max(0, num(url.searchParams.get("offset")) || 0);

  if (mode === "list") {
    const rows = await db
      .select({
        id: chats.id,
        type: chats.type,
        name: chats.name,
        photoUrl: chats.photoUrl,
        lastMessage: messages.body,
        lastMessageTime: chats.lastMessageTime,
        lastSenderName: users.name,
        memberCount: sql<number>`(select count(*)::int from ${chatMembers} where ${chatMembers.chatId} = ${chats.id} and ${chatMembers.leftAt} is null)`,
        unreadCount: sql<number>`(select count(*)::int from ${messages} m where m.${messages.chatId} = ${chats.id} and m.${messages.senderId} != ${user.id} and m.${messages.createdAt} > (select coalesce(max(${messageReads.readAt}), now() - interval '30 days') from ${messageReads} where ${messageReads.userId} = ${user.id} and ${messageReads.messageId} = m.id) and m.${messages.deletedAt} is null)`,
      })
      .from(chats)
      .innerJoin(chatMembers, and(eq(chatMembers.chatId, chats.id), eq(chatMembers.userId, user.id), isNull(chatMembers.leftAt)))
      .leftJoin(messages, eq(messages.id, chats.lastMessageId))
      .leftJoin(users, eq(users.id, messages?.senderId ?? null))
      .orderBy(desc(chats.lastMessageTime))
      .limit(limit)
      .offset(offset);

    return ok({ chats: rows });
  }

  if (mode === "messages" && chatId) {
    const member = await db
      .select()
      .from(chatMembers)
      .where(and(eq(chatMembers.chatId, chatId), eq(chatMembers.userId, user.id)))
      .limit(1);
    if (!member[0]) return fail("Access denied.", 403);

    const rows = await db
      .select({
        id: messages.id,
        chatId: messages.chatId,
        senderId: messages.senderId,
        senderName: users.name,
        senderAvatar: users.avatarUrl,
        type: messages.type,
        body: messages.body,
        mediaUrl: messages.mediaUrl,
        videoId: messages.videoId,
        videoTitle: videos.title,
        videoThumbnail: videos.thumbnailUrl,
        replyToId: messages.replyToId,
        deletedAt: messages.deletedAt,
        createdAt: messages.createdAt,
        readAt: messageReads.readAt,
      })
      .from(messages)
      .innerJoin(users, eq(users.id, messages.senderId))
      .leftJoin(videos, eq(videos.id, messages.videoId))
      .leftJoin(messageReads, and(eq(messageReads.messageId, messages.id), eq(messageReads.userId, user.id)))
      .where(and(eq(messages.chatId, chatId), isNull(messages.deletedAt)))
      .orderBy(desc(messages.createdAt))
      .limit(limit)
      .offset(offset);

    // Mark as read
    const unread = rows.filter((m) => m.senderId !== user.id && !m.readAt);
    if (unread.length > 0) {
      await Promise.all(
        unread.map((m) =>
          db
            .insert(messageReads)
            .values({ messageId: m.id, userId: user.id })
            .onConflictDoNothing(),
        ),
      );
    }

    return ok({ messages: rows.reverse() });
  }

  return fail("Invalid mode.");
}

export async function POST(req: Request) {
  if (!rateLimit(clientKey(req, "chat"), 100, 60_000)) return fail("Too many messages.", 429);
  const user = await getCurrentUser();
  if (!user) return unauthorized();

  const body = await req.json().catch(() => null);
  if (!body) return fail("Invalid payload.");

  const action = str(body.action, 30);

  if (action === "send-direct") {
    const recipientId = num(body.recipientId);
    const text = str(body.text, 5000);
    if (!recipientId || !text) return fail("Missing recipient or message.");

    const blocked = await db
      .select()
      .from(blockedUsers)
      .where(or(and(eq(blockedUsers.userId, user.id), eq(blockedUsers.blockedUserId, recipientId)), and(eq(blockedUsers.userId, recipientId), eq(blockedUsers.blockedUserId, user.id))))
      .limit(1);
    if (blocked[0]) return fail("You cannot message this user.", 403);

    // Find or create direct chat between two users
    const existing = await db
      .select({ id: chats.id })
      .from(chats)
      .innerJoin(chatMembers, eq(chatMembers.chatId, chats.id))
      .where(and(eq(chats.type, "direct"), eq(chatMembers.userId, user.id)))
      .limit(1);

    let chatId = existing[0]?.id;
    if (!chatId) {
      const created = await db
        .insert(chats)
        .values({ type: "direct" })
        .returning({ id: chats.id });
      chatId = created[0].id;
      await db
        .insert(chatMembers)
        .values([
          { chatId, userId: user.id },
          { chatId, userId: recipientId },
        ]);
    }

    const inserted = await db
      .insert(messages)
      .values({
        chatId,
        senderId: user.id,
        type: "text",
        body: text,
      })
      .returning({ id: messages.id });

    await db
      .update(chats)
      .set({ lastMessageId: inserted[0].id, lastMessageTime: new Date() })
      .where(eq(chats.id, chatId));

    return ok({ success: true, chatId, messageId: inserted[0].id }, 201);
  }

  if (action === "send-video-share") {
    const chatId = num(body.chatId);
    const videoId = num(body.videoId);
    if (!chatId || !videoId) return fail("Missing chat or video.");

    const member = await db
      .select()
      .from(chatMembers)
      .where(and(eq(chatMembers.chatId, chatId), eq(chatMembers.userId, user.id)))
      .limit(1);
    if (!member[0]) return fail("Access denied.", 403);

    const inserted = await db
      .insert(messages)
      .values({
        chatId,
        senderId: user.id,
        type: "video_share",
        videoId,
        body: str(body.caption, 500) || null,
      })
      .returning({ id: messages.id });

    await db
      .update(chats)
      .set({ lastMessageId: inserted[0].id, lastMessageTime: new Date() })
      .where(eq(chats.id, chatId));

    return ok({ success: true }, 201);
  }

  if (action === "delete") {
    const messageId = num(body.messageId);
    const msg = await db.select().from(messages).where(eq(messages.id, messageId)).limit(1);
    if (!msg[0]) return fail("Message not found.", 404);
    if (msg[0].senderId !== user.id) return fail("Not allowed.", 403);

    await db.update(messages).set({ deletedAt: new Date() }).where(eq(messages.id, messageId));
    return ok({ success: true });
  }

  if (action === "block") {
    const blockedId = num(body.userId);
    await db
      .insert(blockedUsers)
      .values({ userId: user.id, blockedUserId: blockedId })
      .onConflictDoNothing();
    return ok({ success: true, message: "User blocked." });
  }

  if (action === "unblock") {
    const blockedId = num(body.userId);
    await db
      .delete(blockedUsers)
      .where(and(eq(blockedUsers.userId, user.id), eq(blockedUsers.blockedUserId, blockedId)));
    return ok({ success: true, message: "User unblocked." });
  }

  if (action === "create-group") {
    const name = str(body.name, 100);
    const memberIds = Array.isArray(body.members) ? body.members.map(num).filter(Boolean) : [];
    if (!name || memberIds.length === 0) return fail("Missing name or members.");

    const created = await db
      .insert(chats)
      .values({ type: "group", name, creatorId: user.id })
      .returning({ id: chats.id });
    const chatId = created[0].id;

    await db.insert(chatMembers).values([
      { chatId, userId: user.id, role: "admin" },
      ...memberIds.map((mid: number) => ({
        chatId,
        userId: mid,
        role: "member" as const,
      })),
    ]);

    return ok({ success: true, chatId }, 201);
  }

  if (action === "mute") {
    const chatId = num(body.chatId);
    const hours = num(body.hours) || 8;
    await db
      .update(chatMembers)
      .set({ mutedUntil: new Date(Date.now() + hours * 60 * 60 * 1000) })
      .where(and(eq(chatMembers.chatId, chatId), eq(chatMembers.userId, user.id)));
    return ok({ success: true });
  }

  if (action === "leave") {
    const chatId = num(body.chatId);
    await db
      .update(chatMembers)
      .set({ leftAt: new Date() })
      .where(and(eq(chatMembers.chatId, chatId), eq(chatMembers.userId, user.id)));
    return ok({ success: true, message: "Left chat." });
  }

  return fail("Unsupported action.");
}
