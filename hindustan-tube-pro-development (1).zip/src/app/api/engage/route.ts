import { and, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  channels,
  notifications,
  playlistItems,
  playlists,
  reactions,
  reports,
  subscriptions,
  videos,
  watchHistory,
} from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { clientKey, fail, num, ok, rateLimit, str, unauthorized } from "@/lib/api";

async function systemPlaylist(userId: number, system: "watch_later" | "liked", title: string) {
  const rows = await db
    .select({ id: playlists.id })
    .from(playlists)
    .where(and(eq(playlists.userId, userId), eq(playlists.system, system)))
    .limit(1);
  if (rows[0]) return rows[0].id;
  const created = await db
    .insert(playlists)
    .values({ userId, title, visibility: "private", system })
    .returning({ id: playlists.id });
  return created[0].id;
}

export async function POST(req: Request) {
  if (!rateLimit(clientKey(req, "engage"), 240, 60_000)) {
    return fail("Slow down a little.", 429);
  }
  const body = await req.json().catch(() => null);
  if (!body) return fail("Invalid payload.");
  const action = str(body.action, 30);
  const user = await getCurrentUser();

  // Anonymous-safe actions
  if (action === "view") {
    const videoId = num(body.videoId);
    if (!videoId) return fail("Missing video.");
    await db
      .update(videos)
      .set({ views: sql`${videos.views} + 1`, watchMinutes: sql`${videos.watchMinutes} + 2` })
      .where(eq(videos.id, videoId));
    if (user) {
      await db
        .insert(watchHistory)
        .values({ userId: user.id, videoId, progressSec: 0 })
        .onConflictDoUpdate({
          target: [watchHistory.userId, watchHistory.videoId],
          set: { watchedAt: new Date() },
        });
    }
    return ok({ success: true });
  }

  if (action === "download") {
    return ok({ success: true, message: "Offline downloads arrive in the next release." });
  }

  if (!user) return unauthorized();

  switch (action) {
    case "react": {
      const videoId = num(body.videoId);
      const type = str(body.type, 10) === "dislike" ? "dislike" : "like";
      const existing = await db
        .select()
        .from(reactions)
        .where(and(eq(reactions.userId, user.id), eq(reactions.videoId, videoId)))
        .limit(1);

      if (existing[0]?.type === type) {
        await db.delete(reactions).where(eq(reactions.id, existing[0].id));
        await db
          .update(videos)
          .set(
            type === "like"
              ? { likeCount: sql`GREATEST(${videos.likeCount} - 1, 0)` }
              : { dislikeCount: sql`GREATEST(${videos.dislikeCount} - 1, 0)` },
          )
          .where(eq(videos.id, videoId));
        return ok({ success: true, reaction: null });
      }

      if (existing[0]) {
        await db.update(reactions).set({ type }).where(eq(reactions.id, existing[0].id));
        await db
          .update(videos)
          .set({
            likeCount:
              type === "like" ? sql`${videos.likeCount} + 1` : sql`GREATEST(${videos.likeCount} - 1, 0)`,
            dislikeCount:
              type === "dislike"
                ? sql`${videos.dislikeCount} + 1`
                : sql`GREATEST(${videos.dislikeCount} - 1, 0)`,
          })
          .where(eq(videos.id, videoId));
      } else {
        await db.insert(reactions).values({ userId: user.id, videoId, type });
        await db
          .update(videos)
          .set(
            type === "like"
              ? { likeCount: sql`${videos.likeCount} + 1` }
              : { dislikeCount: sql`${videos.dislikeCount} + 1` },
          )
          .where(eq(videos.id, videoId));
      }

      if (type === "like") {
        const owner = await db
          .select({ ownerId: channels.userId, title: videos.title, thumb: videos.thumbnailUrl })
          .from(videos)
          .innerJoin(channels, eq(channels.id, videos.channelId))
          .where(eq(videos.id, videoId))
          .limit(1);
        if (owner[0] && owner[0].ownerId !== user.id) {
          await db.insert(notifications).values({
            userId: owner[0].ownerId,
            type: "like",
            title: `${user.name} liked your video`,
            body: owner[0].title,
            link: `/video/${videoId}`,
            thumbnailUrl: owner[0].thumb,
          });
        }
      }
      return ok({ success: true, reaction: type, message: type === "like" ? "Added to Liked videos" : "Feedback saved" });
    }

    case "like": {
      const videoId = num(body.videoId);
      await db
        .insert(reactions)
        .values({ userId: user.id, videoId, type: "like" })
        .onConflictDoUpdate({
          target: [reactions.userId, reactions.videoId],
          set: { type: "like" },
        });
      await db.update(videos).set({ likeCount: sql`${videos.likeCount} + 1` }).where(eq(videos.id, videoId));
      return ok({ success: true, message: "Saved to Liked videos" });
    }

    case "watch-later": {
      const videoId = num(body.videoId);
      const playlistId = await systemPlaylist(user.id, "watch_later", "Watch Later");
      await db
        .insert(playlistItems)
        .values({ playlistId, videoId, position: Date.now() % 100000 })
        .onConflictDoNothing();
      return ok({ success: true, message: "Saved to Watch Later" });
    }

    case "subscribe": {
      const channelId = num(body.channelId);
      const existing = await db
        .select({ id: subscriptions.id })
        .from(subscriptions)
        .where(and(eq(subscriptions.userId, user.id), eq(subscriptions.channelId, channelId)))
        .limit(1);
      if (existing[0]) {
        await db.delete(subscriptions).where(eq(subscriptions.id, existing[0].id));
        await db
          .update(channels)
          .set({ subscriberCount: sql`GREATEST(${channels.subscriberCount} - 1, 0)` })
          .where(eq(channels.id, channelId));
        return ok({ success: true, subscribed: false, message: "Unsubscribed" });
      }
      await db.insert(subscriptions).values({ userId: user.id, channelId });
      await db
        .update(channels)
        .set({ subscriberCount: sql`${channels.subscriberCount} + 1` })
        .where(eq(channels.id, channelId));
      const owner = await db
        .select({ ownerId: channels.userId })
        .from(channels)
        .where(eq(channels.id, channelId))
        .limit(1);
      if (owner[0] && owner[0].ownerId !== user.id) {
        await db.insert(notifications).values({
          userId: owner[0].ownerId,
          type: "subscriber",
          title: "New subscriber",
          body: `${user.name} subscribed to your channel`,
          link: `/studio`,
        });
      }
      return ok({ success: true, subscribed: true, message: "Subscribed" });
    }

    case "notify": {
      const channelId = num(body.channelId);
      await db
        .update(subscriptions)
        .set({ notify: Boolean(body.notify) })
        .where(and(eq(subscriptions.userId, user.id), eq(subscriptions.channelId, channelId)));
      return ok({ success: true });
    }

    case "report": {
      if (!rateLimit(clientKey(req, "report"), 10, 60_000)) return fail("Too many reports.", 429);
      await db.insert(reports).values({
        reporterId: user.id,
        targetType: str(body.targetType, 20) || "video",
        targetId: num(body.targetId),
        category: str(body.category, 30) || "other",
        note: str(body.note, 1000),
      });
      return ok({ success: true, message: "Report submitted" });
    }

    case "progress": {
      const videoId = num(body.videoId);
      await db
        .insert(watchHistory)
        .values({ userId: user.id, videoId, progressSec: num(body.progressSec) })
        .onConflictDoUpdate({
          target: [watchHistory.userId, watchHistory.videoId],
          set: { progressSec: num(body.progressSec), watchedAt: new Date() },
        });
      return ok({ success: true });
    }

    case "history-remove": {
      await db
        .delete(watchHistory)
        .where(and(eq(watchHistory.userId, user.id), eq(watchHistory.videoId, num(body.videoId))));
      return ok({ success: true, message: "Removed from history" });
    }

    case "history-clear": {
      await db.delete(watchHistory).where(eq(watchHistory.userId, user.id));
      return ok({ success: true, message: "Watch history cleared" });
    }

    default:
      return fail("Unsupported action.");
  }
}
