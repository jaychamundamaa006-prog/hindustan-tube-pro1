import { and, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { notifications } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { fail, num, ok, str, unauthorized } from "@/lib/api";

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return unauthorized();
  const rows = await db
    .select()
    .from(notifications)
    .where(eq(notifications.userId, user.id))
    .orderBy(desc(notifications.createdAt))
    .limit(100);
  return ok({
    notifications: rows.map((r) => ({ ...r, createdAt: new Date(r.createdAt).toISOString() })),
  });
}

export async function PATCH(req: Request) {
  const user = await getCurrentUser();
  if (!user) return unauthorized();
  const body = await req.json().catch(() => null);
  if (!body) return fail("Invalid payload.");
  if (str(body.action, 20) === "all") {
    await db.update(notifications).set({ read: true }).where(eq(notifications.userId, user.id));
    return ok({ success: true });
  }
  await db
    .update(notifications)
    .set({ read: true })
    .where(and(eq(notifications.id, num(body.id)), eq(notifications.userId, user.id)));
  return ok({ success: true });
}

export async function DELETE(req: Request) {
  const user = await getCurrentUser();
  if (!user) return unauthorized();
  const id = Number(new URL(req.url).searchParams.get("id"));
  if (id) {
    await db
      .delete(notifications)
      .where(and(eq(notifications.id, id), eq(notifications.userId, user.id)));
  } else {
    await db.delete(notifications).where(eq(notifications.userId, user.id));
  }
  return ok({ success: true });
}
