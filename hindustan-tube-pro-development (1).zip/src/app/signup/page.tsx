"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import Icon from "@/components/Icon";
import { Logo } from "@/components/AppChrome";
import { Avatar, Button, Spinner } from "@/components/ui";

const inputCls =
  "w-full rounded-2xl border border-line bg-surface px-4 py-3.5 text-sm outline-none transition-colors focus:border-brand";

export default function SignupPage() {
  const router = useRouter();
  const [form, setForm] = useState({
    name: "",
    username: "",
    email: "",
    phone: "",
    password: "",
    avatarUrl: "",
  });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  const set = (key: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setForm({ ...form, [key]: e.target.value });

  async function submit() {
    setBusy(true);
    setError("");
    try {
      const res = await fetch("/api/auth", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "signup", ...form }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error ?? "Could not create account.");
      } else {
        router.replace(data.redirect ?? "/home");
        router.refresh();
      }
    } catch {
      setError("Network error. Please retry.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="mx-auto flex min-h-dvh max-w-md flex-col justify-center px-6 py-10">
      <div className="fade-up">
        <Logo size={40} />
        <h1 className="mt-6 text-2xl font-bold">Create your channel</h1>
        <p className="mt-1 text-sm text-muted">Join Hindustan Tube Pro — it takes 30 seconds.</p>

        <div className="mt-6 flex items-center gap-4">
          <Avatar src={form.avatarUrl || null} name={form.name || "?"} size={64} ring />
          <div className="flex-1">
            <input
              className={inputCls}
              placeholder="Profile photo URL (optional)"
              value={form.avatarUrl}
              onChange={set("avatarUrl")}
            />
          </div>
        </div>

        <div className="mt-4 space-y-3">
          <input className={inputCls} placeholder="Full name" value={form.name} onChange={set("name")} />
          <input className={inputCls} placeholder="Username (handle)" value={form.username} onChange={set("username")} />
          <input className={inputCls} placeholder="Email" type="email" value={form.email} onChange={set("email")} />
          <input className={inputCls} placeholder="Phone (optional)" value={form.phone} onChange={set("phone")} />
          <input
            className={inputCls}
            placeholder="Password (min 6 characters)"
            type="password"
            value={form.password}
            onChange={set("password")}
          />

          {error && (
            <p className="flex items-center gap-2 rounded-xl bg-danger/10 px-3 py-2 text-xs text-danger">
              <Icon name="info" size={14} /> {error}
            </p>
          )}

          <Button full size="lg" disabled={busy} onClick={submit}>
            {busy ? <Spinner size={18} /> : "Create account"}
          </Button>
          <p className="text-center text-[11px] leading-relaxed text-muted">
            By continuing you agree to our Community Guidelines, Terms and Privacy Policy.
          </p>
        </div>

        <p className="mt-6 text-center text-sm text-muted">
          Already have an account?{" "}
          <Link href="/login" className="font-semibold text-brand">
            Sign in
          </Link>
        </p>
      </div>
    </div>
  );
}
