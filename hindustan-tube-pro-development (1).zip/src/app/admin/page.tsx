import Link from "next/link";
import { desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  channels,
  comments,
  reports,
  subscriptions,
  users,
  videos,
  withdrawals,
} from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { getMonetizationConfig } from "@/lib/settings";
import AdminView from "@/components/AdminView";
import { Button, StateView } from "@/components/ui";

export const dynamic = "force-dynamic";

export default async function AdminPage() {
  const user = await getCurrentUser();
  if (!user || user.role !== "admin") {
    return (
      <div className="mx-auto max-w-md px-4 py-20">
        <StateView
          tone="error"
          icon="shield"
          title="Admin access required"
          message="This console is restricted to platform administrators. Sign in with an admin account to continue."
          action={
            <Link href="/login">
              <Button>Sign in as admin</Button>
            </Link>
          }
        />
      </div>
    );
  }

  const one = sql<number>`count(*)::int`;
  const [
    userCount,
    activeCount,
    videoCount,
    shortCount,
    engagement,
    commentCount,
    reportRows,
    withdrawalRows,
    userRows,
    videoRows,
    reportedComments,
    config,
    subsCount,
  ] = await Promise.all([
    db.select({ c: one }).from(users),
    db.select({ c: one }).from(users).where(eq(users.status, "active")),
    db.select({ c: one }).from(videos).where(eq(videos.isShort, false)),
    db.select({ c: one }).from(videos).where(eq(videos.isShort, true)),
    db
      .select({
        views: sql<number>`coalesce(sum(${videos.views}),0)::int`,
        likes: sql<number>`coalesce(sum(${videos.likeCount}),0)::int`,
      })
      .from(videos),
    db.select({ c: one }).from(comments),
    db
      .select({
        id: reports.id,
        targetType: reports.targetType,
        targetId: reports.targetId,
        category: reports.category,
        note: reports.note,
        status: reports.status,
        createdAt: reports.createdAt,
        reporter: users.name,
      })
      .from(reports)
      .leftJoin(users, eq(users.id, reports.reporterId))
      .orderBy(desc(reports.createdAt))
      .limit(40),
    db
      .select({
        id: withdrawals.id,
        amountCents: withdrawals.amountCents,
        status: withdrawals.status,
        method: withdrawals.method,
        account: withdrawals.account,
        requestedAt: withdrawals.requestedAt,
        channelName: channels.name,
      })
      .from(withdrawals)
      .innerJoin(channels, eq(channels.id, withdrawals.channelId))
      .orderBy(desc(withdrawals.requestedAt))
      .limit(40),
    db
      .select({
        id: users.id,
        name: users.name,
        username: users.username,
        email: users.email,
        role: users.role,
        status: users.status,
        verified: users.verified,
      })
      .from(users)
      .orderBy(desc(users.createdAt))
      .limit(30),
    db
      .select({
        id: videos.id,
        title: videos.title,
        status: videos.status,
        visibility: videos.visibility,
        views: videos.views,
        thumbnailUrl: videos.thumbnailUrl,
        isShort: videos.isShort,
        channelName: channels.name,
      })
      .from(videos)
      .innerJoin(channels, eq(channels.id, videos.channelId))
      .orderBy(desc(videos.createdAt))
      .limit(30),
    db
      .select({
        id: comments.id,
        body: comments.body,
        status: comments.status,
        videoId: comments.videoId,
        author: users.name,
      })
      .from(comments)
      .innerJoin(users, eq(users.id, comments.userId))
      .orderBy(desc(comments.createdAt))
      .limit(20),
    getMonetizationConfig(),
    db.select({ c: one }).from(subscriptions),
  ]);

  const revenueCents = Math.round(
    ((engagement[0]?.views ?? 0) / 1000) * config.cpmCents * ((100 - config.creatorSharePercent) / 100),
  );
  const pendingCents = withdrawalRows
    .filter((w) => w.status === "pending")
    .reduce((s, w) => s + w.amountCents, 0);

  return (
    <AdminView
      stats={{
        users: userCount[0]?.c ?? 0,
        activeUsers: activeCount[0]?.c ?? 0,
        videos: videoCount[0]?.c ?? 0,
        shorts: shortCount[0]?.c ?? 0,
        views: engagement[0]?.views ?? 0,
        likes: engagement[0]?.likes ?? 0,
        comments: commentCount[0]?.c ?? 0,
        subscriptions: subsCount[0]?.c ?? 0,
        openReports: reportRows.filter((r) => r.status === "open").length,
        revenueCents,
        pendingCents,
      }}
      users={userRows}
      videos={videoRows}
      reports={reportRows.map((r) => ({ ...r, createdAt: new Date(r.createdAt).toISOString() }))}
      withdrawals={withdrawalRows.map((w) => ({
        ...w,
        requestedAt: new Date(w.requestedAt).toISOString(),
      }))}
      comments={reportedComments}
      config={config}
      adminName={user.name}
    />
  );
}


