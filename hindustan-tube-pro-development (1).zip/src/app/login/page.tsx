"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import Icon from "@/components/Icon";
import { Logo } from "@/components/AppChrome";
import { Button, Sheet, Spinner } from "@/components/ui";

const inputCls =
  "w-full rounded-2xl border border-line bg-surface px-4 py-3.5 text-sm outline-none transition-colors focus:border-brand";

export default function LoginPage() {
  const router = useRouter();
  const [tab, setTab] = useState<"email" | "phone">("email");
  const [email, setEmail] = useState("aarav@htp.app");
  const [password, setPassword] = useState("password123");
  const [phone, setPhone] = useState("");
  const [code, setCode] = useState("");
  const [otpSent, setOtpSent] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [info, setInfo] = useState("");
  const [forgot, setForgot] = useState(false);
  const [next, setNext] = useState("");

  useEffect(() => {
    const target = new URLSearchParams(window.location.search).get("next");
    if (target && target.startsWith("/")) setNext(target);
  }, []);

  function go(fallback: string) {
    router.replace(next || fallback);
    router.refresh();
  }

  async function post(payload: Record<string, unknown>) {
    setBusy(true);
    setError("");
    setInfo("");
    try {
      const res = await fetch("/api/auth", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error ?? "Something went wrong.");
        return null;
      }
      return data as { redirect?: string; devCode?: string; message?: string };
    } catch {
      setError("Network error. Check your connection and retry.");
      return null;
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="mx-auto flex min-h-dvh max-w-md flex-col justify-center px-6 py-10">
      <div className="fade-up">
        <Logo size={40} />
        <h1 className="mt-6 text-2xl font-bold">Welcome back</h1>
        <p className="mt-1 text-sm text-muted">Sign in to continue watching and creating.</p>

        <div className="mt-6 flex rounded-2xl bg-surface2 p-1">
          {(["email", "phone"] as const).map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={`flex-1 rounded-xl py-2 text-sm font-semibold transition-all ${
                tab === t ? "bg-surface shadow" : "text-muted"
              }`}
            >
              {t === "email" ? "Email" : "Phone OTP"}
            </button>
          ))}
        </div>

        <div className="mt-5 space-y-3">
          {tab === "email" ? (
            <>
              <input
                className={inputCls}
                placeholder="Email or username"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                autoComplete="username"
              />
              <input
                className={inputCls}
                type="password"
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                autoComplete="current-password"
              />
              <button onClick={() => setForgot(true)} className="text-xs font-semibold text-secondary">
                Forgot password?
              </button>
              <Button
                full
                size="lg"
                disabled={busy}
                onClick={async () => {
                  const data = await post({ action: "login", email, password });
                  if (data?.redirect) go(data.redirect);
                }}
              >
                {busy ? <Spinner size={18} /> : "Sign in"}
              </Button>
            </>
          ) : (
            <>
              <input
                className={inputCls}
                placeholder="Phone number (10 digits)"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                inputMode="tel"
              />
              {otpSent && (
                <input
                  className={inputCls}
                  placeholder="6-digit OTP"
                  value={code}
                  onChange={(e) => setCode(e.target.value)}
                  inputMode="numeric"
                />
              )}
              <Button
                full
                size="lg"
                disabled={busy}
                onClick={async () => {
                  if (!otpSent) {
                    const data = await post({ action: "otp-request", phone });
                    if (data) {
                      setOtpSent(true);
                      setInfo(`OTP sent. Sandbox code: ${data.devCode}`);
                    }
                  } else {
                    const data = await post({ action: "otp-verify", phone, code });
                    if (data?.redirect) go(data.redirect);
                  }
                }}
              >
                {busy ? <Spinner size={18} /> : otpSent ? "Verify & continue" : "Send OTP"}
              </Button>
            </>
          )}

          {error && (
            <p className="flex items-center gap-2 rounded-xl bg-danger/10 px-3 py-2 text-xs text-danger">
              <Icon name="info" size={14} /> {error}
            </p>
          )}
          {info && (
            <p className="rounded-xl bg-success/10 px-3 py-2 text-xs text-success">{info}</p>
          )}

          <div className="flex items-center gap-3 py-1 text-xs text-muted">
            <span className="h-px flex-1 bg-line" /> or <span className="h-px flex-1 bg-line" />
          </div>

          <Button
            full
            size="lg"
            variant="outline"
            disabled={busy}
            onClick={async () => {
              const data = await post({ action: "google", email: "google.creator@htp.app", name: "Google Creator" });
              if (data?.redirect) go(data.redirect);
            }}
          >
            <span className="text-base font-bold text-secondary">G</span> Continue with Google
          </Button>
          <Button full size="lg" variant="ghost" onClick={() => router.push(next || "/home")}>
            Browse as guest
          </Button>
        </div>

        <p className="mt-6 text-center text-sm text-muted">
          New here?{" "}
          <Link href="/signup" className="font-semibold text-brand">
            Create an account
          </Link>
        </p>
        <p className="mt-4 rounded-xl bg-surface2 p-3 text-center text-[11px] leading-relaxed text-muted">
          Demo logins — creator: <b>aarav@htp.app</b> / password123 · admin: <b>admin@htp.app</b> / admin12345
        </p>
      </div>

      <Sheet open={forgot} onClose={() => setForgot(false)} title="Reset your password">
        <div className="space-y-3">
          <input
            className={inputCls}
            placeholder="Your account email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
          <Button
            full
            onClick={async () => {
              const data = await post({ action: "forgot", email });
              if (data?.message) {
                setInfo(data.message);
                setForgot(false);
              }
            }}
          >
            Send reset link
          </Button>
        </div>
      </Sheet>
    </div>
  );
}
