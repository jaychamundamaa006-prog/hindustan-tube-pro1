"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import Icon from "./Icon";
import { Button, Sheet, StateView } from "./ui";
import { compactNumber, money, timeAgo } from "@/lib/format";
import { CATEGORIES } from "@/lib/constants";
import type { VideoCard as VideoCardType } from "@/lib/queries";

export type StudioData = {
  channelName: string;
  channelHandle: string;
  subscribers: number;
  totalViews: number;
  watchMinutes: number;
  likes: number;
  comments: number;
  videos: VideoCardType[];
  series: { day: string; views: number; watchMinutes: number; subs: number }[];
  earnings: {
    eligibleViews: number;
    estimatedCents: number;
    totalCents: number;
    pendingCents: number;
    withdrawnCents: number;
    availableCents: number;
    minWithdrawalCents: number;
    eligible: boolean;
    requirements: { label: string; current: number; target: number }[];
  };
  withdrawals: { id: number; amountCents: number; status: string; requestedAt: string; method: string }[];
};

function Sparkline({ data, color }: { data: number[]; color: string }) {
  const max = Math.max(...data, 1);
  const points = data
    .map((v, i) => `${(i / Math.max(1, data.length - 1)) * 100},${40 - (v / max) * 36}`)
    .join(" ");
  return (
    <svg viewBox="0 0 100 40" preserveAspectRatio="none" className="h-16 w-full">
      <polyline points={points} fill="none" stroke={color} strokeWidth="2" strokeLinejoin="round" />
      <polygon points={`0,40 ${points} 100,40`} fill={color} opacity="0.14" />
    </svg>
  );
}

function Metric({ icon, label, value, tint }: { icon: string; label: string; value: string; tint: string }) {
  return (
    <div className="rounded-2xl bg-surface p-3">
      <span className={`grid h-8 w-8 place-items-center rounded-lg ${tint}`}>
        <Icon name={icon} size={16} />
      </span>
      <p className="mt-2 text-lg font-bold leading-none">{value}</p>
      <p className="mt-1 text-[11px] text-muted">{label}</p>
    </div>
  );
}

export default function StudioView({ data }: { data: StudioData }) {
  const router = useRouter();
  const [tab, setTab] = useState<"Overview" | "Content" | "Analytics" | "Earnings">("Overview");
  const [editing, setEditing] = useState<VideoCardType | null>(null);
  const [amount, setAmount] = useState(String(data.earnings.minWithdrawalCents / 100));
  const [account, setAccount] = useState("");
  const [message, setMessage] = useState("");
  const [withdrawOpen, setWithdrawOpen] = useState(false);

  const views = data.series.map((s) => s.views);
  const watch = data.series.map((s) => s.watchMinutes);
  const subs = data.series.map((s) => s.subs);
  const topVideos = [...data.videos].sort((a, b) => b.views - a.views).slice(0, 5);

  async function saveVideo() {
    if (!editing) return;
    const res = await fetch("/api/studio", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        id: editing.id,
        title: editing.title,
        description: editing.description,
        thumbnailUrl: editing.thumbnailUrl,
        category: editing.category,
        visibility: editing.visibility,
      }),
    });
    if (res.ok) {
      setEditing(null);
      router.refresh();
    }
  }

  async function deleteVideo(id: number) {
    await fetch(`/api/studio?id=${id}`, { method: "DELETE" });
    setEditing(null);
    router.refresh();
  }

  async function requestWithdrawal() {
    const res = await fetch("/api/studio", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        action: "withdraw",
        amountCents: Math.round(Number(amount) * 100),
        account,
        method: "upi",
      }),
    });
    const body = await res.json();
    setMessage(res.ok ? body.message : body.error);
    if (res.ok) {
      setWithdrawOpen(false);
      router.refresh();
    }
  }

  return (
    <div className="pb-8">
      <div className="border-b border-line px-3 py-4">
        <h1 className="text-lg font-bold">Creator Studio</h1>
        <p className="text-xs text-muted">
          {data.channelName} · @{data.channelHandle}
        </p>
      </div>

      <div className="no-scrollbar flex gap-1 overflow-x-auto border-b border-line px-3">
        {(["Overview", "Content", "Analytics", "Earnings"] as const).map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`shrink-0 border-b-2 px-4 py-3 text-sm font-semibold ${
              tab === t ? "border-brand text-ink" : "border-transparent text-muted"
            }`}
          >
            {t}
          </button>
        ))}
      </div>

      <div className="space-y-4 p-3">
        {tab === "Overview" && (
          <>
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
              <Metric icon="eye" label="Total views" value={compactNumber(data.totalViews)} tint="bg-brand/15 text-brand" />
              <Metric icon="clock" label="Watch minutes" value={compactNumber(data.watchMinutes)} tint="bg-secondary/15 text-secondary" />
              <Metric icon="users" label="Subscribers" value={compactNumber(data.subscribers)} tint="bg-accent/15 text-accent" />
              <Metric icon="like" label="Likes" value={compactNumber(data.likes)} tint="bg-success/15 text-success" />
              <Metric icon="comment" label="Comments" value={compactNumber(data.comments)} tint="bg-secondary/15 text-secondary" />
              <Metric icon="money" label="Est. earnings" value={money(data.earnings.estimatedCents)} tint="bg-success/15 text-success" />
            </div>

            <div className="rounded-2xl bg-surface p-4">
              <p className="text-xs font-semibold text-muted">Views · last 30 days</p>
              <Sparkline data={views} color="#FF3B30" />
            </div>

            <div className="flex gap-2">
              <Link href="/upload" className="flex-1">
                <Button full>
                  <Icon name="upload" size={16} /> Upload
                </Button>
              </Link>
              <Link href={`/channel/${data.channelHandle}`} className="flex-1">
                <Button full variant="outline">
                  View channel
                </Button>
              </Link>
            </div>

            <div className="rounded-2xl bg-surface p-4">
              <h2 className="mb-2 text-sm font-bold">Recent performance</h2>
              {topVideos.length === 0 ? (
                <p className="text-xs text-muted">Upload a video to start collecting analytics.</p>
              ) : (
                <ul className="space-y-3">
                  {topVideos.map((v) => (
                    <li key={v.id} className="flex items-center gap-3">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img src={v.thumbnailUrl} alt="" className="h-10 w-16 rounded-lg object-cover" />
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-[13px] font-medium">{v.title}</p>
                        <p className="text-[11px] text-muted">
                          {compactNumber(v.views)} views · {compactNumber(v.likeCount)} likes
                        </p>
                      </div>
                      <span className="text-[11px] text-muted">{timeAgo(v.createdAt)}</span>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </>
        )}

        {tab === "Content" &&
          (data.videos.length === 0 ? (
            <StateView
              icon="video"
              title="No content yet"
              message="Your uploads and shorts will be managed here."
              action={
                <Link href="/upload">
                  <Button>Upload now</Button>
                </Link>
              }
            />
          ) : (
            <ul className="space-y-2">
              {data.videos.map((v) => (
                <li key={v.id} className="flex items-center gap-3 rounded-2xl bg-surface p-2.5">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={v.thumbnailUrl} alt="" className="h-12 w-20 rounded-lg object-cover" />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[13px] font-semibold">{v.title}</p>
                    <p className="flex items-center gap-1.5 text-[11px] text-muted">
                      <span className={`rounded px-1.5 py-0.5 ${v.visibility === "public" ? "bg-success/15 text-success" : "bg-surface2"}`}>
                        {v.visibility}
                      </span>
                      {v.isShort ? "Short" : "Video"} · {compactNumber(v.views)} views
                    </p>
                  </div>
                  <button onClick={() => setEditing(v)} className="rounded-full p-2 text-muted hover:bg-surface2">
                    <Icon name="edit" size={16} />
                  </button>
                </li>
              ))}
            </ul>
          ))}

        {tab === "Analytics" && (
          <>
            <div className="rounded-2xl bg-surface p-4">
              <p className="text-xs font-semibold text-muted">Watch time (minutes)</p>
              <Sparkline data={watch} color="#1E88E5" />
            </div>
            <div className="rounded-2xl bg-surface p-4">
              <p className="text-xs font-semibold text-muted">Subscribers gained</p>
              <Sparkline data={subs} color="#00C853" />
            </div>
            <div className="rounded-2xl bg-surface p-4">
              <h2 className="mb-3 text-sm font-bold">Top videos</h2>
              {topVideos.map((v) => {
                const max = Math.max(...topVideos.map((t) => t.views), 1);
                return (
                  <div key={v.id} className="mb-3">
                    <div className="flex justify-between text-[11px]">
                      <span className="truncate pr-2">{v.title}</span>
                      <span className="text-muted">{compactNumber(v.views)}</span>
                    </div>
                    <div className="mt-1 h-2 overflow-hidden rounded-full bg-surface2">
                      <div className="h-full rounded-full bg-gradient-to-r from-brand to-accent" style={{ width: `${(v.views / max) * 100}%` }} />
                    </div>
                  </div>
                );
              })}
            </div>
            <div className="rounded-2xl bg-surface p-4">
              <h2 className="mb-2 text-sm font-bold">Audience overview</h2>
              <div className="grid grid-cols-2 gap-3 text-xs">
                <div className="rounded-xl bg-surface2 p-3">
                  <p className="text-muted">Returning viewers</p>
                  <p className="text-base font-bold">68%</p>
                </div>
                <div className="rounded-xl bg-surface2 p-3">
                  <p className="text-muted">Avg. view duration</p>
                  <p className="text-base font-bold">
                    {Math.max(1, Math.round(data.watchMinutes / Math.max(1, data.totalViews) * 60))}s
                  </p>
                </div>
                <div className="rounded-xl bg-surface2 p-3">
                  <p className="text-muted">Top region</p>
                  <p className="text-base font-bold">India</p>
                </div>
                <div className="rounded-xl bg-surface2 p-3">
                  <p className="text-muted">Mobile traffic</p>
                  <p className="text-base font-bold">91%</p>
                </div>
              </div>
            </div>
          </>
        )}

        {tab === "Earnings" && (
          <>
            <div className="rounded-2xl bg-gradient-to-br from-brand to-[#ff7a3d] p-5 text-white">
              <p className="text-xs opacity-80">Available to withdraw</p>
              <p className="text-3xl font-bold">{money(data.earnings.availableCents)}</p>
              <div className="mt-3 grid grid-cols-3 gap-2 text-[11px]">
                <div>
                  <p className="opacity-80">Total</p>
                  <p className="font-semibold">{money(data.earnings.totalCents)}</p>
                </div>
                <div>
                  <p className="opacity-80">Pending</p>
                  <p className="font-semibold">{money(data.earnings.pendingCents)}</p>
                </div>
                <div>
                  <p className="opacity-80">Withdrawn</p>
                  <p className="font-semibold">{money(data.earnings.withdrawnCents)}</p>
                </div>
              </div>
            </div>

            <div className="rounded-2xl bg-surface p-4">
              <h2 className="mb-1 text-sm font-bold">Monetization status</h2>
              <p className={`mb-3 text-xs ${data.earnings.eligible ? "text-success" : "text-muted"}`}>
                {data.earnings.eligible
                  ? "Your channel meets all program requirements."
                  : "Keep growing — requirements are set by the platform admin."}
              </p>
              {data.earnings.requirements.map((r) => (
                <div key={r.label} className="mb-3">
                  <div className="flex justify-between text-[11px]">
                    <span>{r.label}</span>
                    <span className="text-muted">
                      {compactNumber(r.current)} / {compactNumber(r.target)}
                    </span>
                  </div>
                  <div className="mt-1 h-2 overflow-hidden rounded-full bg-surface2">
                    <div
                      className="h-full rounded-full bg-success"
                      style={{ width: `${Math.min(100, (r.current / Math.max(1, r.target)) * 100)}%` }}
                    />
                  </div>
                </div>
              ))}
              <p className="text-[11px] text-muted">
                Eligible views counted: <b>{compactNumber(data.earnings.eligibleViews)}</b>
              </p>
            </div>

            <Button full onClick={() => setWithdrawOpen(true)} disabled={!data.earnings.eligible}>
              <Icon name="money" size={16} /> Request withdrawal
            </Button>
            {message && <p className="text-center text-xs text-muted">{message}</p>}

            <div className="rounded-2xl bg-surface p-4">
              <h2 className="mb-2 text-sm font-bold">Withdrawal history</h2>
              {data.withdrawals.length === 0 ? (
                <p className="text-xs text-muted">No withdrawals requested yet.</p>
              ) : (
                <ul className="divide-y divide-line/60">
                  {data.withdrawals.map((w) => (
                    <li key={w.id} className="flex items-center justify-between py-2.5 text-xs">
                      <div>
                        <p className="font-semibold">{money(w.amountCents)}</p>
                        <p className="text-muted">
                          {w.method.toUpperCase()} · {timeAgo(w.requestedAt)}
                        </p>
                      </div>
                      <span
                        className={`rounded-full px-2 py-1 text-[10px] font-bold uppercase ${
                          w.status === "paid"
                            ? "bg-success/15 text-success"
                            : w.status === "rejected"
                              ? "bg-danger/15 text-danger"
                              : "bg-accent/15 text-accent"
                        }`}
                      >
                        {w.status}
                      </span>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </>
        )}
      </div>

      <Sheet open={editing !== null} onClose={() => setEditing(null)} title="Edit video">
        {editing && (
          <div className="space-y-3">
            <input
              value={editing.title}
              onChange={(e) => setEditing({ ...editing, title: e.target.value })}
              className="w-full rounded-2xl border border-line bg-surface2 px-4 py-3 text-sm outline-none focus:border-brand"
            />
            <textarea
              rows={3}
              value={editing.description}
              onChange={(e) => setEditing({ ...editing, description: e.target.value })}
              className="w-full rounded-2xl border border-line bg-surface2 px-4 py-3 text-sm outline-none focus:border-brand"
            />
            <input
              value={editing.thumbnailUrl}
              onChange={(e) => setEditing({ ...editing, thumbnailUrl: e.target.value })}
              placeholder="Thumbnail URL"
              className="w-full rounded-2xl border border-line bg-surface2 px-4 py-3 text-sm outline-none focus:border-brand"
            />
            <div className="grid grid-cols-2 gap-3">
              <select
                value={editing.category}
                onChange={(e) => setEditing({ ...editing, category: e.target.value })}
                className="rounded-2xl border border-line bg-surface2 px-3 py-3 text-sm"
              >
                {CATEGORIES.filter((c) => c.slug !== "all" && c.slug !== "shorts").map((c) => (
                  <option key={c.slug} value={c.slug}>
                    {c.name}
                  </option>
                ))}
              </select>
              <select
                value={editing.visibility}
                onChange={(e) => setEditing({ ...editing, visibility: e.target.value })}
                className="rounded-2xl border border-line bg-surface2 px-3 py-3 text-sm"
              >
                <option value="public">Public</option>
                <option value="unlisted">Unlisted</option>
                <option value="private">Private</option>
              </select>
            </div>
            <Button full onClick={saveVideo}>
              Save changes
            </Button>
            <Button full variant="danger" onClick={() => deleteVideo(editing.id)}>
              <Icon name="trash" size={16} /> Delete video
            </Button>
          </div>
        )}
      </Sheet>

      <Sheet open={withdrawOpen} onClose={() => setWithdrawOpen(false)} title="Request withdrawal">
        <div className="space-y-3">
          <input
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            inputMode="decimal"
            placeholder="Amount (₹)"
            className="w-full rounded-2xl border border-line bg-surface2 px-4 py-3 text-sm outline-none focus:border-brand"
          />
          <input
            value={account}
            onChange={(e) => setAccount(e.target.value)}
            placeholder="UPI ID or bank account"
            className="w-full rounded-2xl border border-line bg-surface2 px-4 py-3 text-sm outline-none focus:border-brand"
          />
          <p className="text-[11px] text-muted">
            Minimum withdrawal: {money(data.earnings.minWithdrawalCents)}. Payouts are reviewed by the admin team.
          </p>
          <Button full onClick={requestWithdrawal}>
            Submit request
          </Button>
        </div>
      </Sheet>
    </div>
  );
}
