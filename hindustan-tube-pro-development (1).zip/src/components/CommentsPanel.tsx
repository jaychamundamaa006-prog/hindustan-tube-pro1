"use client";

import { useCallback, useEffect, useState } from "react";
import Icon from "./Icon";
import { Avatar, Button, Skeleton, StateView } from "./ui";
import ReportDialog from "./ReportDialog";
import { timeAgo, compactNumber } from "@/lib/format";
import type { CommentNode } from "@/lib/queries";
import { requireSignIn } from "@/lib/client";

type Viewer = { id: number; name: string; avatarUrl: string | null; role: string } | null;

export default function CommentsPanel({
  videoId,
  viewer,
  dark = false,
}: {
  videoId: number;
  viewer: Viewer;
  dark?: boolean;
}) {
  const [items, setItems] = useState<CommentNode[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(false);
  const [sort, setSort] = useState<"top" | "new">("top");
  const [status, setStatus] = useState<"loading" | "ready" | "error">("loading");
  const [draft, setDraft] = useState("");
  const [replyTo, setReplyTo] = useState<CommentNode | null>(null);
  const [reportId, setReportId] = useState<number | null>(null);
  const [sending, setSending] = useState(false);

  const load = useCallback(
    async (nextPage: number, nextSort: "top" | "new", replace: boolean) => {
      setStatus(replace ? "loading" : status);
      try {
        const res = await fetch(`/api/comments?videoId=${videoId}&sort=${nextSort}&page=${nextPage}`);
        if (!res.ok) throw new Error();
        const data = await res.json();
        setItems((prev) => (replace ? data.comments : [...prev, ...data.comments]));
        setTotal(data.total);
        setHasMore(data.hasMore);
        setPage(nextPage);
        setStatus("ready");
      } catch {
        setStatus("error");
      }
    },
    [videoId, status],
  );

  useEffect(() => {
    void load(1, sort, true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [videoId, sort]);

  async function submit() {
    if (!viewer) {
      requireSignIn("Sign in to join the conversation and post comments.");
      return;
    }
    const body = draft.trim();
    if (!body) return;
    setSending(true);
    const res = await fetch("/api/comments", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ videoId, body, parentId: replyTo?.id ?? null }),
    });
    setSending(false);
    if (!res.ok) return;
    const data = await res.json();
    if (replyTo) {
      setItems((prev) =>
        prev.map((c) => (c.id === replyTo.id ? { ...c, replies: [...c.replies, data.comment] } : c)),
      );
    } else {
      setItems((prev) => [data.comment, ...prev]);
      setTotal((t) => t + 1);
    }
    setDraft("");
    setReplyTo(null);
  }

  async function likeComment(id: number) {
    if (!viewer) return requireSignIn("Sign in to like comments.");
    setItems((prev) =>
      prev.map((c) =>
        c.id === id
          ? { ...c, likeCount: c.likeCount + 1 }
          : { ...c, replies: c.replies.map((r) => (r.id === id ? { ...r, likeCount: r.likeCount + 1 } : r)) },
      ),
    );
    await fetch("/api/comments", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id, action: "like" }),
    });
  }

  async function removeComment(id: number) {
    await fetch(`/api/comments?id=${id}`, { method: "DELETE" });
    setItems((prev) =>
      prev.filter((c) => c.id !== id).map((c) => ({ ...c, replies: c.replies.filter((r) => r.id !== id) })),
    );
  }

  const textTone = dark ? "text-white" : "text-ink";
  const mutedTone = dark ? "text-white/60" : "text-muted";
  const fieldTone = dark ? "bg-white/10 text-white placeholder:text-white/40" : "bg-surface2";

  function Row({ node, depth = 0 }: { node: CommentNode; depth?: number }) {
    return (
      <div className={`flex gap-3 py-3 ${depth ? "pl-10" : ""}`}>
        <Avatar src={node.userAvatar} name={node.userName} size={depth ? 26 : 32} />
        <div className="min-w-0 flex-1">
          <p className={`text-[11px] ${mutedTone}`}>
            <span className={`font-semibold ${textTone}`}>{node.userName}</span> · {timeAgo(node.createdAt)}
          </p>
          <p className={`mt-0.5 whitespace-pre-wrap text-[13px] leading-relaxed ${textTone}`}>{node.body}</p>
          <div className={`mt-1.5 flex items-center gap-4 text-[11px] ${mutedTone}`}>
            <button onClick={() => likeComment(node.id)} className="flex items-center gap-1 hover:text-brand">
              <Icon name="like" size={14} /> {compactNumber(node.likeCount)}
            </button>
            {depth === 0 && (
              <button onClick={() => setReplyTo(node)} className="font-semibold hover:text-brand">
                Reply
              </button>
            )}
            {viewer && (viewer.id === node.userId || viewer.role === "admin") ? (
              <button onClick={() => removeComment(node.id)} className="hover:text-danger">
                Delete
              </button>
            ) : (
              <button onClick={() => setReportId(node.id)} className="hover:text-danger">
                Report
              </button>
            )}
          </div>
          {node.replies.map((r) => (
            <Row key={r.id} node={r} depth={depth + 1} />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="flex items-center justify-between">
        <h3 className={`text-sm font-bold ${textTone}`}>{compactNumber(total)} comments</h3>
        <button
          onClick={() => setSort(sort === "top" ? "new" : "top")}
          className={`flex items-center gap-1 text-xs font-semibold ${mutedTone}`}
        >
          <Icon name="filter" size={14} /> {sort === "top" ? "Top" : "Newest"}
        </button>
      </div>

      <div className={`mt-3 flex items-start gap-3 rounded-2xl p-3 ${fieldTone}`}>
        <Avatar src={viewer?.avatarUrl ?? null} name={viewer?.name ?? "Guest"} size={30} />
        <div className="flex-1">
          {replyTo && (
            <p className={`mb-1 text-[11px] ${mutedTone}`}>
              Replying to {replyTo.userName}{" "}
              <button onClick={() => setReplyTo(null)} className="font-semibold text-brand">
                cancel
              </button>
            </p>
          )}
          <textarea
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            placeholder={viewer ? "Add a comment…" : "Sign in to join the conversation"}
            rows={draft.length > 60 ? 3 : 1}
            className={`w-full resize-none bg-transparent text-sm outline-none ${textTone}`}
          />
        </div>
        <Button size="sm" onClick={submit} disabled={sending || !draft.trim()}>
          {sending ? "…" : "Post"}
        </Button>
      </div>

      {status === "loading" && (
        <div className="space-y-4 py-4">
          {Array.from({ length: 3 }).map((_, i) => (
            <div key={i} className="flex gap-3">
              <Skeleton className="h-8 w-8 rounded-full" />
              <div className="flex-1 space-y-2">
                <Skeleton className="h-3 w-1/3" />
                <Skeleton className="h-3 w-3/4" />
              </div>
            </div>
          ))}
        </div>
      )}

      {status === "error" && (
        <StateView
          tone="error"
          icon="wifi"
          title="Comments failed to load"
          action={<Button variant="outline" onClick={() => load(1, sort, true)}>Retry</Button>}
        />
      )}

      {status === "ready" && items.length === 0 && (
        <StateView icon="comment" title="No comments yet" message="Be the first to share what you think." />
      )}

      <div className="divide-y divide-line/40">
        {items.map((c) => (
          <Row key={c.id} node={c} />
        ))}
      </div>

      {hasMore && (
        <div className="py-3 text-center">
          <Button variant="outline" size="sm" onClick={() => load(page + 1, sort, false)}>
            Load more comments
          </Button>
        </div>
      )}

      <ReportDialog
        open={reportId !== null}
        onClose={() => setReportId(null)}
        targetType="comment"
        targetId={reportId ?? 0}
      />
    </div>
  );
}
