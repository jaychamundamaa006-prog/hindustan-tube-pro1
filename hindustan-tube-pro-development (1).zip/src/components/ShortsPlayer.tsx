"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import Icon from "./Icon";
import { Avatar, Sheet, StateView, Button } from "./ui";
import CommentsPanel from "./CommentsPanel";
import ReportDialog from "./ReportDialog";
import { compactNumber } from "@/lib/format";
import type { VideoCard } from "@/lib/queries";
import { requireSignIn } from "@/lib/client";

type Viewer = { id: number; name: string; avatarUrl: string | null; role: string } | null;

function ActionButton({
  icon,
  label,
  onClick,
  active,
  filled,
}: {
  icon: string;
  label?: string;
  onClick: () => void;
  active?: boolean;
  filled?: boolean;
}) {
  return (
    <button onClick={onClick} className="flex flex-col items-center gap-1 text-white active:scale-90">
      <span
        className={`grid h-11 w-11 place-items-center rounded-full backdrop-blur transition-colors ${
          active ? "bg-brand text-white" : "bg-white/15"
        }`}
      >
        <Icon name={icon} size={21} filled={filled && active} />
      </span>
      {label ? <span className="text-[10px] font-semibold drop-shadow">{label}</span> : null}
    </button>
  );
}

function ShortItem({
  short,
  viewer,
  active,
  subscribed,
  onToggleSub,
}: {
  short: VideoCard;
  viewer: Viewer;
  active: boolean;
  subscribed: boolean;
  onToggleSub: (channelId: number) => void;
}) {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const router = useRouter();
  const [liked, setLiked] = useState(false);
  const [likes, setLikes] = useState(short.likeCount);
  const [comments, setComments] = useState(false);
  const [report, setReport] = useState(false);
  const [muted, setMuted] = useState(true);
  const [expanded, setExpanded] = useState(false);
  const [failed, setFailed] = useState(false);
  const [viewed, setViewed] = useState(false);

  useEffect(() => {
    const el = videoRef.current;
    if (!el) return;
    if (active) {
      el.play().catch(() => undefined);
      if (!viewed) {
        setViewed(true);
        void fetch("/api/engage", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ action: "view", videoId: short.id }),
        });
      }
    } else {
      el.pause();
      el.currentTime = 0;
    }
  }, [active, short.id, viewed]);

  async function react() {
    if (!viewer) return requireSignIn("Sign in to like this short.");
    setLiked((v) => !v);
    setLikes((n) => (liked ? n - 1 : n + 1));
    await fetch("/api/engage", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "react", videoId: short.id, type: "like" }),
    });
  }

  return (
    <section className="snap-page relative h-[100dvh] w-full shrink-0 overflow-hidden bg-black">
      {failed ? (
        <div className="grid h-full place-items-center">
          <StateView tone="error" icon="wifi" title="Playback failed" message="This short couldn't be streamed." />
        </div>
      ) : (
        <video
          ref={videoRef}
          src={short.videoUrl}
          poster={short.thumbnailUrl}
          loop
          muted={muted}
          playsInline
          preload="metadata"
          onError={() => setFailed(true)}
          onClick={() => {
            const el = videoRef.current;
            if (!el) return;
            if (el.paused) void el.play();
            else el.pause();
          }}
          className="h-full w-full object-cover"
        />
      )}

      <div className="pointer-events-none absolute inset-x-0 bottom-0 h-2/5 bg-gradient-to-t from-black/85 to-transparent" />

      <div className="absolute right-3 bottom-28 flex flex-col items-center gap-4">
        <ActionButton icon="like" label={compactNumber(likes)} onClick={react} active={liked} filled />
        <ActionButton icon="comment" label={compactNumber(short.commentCount)} onClick={() => setComments(true)} />
        <ActionButton
          icon="share"
          label="Share"
          onClick={() => {
            const url = `${window.location.origin}/shorts?v=${short.id}`;
            if (navigator.share) void navigator.share({ title: short.title, url });
            else void navigator.clipboard.writeText(url);
          }}
        />
        <ActionButton
          icon="save"
          label="Save"
          onClick={() =>
            fetch("/api/engage", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ action: "watch-later", videoId: short.id }),
            })
          }
        />
        <ActionButton icon="flag" label="Report" onClick={() => setReport(true)} />
        <ActionButton icon={muted ? "mute" : "volume"} onClick={() => setMuted((m) => !m)} />
      </div>

      <div className="absolute inset-x-0 bottom-24 px-4 pr-20 text-white">
        <div className="flex items-center gap-2">
          <Link href={`/channel/${short.channelHandle}`} className="flex items-center gap-2">
            <Avatar src={short.channelAvatar} name={short.channelName} size={34} />
            <span className="text-sm font-semibold drop-shadow">@{short.channelHandle}</span>
          </Link>
          <button
            onClick={() => onToggleSub(short.channelId)}
            className={`rounded-full px-3 py-1 text-xs font-bold transition-colors ${
              subscribed ? "bg-white/20 text-white" : "bg-brand text-white"
            }`}
          >
            {subscribed ? "Following" : "Follow"}
          </button>
        </div>
        <p
          onClick={() => setExpanded((v) => !v)}
          className={`mt-2 text-[13px] leading-snug drop-shadow ${expanded ? "" : "line-clamp-2x"}`}
        >
          <span className="font-semibold">{short.title}</span>
          {short.description ? ` — ${short.description}` : ""}
        </p>
        <p className="mt-2 flex items-center gap-2 text-[11px] text-white/80">
          <Icon name="music" size={13} className="spin-slow" />
          <span className="truncate">{short.audioTitle ?? "Original audio"}</span>
        </p>
      </div>

      <Sheet open={comments} onClose={() => setComments(false)} title="Comments">
        <CommentsPanel videoId={short.id} viewer={viewer} />
      </Sheet>
      <ReportDialog open={report} onClose={() => setReport(false)} targetType="video" targetId={short.id} />
    </section>
  );
}

export default function ShortsPlayer({
  shorts,
  viewer,
  subscribedIds,
  startId,
}: {
  shorts: VideoCard[];
  viewer: Viewer;
  subscribedIds: number[];
  startId?: number;
}) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const [activeIndex, setActiveIndex] = useState(0);
  const [subs, setSubs] = useState<number[]>(subscribedIds);
  const router = useRouter();

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    if (startId) {
      const idx = shorts.findIndex((s) => s.id === startId);
      if (idx > 0) {
        el.scrollTo({ top: idx * el.clientHeight });
        setActiveIndex(idx);
      }
    }
    const onScroll = () => {
      const idx = Math.round(el.scrollTop / el.clientHeight);
      setActiveIndex(idx);
    };
    el.addEventListener("scroll", onScroll, { passive: true });
    return () => el.removeEventListener("scroll", onScroll);
  }, [shorts, startId]);

  async function toggleSub(channelId: number) {
    if (!viewer) return requireSignIn("Sign in to follow creators.");
    setSubs((prev) => (prev.includes(channelId) ? prev.filter((c) => c !== channelId) : [...prev, channelId]));
    await fetch("/api/engage", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "subscribe", channelId }),
    });
  }

  if (!shorts.length) {
    return (
      <div className="grid h-[100dvh] place-items-center bg-black">
        <StateView
          icon="shorts"
          title="No shorts yet"
          message="Vertical videos uploaded to the platform will appear here."
          action={<Button onClick={() => router.push("/upload")}>Create a short</Button>}
        />
      </div>
    );
  }

  return (
    <div className="relative">
      <div className="pointer-events-none absolute inset-x-0 top-0 z-20 flex items-center justify-between px-4 pt-4">
        <span className="pointer-events-auto text-lg font-bold text-white drop-shadow">Shorts</span>
        <Link href="/search" className="pointer-events-auto text-white">
          <Icon name="search" size={22} />
        </Link>
      </div>
      <div
        ref={containerRef}
        className="no-scrollbar snap-y-page h-[100dvh] overflow-y-scroll overscroll-contain"
      >
        {shorts.map((s, i) => (
          <ShortItem
            key={s.id}
            short={s}
            viewer={viewer}
            active={i === activeIndex}
            subscribed={subs.includes(s.channelId)}
            onToggleSub={toggleSub}
          />
        ))}
      </div>
    </div>
  );
}
