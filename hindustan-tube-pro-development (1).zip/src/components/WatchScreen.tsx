"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import VideoPlayer from "./VideoPlayer";
import CommentsPanel from "./CommentsPanel";
import ReportDialog from "./ReportDialog";
import Icon from "./Icon";
import VideoCard from "./VideoCard";
import { Avatar, Button, Sheet, Toggle } from "./ui";
import { compactNumber, timeAgo } from "@/lib/format";
import type { VideoCard as VideoCardType } from "@/lib/queries";
import { requireSignIn } from "@/lib/client";

type Viewer = { id: number; name: string; avatarUrl: string | null; role: string } | null;
type Playlist = { id: number; title: string; count: number; visibility: string };

function Action({
  icon,
  label,
  active,
  onClick,
}: {
  icon: string;
  label: string;
  active?: boolean;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={`flex shrink-0 items-center gap-1.5 rounded-full px-3.5 py-2 text-xs font-semibold transition-colors ${
        active ? "bg-brand text-white" : "bg-surface2 text-ink"
      }`}
    >
      <Icon name={icon} size={16} filled={active} /> {label}
    </button>
  );
}

export default function WatchScreen({
  video,
  related,
  viewer,
  initialReaction,
  initialSubscribed,
  startAt,
}: {
  video: VideoCardType;
  related: VideoCardType[];
  viewer: Viewer;
  initialReaction: string | null;
  initialSubscribed: boolean;
  startAt: number;
}) {
  const router = useRouter();
  const [reaction, setReaction] = useState(initialReaction);
  const [likes, setLikes] = useState(video.likeCount);
  const [dislikes, setDislikes] = useState(video.dislikeCount);
  const [subscribed, setSubscribed] = useState(initialSubscribed);
  const [subCount, setSubCount] = useState(video.subscriberCount);
  const [notify, setNotify] = useState(true);
  const [descOpen, setDescOpen] = useState(false);
  const [report, setReport] = useState(false);
  const [saveOpen, setSaveOpen] = useState(false);
  const [playlists, setPlaylists] = useState<Playlist[] | null>(null);
  const [autoplay, setAutoplay] = useState(true);
  const [toast, setToast] = useState("");

  useEffect(() => {
    void fetch("/api/engage", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "view", videoId: video.id }),
    });
  }, [video.id]);

  function flash(message: string) {
    setToast(message);
    setTimeout(() => setToast(""), 1800);
  }

  async function send(payload: Record<string, unknown>) {
    const res = await fetch("/api/engage", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    if (res.status === 401) return null; // AuthGate opens the sign-in sheet
    return res.json().catch(() => ({}));
  }

  async function react(type: "like" | "dislike") {
    if (!viewer) return requireSignIn("Sign in to rate this video.");
    const wasLiked = reaction === "like";
    const wasDisliked = reaction === "dislike";
    const next = reaction === type ? null : type;
    setReaction(next);
    setLikes(likes + (next === "like" ? 1 : 0) - (wasLiked ? 1 : 0));
    setDislikes(dislikes + (next === "dislike" ? 1 : 0) - (wasDisliked ? 1 : 0));
    await send({ action: "react", videoId: video.id, type });
  }

  async function openSave() {
    setSaveOpen(true);
    if (!playlists) {
      const res = await fetch("/api/playlists");
      if (res.status === 401) return;
      const data = await res.json();
      setPlaylists(data.playlists ?? []);
    }
  }

  return (
    <div className="pb-6">
      <VideoPlayer
        src={video.videoUrl}
        poster={video.thumbnailUrl}
        startAt={startAt}
        onProgress={(seconds) => send({ action: "progress", videoId: video.id, progressSec: seconds })}
        onEnded={() => {
          if (autoplay && related[0]) router.push(`/video/${related[0].id}`);
        }}
      />

      <div className="px-3 pt-3">
        <h1 className="text-[16px] font-bold leading-snug">{video.title}</h1>
        <button
          onClick={() => setDescOpen(true)}
          className="mt-1 flex items-center gap-1 text-xs text-muted"
        >
          {compactNumber(video.views)} views · {timeAgo(video.createdAt)} · #{video.category}
          <Icon name="chevronDown" size={14} />
        </button>

        <div className="no-scrollbar mt-3 flex gap-2 overflow-x-auto pb-1">
          <Action icon="like" label={compactNumber(likes)} active={reaction === "like"} onClick={() => react("like")} />
          <Action icon="dislike" label={compactNumber(dislikes)} active={reaction === "dislike"} onClick={() => react("dislike")} />
          <Action
            icon="share"
            label="Share"
            onClick={() => {
              const url = `${window.location.origin}/video/${video.id}`;
              if (navigator.share) void navigator.share({ title: video.title, url });
              else void navigator.clipboard.writeText(url);
              flash("Link copied to clipboard");
            }}
          />
          <Action icon="save" label="Save" onClick={openSave} />
          <Action
            icon="download"
            label="Download"
            onClick={async () => {
              const data = await send({ action: "download" });
              flash(data?.message ?? "Coming soon");
            }}
          />
          <Action icon="flag" label="Report" onClick={() => setReport(true)} />
        </div>

        <div className="mt-4 flex items-center gap-3 rounded-2xl bg-surface p-3">
          <Link href={`/channel/${video.channelHandle}`} className="flex min-w-0 flex-1 items-center gap-3">
            <Avatar src={video.channelAvatar} name={video.channelName} size={40} />
            <div className="min-w-0">
              <p className="flex items-center gap-1 truncate text-sm font-semibold">
                {video.channelName}
                {video.channelVerified && <Icon name="check" size={13} className="text-secondary" />}
              </p>
              <p className="text-xs text-muted">{compactNumber(subCount)} subscribers</p>
            </div>
          </Link>
          {subscribed && (
            <button
              onClick={async () => {
                setNotify(!notify);
                await send({ action: "notify", channelId: video.channelId, notify: !notify });
              }}
              className={`rounded-full p-2 ${notify ? "text-brand" : "text-muted"}`}
              aria-label="Notification preference"
            >
              <Icon name="bell" size={18} filled={notify} />
            </button>
          )}
          <Button
            size="sm"
            variant={subscribed ? "surface" : "primary"}
            onClick={async () => {
              if (!viewer) return requireSignIn("Sign in to subscribe and get upload alerts.");
              setSubscribed(!subscribed);
              setSubCount(subCount + (subscribed ? -1 : 1));
              await send({ action: "subscribe", channelId: video.channelId });
            }}
          >
            {subscribed ? "Subscribed" : "Subscribe"}
          </Button>
        </div>

        <div className="mt-4 rounded-2xl bg-surface p-4">
          <CommentsPanel videoId={video.id} viewer={viewer} />
        </div>

        <div className="mt-6 flex items-center justify-between">
          <h2 className="text-sm font-bold">Up next</h2>
          <label className="flex items-center gap-2 text-xs text-muted">
            Autoplay <Toggle checked={autoplay} onChange={setAutoplay} />
          </label>
        </div>
        <div className="mt-2 divide-y divide-line/50">
          {related.map((r) => (
            <VideoCard key={r.id} video={r} compact />
          ))}
        </div>
      </div>

      <Sheet open={descOpen} onClose={() => setDescOpen(false)} title="Description">
        <div className="space-y-3 text-sm">
          <div className="flex gap-4 text-center">
            <div className="flex-1 rounded-xl bg-surface2 py-3">
              <p className="text-base font-bold">{compactNumber(video.views)}</p>
              <p className="text-[11px] text-muted">Views</p>
            </div>
            <div className="flex-1 rounded-xl bg-surface2 py-3">
              <p className="text-base font-bold">{compactNumber(likes)}</p>
              <p className="text-[11px] text-muted">Likes</p>
            </div>
            <div className="flex-1 rounded-xl bg-surface2 py-3">
              <p className="text-base font-bold">{timeAgo(video.createdAt)}</p>
              <p className="text-[11px] text-muted">Published</p>
            </div>
          </div>
          <p className="whitespace-pre-wrap leading-relaxed text-muted">{video.description}</p>
          <div className="flex flex-wrap gap-2">
            {video.tags.map((t) => (
              <span key={t} className="rounded-full bg-surface2 px-2.5 py-1 text-[11px] text-secondary">
                #{t}
              </span>
            ))}
          </div>
        </div>
      </Sheet>

      <Sheet open={saveOpen} onClose={() => setSaveOpen(false)} title="Save to playlist">
        <div className="space-y-1">
          <button
            onClick={async () => {
              const data = await send({ action: "watch-later", videoId: video.id });
              flash(data?.message ?? "Saved");
              setSaveOpen(false);
            }}
            className="flex w-full items-center gap-3 rounded-xl px-3 py-3 text-sm font-medium hover:bg-surface2"
          >
            <Icon name="clock" size={18} /> Watch Later
          </button>
          {(playlists ?? []).map((p) => (
            <button
              key={p.id}
              onClick={async () => {
                await fetch("/api/playlists", {
                  method: "POST",
                  headers: { "Content-Type": "application/json" },
                  body: JSON.stringify({ action: "add", playlistId: p.id, videoId: video.id }),
                });
                flash(`Added to ${p.title}`);
                setSaveOpen(false);
              }}
              className="flex w-full items-center gap-3 rounded-xl px-3 py-3 text-sm font-medium hover:bg-surface2"
            >
              <Icon name={p.visibility === "private" ? "lock" : "list"} size={18} /> {p.title}
              <span className="ml-auto text-xs text-muted">{p.count}</span>
            </button>
          ))}
          <Link href="/library" className="flex w-full items-center gap-3 rounded-xl px-3 py-3 text-sm font-semibold text-brand hover:bg-surface2">
            <Icon name="plus" size={18} /> Create new playlist
          </Link>
        </div>
      </Sheet>

      <ReportDialog open={report} onClose={() => setReport(false)} targetType="video" targetId={video.id} />

      {toast && (
        <div className="fixed bottom-24 left-1/2 z-[90] -translate-x-1/2 rounded-full bg-ink px-4 py-2 text-xs font-medium text-bg shadow-xl">
          {toast}
        </div>
      )}
    </div>
  );
}
