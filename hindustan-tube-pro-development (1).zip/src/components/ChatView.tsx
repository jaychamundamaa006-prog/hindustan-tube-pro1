"use client";

import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import Icon from "./Icon";

const EMAIL_ICON = "envelope"; // placeholder for missing send icon
import { Avatar, Button, Sheet, Spinner } from "./ui";
import { timeAgo } from "@/lib/format";
import type { Message } from "@/db/schema";

export type MessageRow = {
  id: number;
  chatId: number;
  senderId: number;
  senderName: string | null;
  senderAvatar: string | null;
  type: string;
  body: string | null;
  mediaUrl: string | null;
  videoId: number | null;
  videoTitle: string | null;
  videoThumbnail: string | null;
  replyToId: number | null;
  deletedAt: string | null;
  createdAt: string | Date;
  readAt: string | null;
};

export default function ChatView({
  chatId,
  title,
  subtitle,
  photoUrl,
  messages: initialMessages,
  viewer,
  onShare,
}: {
  chatId: number;
  title: string;
  subtitle?: string;
  photoUrl?: string | null;
  messages: MessageRow[];
  viewer: { id: number; name: string; avatarUrl: string | null };
  onShare?: (chatId: number) => void;
}) {
  const scrollRef = useRef<HTMLDivElement | null>(null);
  const inputRef = useRef<HTMLTextAreaElement | null>(null);
  const [messages, setMessages] = useState(initialMessages);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);
  const [loading, setLoading] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [replyTo, setReplyTo] = useState<MessageRow | null>(null);
  const [deleted, setDeleted] = useState<Set<number>>(new Set());

  useEffect(() => {
    scrollRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  async function send() {
    if (!input.trim() || sending) return;
    setSending(true);
    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "send-direct",
          chatId,
          text: input,
          replyToId: replyTo?.id,
        }),
      });
      if (res.ok) {
        setInput("");
        setReplyTo(null);
        // Optimistically add to UI
        const now = new Date().toISOString();
        setMessages((prev) => [
          ...prev,
          {
            id: Math.random(),
            chatId,
            senderId: viewer.id,
            senderName: viewer.name,
            senderAvatar: viewer.avatarUrl,
            type: "text",
            body: input,
            mediaUrl: null,
            videoId: null,
            videoTitle: null,
            videoThumbnail: null,
            replyToId: replyTo?.id ?? null,
            deletedAt: null,
            createdAt: now,
            readAt: now,
          },
        ]);
        // Refresh in background
        const list = await fetch(`/api/chat?mode=messages&chatId=${chatId}&limit=1`);
        if (list.ok) {
          const data = await list.json();
          setMessages((prev) => {
            const latest = data.messages[0];
            return prev.some((m) => m.id === latest.id) ? prev : [latest, ...prev];
          });
        }
      }
    } finally {
      setSending(false);
    }
  }

  async function deleteMessage(id: number) {
    await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "delete", messageId: id }),
    });
    setDeleted((prev) => new Set([...prev, id]));
  }

  const grouped = messages.reduce(
    (acc, msg) => {
      const date = new Date(msg.createdAt).toLocaleDateString();
      if (!acc[date]) acc[date] = [];
      acc[date].push(msg);
      return acc;
    },
    {} as Record<string, MessageRow[]>,
  );

  return (
    <div className="flex h-[100dvh] flex-col overflow-hidden bg-bg">
      <div className="border-b border-line bg-surface p-3 sm:p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3 min-w-0">
            <Avatar src={photoUrl} name={title} size={40} />
            <div className="min-w-0">
              <p className="truncate text-sm font-semibold">{title}</p>
              {subtitle && <p className="truncate text-[11px] text-muted">{subtitle}</p>}
            </div>
          </div>
          <button
            onClick={() => setMenuOpen(true)}
            className="rounded-full p-2 text-muted hover:bg-surface2"
          >
            <Icon name="more" size={18} />
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto space-y-3 px-3 py-4 sm:px-4">
        {Object.entries(grouped).map(([date, msgs]) => (
          <div key={date}>
            <div className="flex items-center justify-center gap-2 py-2">
              <span className="h-px flex-1 bg-line" />
              <span className="text-[10px] text-muted">{date}</span>
              <span className="h-px flex-1 bg-line" />
            </div>
            <div className="space-y-2">
              {msgs.map((msg) => {
                const isOwn = msg.senderId === viewer.id;
                if (deleted.has(msg.id)) return null;
                return (
                  <div
                    key={msg.id}
                    className={`flex gap-2 ${isOwn ? "flex-row-reverse" : ""}`}
                  >
                    <Avatar src={msg.senderAvatar} name={msg.senderName || "?"} size={28} />
                    <div className={`flex flex-col gap-1 max-w-xs ${isOwn ? "items-end" : ""}`}>
                      {msg.replyToId && (
                        <div className="rounded-lg bg-surface2 px-2.5 py-1.5 text-[11px] text-muted border-l-2 border-brand">
                          <p className="font-semibold">Replying to message</p>
                        </div>
                      )}
                      {msg.type === "text" && (
                        <div
                          className={`rounded-2xl px-3.5 py-2.5 text-[13px] leading-relaxed break-words ${
                            isOwn ? "bg-brand text-white" : "bg-surface2 text-ink"
                          }`}
                        >
                          {msg.body}
                        </div>
                      )}
                      {msg.type === "video_share" && (
                        <Link
                          href={`/video/${msg.videoId}`}
                          className="rounded-2xl overflow-hidden bg-surface2 hover:opacity-80 transition-opacity w-full max-w-xs"
                        >
                          {msg.videoThumbnail && (
                            // eslint-disable-next-line @next/next/no-img-element
                            <img
                              src={msg.videoThumbnail}
                              alt={msg.videoTitle || "Video"}
                              className="w-full aspect-video object-cover"
                            />
                          )}
                          <div className="p-2.5">
                            <p className="line-clamp-2x text-[12px] font-semibold text-ink">{msg.videoTitle}</p>
                            {msg.body && (
                              <p className="mt-1 text-[11px] text-muted">{msg.body}</p>
                            )}
                            <Link href={`/video/${msg.videoId}`} className="block mt-2">
                              <Button size="sm" className="w-full">
                                <Icon name="play" size={14} /> Open video
                              </Button>
                            </Link>
                          </div>
                        </Link>
                      )}
                      <div className={`flex items-center gap-1.5 text-[10px] text-muted ${isOwn ? "flex-row-reverse" : ""}`}>
                        <span>{timeAgo(msg.createdAt)}</span>
                        {isOwn && msg.readAt && (
                          <span title="Read">
                            <Icon name="check" size={12} className="text-brand" />
                          </span>
                        )}
                        {isOwn && (
                          <button
                            onClick={() => deleteMessage(msg.id)}
                            className="hover:text-danger"
                            title="Delete"
                          >
                            <Icon name="trash" size={12} />
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        ))}
        <div ref={scrollRef} />
      </div>

      <div className="border-t border-line bg-surface p-3 sm:p-4 space-y-2">
        {replyTo && (
          <div className="flex items-center justify-between rounded-lg bg-surface2 px-3 py-2 text-[11px]">
            <span className="text-muted">
              Replying to <b>{replyTo.senderName}</b>
            </span>
            <button onClick={() => setReplyTo(null)} className="text-muted hover:text-ink">
              <Icon name="close" size={14} />
            </button>
          </div>
        )}
        <div className="flex items-end gap-2">
          <div className="flex-1 flex items-center gap-2 rounded-2xl border border-line bg-surface2 px-3 py-2">
            <textarea
              ref={inputRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  void send();
                }
              }}
              placeholder="Type a message…"
              rows={1}
              className="flex-1 bg-transparent text-sm outline-none resize-none max-h-24"
            />
            <button className="text-muted hover:text-brand">
              <Icon name="smile" size={18} />
            </button>
          </div>
          <button
            onClick={() => void send()}
            disabled={sending || !input.trim()}
            className="grid h-10 w-10 place-items-center rounded-full bg-brand text-white disabled:opacity-50"
          >
            {sending ? <Spinner size={18} /> : <span className="text-lg">↳</span>}
          </button>
        </div>
      </div>

      <Sheet open={menuOpen} onClose={() => setMenuOpen(false)} title="Chat options">
        <div className="space-y-1">
          {onShare && (
            <button
              onClick={() => {
                onShare(chatId);
                setMenuOpen(false);
              }}
              className="flex w-full items-center gap-3 rounded-xl px-3 py-3 text-sm font-medium hover:bg-surface2"
            >
              <span className="text-lg">↳</span> Share video
            </button>
          )}
          <button className="flex w-full items-center gap-3 rounded-xl px-3 py-3 text-sm font-medium hover:bg-surface2">
            <Icon name="bell" size={18} /> Mute notifications
          </button>
          <button className="flex w-full items-center gap-3 rounded-xl px-3 py-3 text-sm font-medium hover:bg-surface2 text-danger">
            <Icon name="trash" size={18} /> Clear chat
          </button>
        </div>
      </Sheet>
    </div>
  );
}
