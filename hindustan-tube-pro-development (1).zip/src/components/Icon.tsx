import type { SVGProps } from "react";

const PATHS: Record<string, string> = {
  home: "M3 10.5 12 3l9 7.5M5.5 9.5V20a1 1 0 0 0 1 1H10v-6h4v6h3.5a1 1 0 0 0 1-1V9.5",
  shorts: "M10 8.5v7l6-3.5-6-3.5ZM7 4h10a3 3 0 0 1 3 3v10a3 3 0 0 1-3 3H7a3 3 0 0 1-3-3V7a3 3 0 0 1 3-3Z",
  plus: "M12 5v14M5 12h14",
  subs: "M4 7h16M6 11h12M4 15h16v4a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1v-4Z",
  library: "M4 6h10M4 10h10M4 14h7M16 8l5 3-5 3V8Z",
  search: "M11 19a8 8 0 1 1 0-16 8 8 0 0 1 0 16Zm10 2-4.5-4.5",
  bell: "M18 8a6 6 0 1 0-12 0c0 6-2 7-2 7h16s-2-1-2-7ZM10.5 20a2 2 0 0 0 3 0",
  user: "M20 21a8 8 0 0 0-16 0M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8Z",
  like: "M7 22V10l5-8 1 .5A3 3 0 0 1 14.6 6L14 9h5.5a2 2 0 0 1 2 2.4l-1.6 8A2 2 0 0 1 18 21H7ZM7 10H3v11h4",
  dislike: "M17 2v12l-5 8-1-.5A3 3 0 0 1 9.4 18L10 15H4.5a2 2 0 0 1-2-2.4l1.6-8A2 2 0 0 1 6 3h11ZM17 14h4V3h-4",
  comment: "M21 12a8 8 0 0 1-8 8H4l2-3a8 8 0 1 1 15-5Z",
  share: "M4 12v7a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-7M12 16V3m0 0L8 7m4-4 4 4",
  save: "M6 3h12a1 1 0 0 1 1 1v17l-7-4-7 4V4a1 1 0 0 1 1-1Z",
  download: "M12 3v12m0 0-4-4m4 4 4-4M4 21h16",
  flag: "M5 21V4m0 0h11l-2 4 2 4H5",
  more: "M12 6.5h.01M12 12h.01M12 17.5h.01",
  settings: "M12 15.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7Zm8-3.5-.2 1.4 1.7 1.6-1.6 2.8-2.2-.7-1.2.8-.5 2.2h-3.2l-.5-2.2-1.2-.8-2.2.7L7.3 15 9 13.4 8.8 12 9 10.6 7.3 9l1.6-2.8 2.2.7 1.2-.8.5-2.2h3.2l.5 2.2 1.2.8 2.2-.7L21.5 9 19.8 10.6 20 12Z",
  chevronRight: "m9 5 7 7-7 7",
  chevronLeft: "m15 5-7 7 7 7",
  chevronDown: "m6 9 6 6 6-6",
  play: "M7 4.5v15l13-7.5-13-7.5Z",
  pause: "M8 4.5v15M16 4.5v15",
  volume: "M5 9v6h4l5 4V5L9 9H5Z",
  mute: "M5 9v6h4l5 4V5L9 9H5ZM17 9l4 6M21 9l-4 6",
  fullscreen: "M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5",
  back: "M20 12H4m0 0 6-6m-6 6 6 6",
  close: "M6 6l12 12M18 6 6 18",
  check: "m4 12 5 5L20 6",
  trash: "M4 7h16M9 7V4h6v3m-8 0 1 14h8l1-14",
  edit: "M4 20h4L20 8l-4-4L4 16v4Z",
  upload: "M12 20V7m0 0-5 5m5-5 5 5M4 4h16",
  chart: "M4 20V10M10 20V4M16 20v-7M22 20H2",
  shield: "M12 3 4 6v6c0 5 3.5 8 8 9 4.5-1 8-4 8-9V6l-8-3Z",
  money: "M12 3v18M8 7h6a3 3 0 0 1 0 6H8m0 0h6a3 3 0 0 1 0 6H8",
  sun: "M12 17a5 5 0 1 0 0-10 5 5 0 0 0 0 10ZM12 1v2M12 21v2M4.2 4.2l1.4 1.4M18.4 18.4l1.4 1.4M1 12h2M21 12h2M4.2 19.8l1.4-1.4M18.4 5.6l1.4-1.4",
  moon: "M21 13A9 9 0 1 1 11 3a7 7 0 0 0 10 10Z",
  filter: "M3 5h18M6 12h12M10 19h4",
  clock: "M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18ZM12 7v5l3 2",
  list: "M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01",
  forward10: "M12 5V2l4 3-4 3V6a6 6 0 1 0 6 6",
  back10: "M12 5V2L8 5l4 3V6a6 6 0 1 1-6 6",
  verified: "m12 2 2.4 2.1 3.2-.3.7 3.1 2.7 1.7-1.4 2.9 1.4 2.9-2.7 1.7-.7 3.1-3.2-.3L12 21l-2.4-2.1-3.2.3-.7-3.1L3 14.4l1.4-2.9L3 8.6l2.7-1.7.7-3.1 3.2.3L12 2Z",
  speed: "M12 20a8 8 0 1 1 8-8M12 12l4-3",
  cc: "M3 6h18v12H3zM9 10.5a2 2 0 1 0 0 3M17 10.5a2 2 0 1 0 0 3",
  pip: "M3 5h18v14H3zM12 12h7v5h-7z",
  logout: "M15 4h4a1 1 0 0 1 1 1v14a1 1 0 0 1-1 1h-4M10 8l-4 4 4 4M6 12h11",
  users: "M16 20a5 5 0 0 0-10 0M11 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8ZM22 20a4 4 0 0 0-5-3.9M17.5 11.5a3 3 0 0 0 0-6",
  eye: "M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7Zm10 3a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z",
  video: "M3 7a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7Zm12 4 6-4v10l-6-4",
  music: "M9 18V5l11-2v13M9 18a3 3 0 1 1-6 0 3 3 0 0 1 6 0Zm11-2a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z",
  refresh: "M20 11A8 8 0 0 0 6.3 6.3L4 8.5M4 5v3.5H7.5M4 13a8 8 0 0 0 13.7 4.7L20 15.5M20 19v-3.5h-3.5",
  wifi: "M2 8.5a15 15 0 0 1 20 0M5 12.5a10 10 0 0 1 14 0M8.5 16.2a5 5 0 0 1 7 0M12 20h.01",
  sparkle: "M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8L12 3Z",
  grid: "M4 4h7v7H4zM13 4h7v7h-7zM4 13h7v7H4zM13 13h7v7h-7z",
  lock: "M6 11h12v9H6zM9 11V8a3 3 0 0 1 6 0v3",
  globe: "M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18ZM3 12h18M12 3c2.5 2.5 3.5 5.7 3.5 9S14.5 18.5 12 21c-2.5-2.5-3.5-5.7-3.5-9S9.5 5.5 12 3Z",
  help: "M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18ZM9.5 9.5a2.5 2.5 0 1 1 3.4 2.3c-.6.3-.9.8-.9 1.5v.2M12 17h.01",
  info: "M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18ZM12 11v5M12 7.5h.01",
  bookmark: "M6 3h12a1 1 0 0 1 1 1v17l-7-4-7 4V4a1 1 0 0 1 1-1Z",
};

type Props = SVGProps<SVGSVGElement> & {
  name: keyof typeof PATHS | string;
  size?: number;
  filled?: boolean;
};

export default function Icon({ name, size = 22, filled = false, ...rest }: Props) {
  const d = PATHS[name] ?? PATHS.info;
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill={filled ? "currentColor" : "none"}
      stroke="currentColor"
      strokeWidth={filled ? 0 : 1.7}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
      {...rest}
    >
      <path d={d} />
    </svg>
  );
}
