"use client";

import Link from "next/link";
import { useState } from "react";
import Icon from "./Icon";
import { Avatar, Sheet } from "./ui";
import { compactNumber, formatDuration, timeAgo } from "@/lib/format";
import type { VideoCard as VideoCardType } from "@/lib/queries";
import ReportDialog from "./ReportDialog";

export function Thumb({
  src,
  alt,
  duration,
  progress,
  className = "",
}: {
  src: string;
  alt: string;
  duration?: number;
  progress?: number;
  className?: string;
}) {
  return (
    <div className={`relative overflow-hidden rounded-2xl bg-surface2 ${className}`}>
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img
        src={src}
        alt={alt}
        loading="lazy"
        decoding="async"
        className="h-full w-full object-cover transition-transform duration-500 hover:scale-105"
      />
      {duration ? (
        <span className="absolute bottom-1.5 right-1.5 rounded-md bg-black/80 px-1.5 py-0.5 text-[11px] font-semibold text-white">
          {formatDuration(duration)}
        </span>
      ) : null}
      {progress && duration ? (
        <span className="absolute bottom-0 left-0 h-1 bg-brand" style={{ width: `${Math.min(100, (progress / duration) * 100)}%` }} />
      ) : null}
    </div>
  );
}

export default function VideoCard({
  video,
  progress,
  compact = false,
}: {
  video: VideoCardType;
  progress?: number;
  compact?: boolean;
}) {
  const [menu, setMenu] = useState(false);
  const [report, setReport] = useState(false);
  const [toast, setToast] = useState("");

  async function quickAction(action: string) {
    setMenu(false);
    const res = await fetch("/api/engage", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action, videoId: video.id }),
    });
    if (res.status === 401) return; // AuthGate opens the sign-in sheet
    const data = await res.json().catch(() => ({}));
    setToast(data.message ?? "Done");
    setTimeout(() => setToast(""), 1800);
  }

  if (compact) {
    return (
      <Link href={`/video/${video.id}`} className="flex gap-3 py-2">
        <Thumb src={video.thumbnailUrl} alt={video.title} duration={video.durationSec} className="aspect-video w-40 shrink-0" />
        <div className="min-w-0 flex-1">
          <p className="line-clamp-2x text-[13px] font-semibold leading-snug">{video.title}</p>
          <p className="mt-1 truncate text-[11px] text-muted">{video.channelName}</p>
          <p className="text-[11px] text-muted">
            {compactNumber(video.views)} views · {timeAgo(video.createdAt)}
          </p>
        </div>
      </Link>
    );
  }

  return (
    <article className="fade-up">
      <Link href={`/video/${video.id}`}>
        <Thumb
          src={video.thumbnailUrl}
          alt={video.title}
          duration={video.durationSec}
          progress={progress}
          className="aspect-video w-full sm:rounded-2xl"
        />
      </Link>
      <div className="flex gap-3 px-1 pt-3">
        <Link href={`/channel/${video.channelHandle}`}>
          <Avatar src={video.channelAvatar} name={video.channelName} size={36} />
        </Link>
        <Link href={`/video/${video.id}`} className="min-w-0 flex-1">
          <h3 className="line-clamp-2x text-[14px] font-semibold leading-snug">{video.title}</h3>
          <p className="mt-1 flex items-center gap-1 truncate text-xs text-muted">
            {video.channelName}
            {video.channelVerified && <Icon name="check" size={12} className="text-secondary" />}
          </p>
          <p className="text-xs text-muted">
            {compactNumber(video.views)} views · {timeAgo(video.createdAt)}
          </p>
        </Link>
        <button
          onClick={() => setMenu(true)}
          aria-label="More options"
          className="h-8 w-8 shrink-0 rounded-full text-muted hover:bg-surface2"
        >
          <Icon name="more" size={18} className="mx-auto" />
        </button>
      </div>

      <Sheet open={menu} onClose={() => setMenu(false)} title={video.title}>
        <div className="space-y-1">
          <MenuItem icon="clock" label="Save to Watch Later" onClick={() => quickAction("watch-later")} />
          <MenuItem icon="bookmark" label="Save to Liked videos" onClick={() => quickAction("like")} />
          <MenuItem
            icon="share"
            label="Share"
            onClick={() => {
              setMenu(false);
              const url = `${window.location.origin}/video/${video.id}`;
              if (navigator.share) void navigator.share({ title: video.title, url });
              else void navigator.clipboard.writeText(url);
              setToast("Link copied");
              setTimeout(() => setToast(""), 1600);
            }}
          />
          <MenuItem icon="download" label="Download (offline soon)" onClick={() => quickAction("download")} />
          <MenuItem
            icon="flag"
            label="Report"
            onClick={() => {
              setMenu(false);
              setReport(true);
            }}
          />
        </div>
      </Sheet>

      <ReportDialog open={report} onClose={() => setReport(false)} targetType="video" targetId={video.id} />

      {toast ? (
        <div className="fixed bottom-24 left-1/2 z-[90] -translate-x-1/2 rounded-full bg-ink px-4 py-2 text-xs font-medium text-bg shadow-xl">
          {toast}
        </div>
      ) : null}
    </article>
  );
}

export function MenuItem({
  icon,
  label,
  onClick,
}: {
  icon: string;
  label: string;
  onClick?: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className="flex w-full items-center gap-3 rounded-xl px-3 py-3 text-left text-sm font-medium hover:bg-surface2"
    >
      <Icon name={icon} size={19} className="text-muted" />
      {label}
    </button>
  );
}
