"use client";

import { useEffect, useState } from "react";
import Icon from "./Icon";

export function useTheme() {
  const [dark, setDark] = useState(true);
  useEffect(() => {
    setDark(document.documentElement.classList.contains("dark"));
  }, []);
  const toggle = () => {
    const next = !document.documentElement.classList.contains("dark");
    document.documentElement.classList.toggle("dark", next);
    try {
      localStorage.setItem("htp-theme", next ? "dark" : "light");
    } catch {
      /* ignore */
    }
    setDark(next);
  };
  return { dark, toggle };
}

export default function ThemeToggle({ compact = false }: { compact?: boolean }) {
  const { dark, toggle } = useTheme();
  return (
    <button
      onClick={toggle}
      aria-label="Toggle theme"
      className={`grid place-items-center rounded-full text-ink transition-colors hover:bg-surface2 ${
        compact ? "h-9 w-9" : "h-10 w-10"
      }`}
    >
      <Icon name={dark ? "sun" : "moon"} size={20} />
    </button>
  );
}
