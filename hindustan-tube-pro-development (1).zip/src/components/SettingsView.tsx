"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import Icon from "./Icon";
import { Avatar, Button, Sheet, Toggle } from "./ui";
import { useTheme } from "./ThemeToggle";

type Props = {
  user: {
    name: string;
    username: string;
    email: string;
    phone: string | null;
    avatarUrl: string | null;
    role: string;
    verified: boolean;
    channelHandle: string | null;
  };
};

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="mb-4">
      <h2 className="mb-2 px-1 text-[11px] font-bold uppercase tracking-wide text-muted">{title}</h2>
      <div className="divide-y divide-line/60 overflow-hidden rounded-2xl bg-surface">{children}</div>
    </div>
  );
}

function Row({
  icon,
  label,
  value,
  onClick,
  right,
}: {
  icon: string;
  label: string;
  value?: string;
  onClick?: () => void;
  right?: React.ReactNode;
}) {
  return (
    <div
      onClick={onClick}
      className={`flex items-center gap-3 px-4 py-3.5 ${onClick ? "cursor-pointer hover:bg-surface2" : ""}`}
    >
      <Icon name={icon} size={18} className="text-muted" />
      <span className="flex-1 text-sm font-medium">{label}</span>
      {value ? <span className="text-xs text-muted">{value}</span> : null}
      {right ?? (onClick ? <Icon name="chevronRight" size={15} className="text-muted" /> : null)}
    </div>
  );
}

export default function SettingsView({ user }: Props) {
  const router = useRouter();
  const { dark, toggle } = useTheme();
  const [prefs, setPrefs] = useState({
    uploads: true,
    replies: true,
    likes: false,
    autoplay: true,
    dataSaver: false,
    hd: true,
    privateHistory: false,
    twoFactor: false,
  });
  const [sheet, setSheet] = useState<string | null>(null);
  const [language, setLanguage] = useState("English (India)");

  const setPref = (k: keyof typeof prefs) => (v: boolean) => setPrefs({ ...prefs, [k]: v });

  async function logout() {
    await fetch("/api/auth", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "logout" }),
    });
    router.replace("/login");
    router.refresh();
  }

  return (
    <div className="px-3 py-4">
      <div className="mb-5 flex items-center gap-3 rounded-2xl bg-surface p-4">
        <Avatar src={user.avatarUrl} name={user.name} size={56} ring />
        <div className="min-w-0 flex-1">
          <p className="flex items-center gap-1 truncate text-base font-bold">
            {user.name}
            {user.verified && <Icon name="check" size={14} className="text-secondary" />}
          </p>
          <p className="truncate text-xs text-muted">
            @{user.username} · {user.email}
          </p>
          <span className="mt-1 inline-block rounded-full bg-brand/15 px-2 py-0.5 text-[10px] font-bold uppercase text-brand">
            {user.role}
          </span>
        </div>
      </div>

      <Section title="Account">
        <Row icon="user" label="Profile & channel" onClick={() => router.push(`/channel/${user.channelHandle ?? user.username}`)} />
        <Row icon="chart" label="Creator Studio" onClick={() => router.push("/studio")} />
        <Row icon="globe" label="Phone" value={user.phone ?? "Not linked"} onClick={() => setSheet("phone")} />
        {user.role === "admin" && <Row icon="shield" label="Admin console" onClick={() => router.push("/admin")} />}
      </Section>

      <Section title="Appearance">
        <Row
          icon={dark ? "moon" : "sun"}
          label="Dark theme"
          right={<Toggle checked={dark} onChange={toggle} />}
        />
        <Row icon="globe" label="Language" value={language} onClick={() => setSheet("language")} />
      </Section>

      <Section title="Notifications">
        <Row icon="video" label="New uploads" right={<Toggle checked={prefs.uploads} onChange={setPref("uploads")} />} />
        <Row icon="comment" label="Replies & comments" right={<Toggle checked={prefs.replies} onChange={setPref("replies")} />} />
        <Row icon="like" label="Likes on my content" right={<Toggle checked={prefs.likes} onChange={setPref("likes")} />} />
      </Section>

      <Section title="Playback">
        <Row icon="play" label="Autoplay next video" right={<Toggle checked={prefs.autoplay} onChange={setPref("autoplay")} />} />
        <Row icon="wifi" label="Data saver" right={<Toggle checked={prefs.dataSaver} onChange={setPref("dataSaver")} />} />
        <Row icon="video" label="Prefer HD on Wi-Fi" right={<Toggle checked={prefs.hd} onChange={setPref("hd")} />} />
      </Section>

      <Section title="Privacy & security">
        <Row icon="eye" label="Keep watch history private" right={<Toggle checked={prefs.privateHistory} onChange={setPref("privateHistory")} />} />
        <Row icon="lock" label="Two-step verification" right={<Toggle checked={prefs.twoFactor} onChange={setPref("twoFactor")} />} />
        <Row icon="trash" label="Clear watch history" onClick={async () => {
          await fetch("/api/engage", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ action: "history-clear" }),
          });
          setSheet("cleared");
        }} />
      </Section>

      <Section title="Support">
        <Row icon="help" label="Help & support" onClick={() => setSheet("help")} />
        <Row icon="info" label="About Hindustan Tube Pro" onClick={() => setSheet("about")} />
        <Row icon="shield" label="Community guidelines" onClick={() => setSheet("about")} />
      </Section>

      <Button full variant="danger" onClick={logout}>
        <Icon name="logout" size={16} /> Log out
      </Button>
      <p className="mt-4 text-center text-[11px] text-muted">Hindustan Tube Pro · v1.0.0 · Made in India</p>

      <Sheet open={sheet === "language"} onClose={() => setSheet(null)} title="Language">
        <div className="space-y-1">
          {["English (India)", "हिन्दी", "বাংলা", "தமிழ்", "తెలుగు", "मराठी"].map((l) => (
            <button
              key={l}
              onClick={() => {
                setLanguage(l);
                setSheet(null);
              }}
              className="flex w-full items-center justify-between rounded-xl px-3 py-3 text-sm hover:bg-surface2"
            >
              {l}
              {language === l && <Icon name="check" size={16} className="text-brand" />}
            </button>
          ))}
        </div>
      </Sheet>

      <Sheet open={sheet === "help"} onClose={() => setSheet(null)} title="Help & support">
        <div className="space-y-3 text-sm text-muted">
          <p>Need a hand? Our support desk replies within 24 hours.</p>
          <Row icon="comment" label="Chat with support" />
          <Row icon="flag" label="Report a problem" />
          <Link href="/admin" className="block text-xs font-semibold text-brand">
            Platform status
          </Link>
        </div>
      </Sheet>

      <Sheet open={sheet === "about"} onClose={() => setSheet(null)} title="About">
        <div className="space-y-2 text-sm text-muted">
          <p>
            <b className="text-ink">Hindustan Tube Pro</b> is an original video sharing platform for
            long-form videos and vertical shorts, built with a creator-first monetization framework.
          </p>
          <p>Version 1.0.0 · Build 100 · © {new Date().getFullYear()} Hindustan Tube Labs</p>
        </div>
      </Sheet>

      <Sheet open={sheet === "phone"} onClose={() => setSheet(null)} title="Linked phone">
        <p className="py-4 text-sm text-muted">
          {user.phone ? `Your account is linked to ${user.phone}.` : "No phone number is linked yet. Sign in with phone OTP to link one."}
        </p>
      </Sheet>

      <Sheet open={sheet === "cleared"} onClose={() => setSheet(null)} title="History cleared">
        <p className="py-4 text-sm text-success">Your watch history has been cleared from this account.</p>
      </Sheet>
    </div>
  );
}
