"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import Icon from "./Icon";
import { Button } from "./ui";
import { Logo } from "./AppChrome";
import ThemeToggle from "./ThemeToggle";
import { compactNumber, money, timeAgo } from "@/lib/format";
import type { MonetizationConfig } from "@/lib/settings";

type Stats = {
  users: number;
  activeUsers: number;
  videos: number;
  shorts: number;
  views: number;
  likes: number;
  comments: number;
  subscriptions: number;
  openReports: number;
  revenueCents: number;
  pendingCents: number;
};

type UserRow = {
  id: number;
  name: string;
  username: string;
  email: string;
  role: string;
  status: string;
  verified: boolean;
};

type VideoRow = {
  id: number;
  title: string;
  status: string;
  visibility: string;
  views: number;
  thumbnailUrl: string;
  isShort: boolean;
  channelName: string;
};

type ReportRow = {
  id: number;
  targetType: string;
  targetId: number;
  category: string;
  note: string;
  status: string;
  createdAt: string;
  reporter: string | null;
};

type WithdrawalRow = {
  id: number;
  amountCents: number;
  status: string;
  method: string;
  account: string;
  requestedAt: string;
  channelName: string;
};

type CommentRow = { id: number; body: string; status: string; videoId: number; author: string };

const TABS = ["Dashboard", "Users", "Content", "Comments", "Reports", "Payouts", "Monetization"] as const;

export default function AdminView({
  stats,
  users,
  videos,
  reports,
  withdrawals,
  comments,
  config,
  adminName,
}: {
  stats: Stats;
  users: UserRow[];
  videos: VideoRow[];
  reports: ReportRow[];
  withdrawals: WithdrawalRow[];
  comments: CommentRow[];
  config: MonetizationConfig;
  adminName: string;
}) {
  const router = useRouter();
  const [tab, setTab] = useState<(typeof TABS)[number]>("Dashboard");
  const [query, setQuery] = useState("");
  const [toast, setToast] = useState("");
  const [form, setForm] = useState<MonetizationConfig>(config);

  async function act(payload: Record<string, unknown>) {
    const res = await fetch("/api/admin", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    const data = await res.json().catch(() => ({}));
    setToast(data.message ?? data.error ?? "Done");
    setTimeout(() => setToast(""), 2200);
    router.refresh();
  }

  const filteredUsers = users.filter(
    (u) =>
      !query ||
      u.name.toLowerCase().includes(query.toLowerCase()) ||
      u.email.toLowerCase().includes(query.toLowerCase()),
  );
  const filteredVideos = videos.filter(
    (v) => !query || v.title.toLowerCase().includes(query.toLowerCase()),
  );

  const cards = [
    { label: "Total users", value: compactNumber(stats.users), icon: "users", tint: "bg-brand/15 text-brand" },
    { label: "Active users", value: compactNumber(stats.activeUsers), icon: "user", tint: "bg-success/15 text-success" },
    { label: "Videos", value: compactNumber(stats.videos), icon: "video", tint: "bg-secondary/15 text-secondary" },
    { label: "Shorts", value: compactNumber(stats.shorts), icon: "shorts", tint: "bg-accent/15 text-accent" },
    { label: "Total views", value: compactNumber(stats.views), icon: "eye", tint: "bg-brand/15 text-brand" },
    { label: "Total likes", value: compactNumber(stats.likes), icon: "like", tint: "bg-success/15 text-success" },
    { label: "Comments", value: compactNumber(stats.comments), icon: "comment", tint: "bg-secondary/15 text-secondary" },
    { label: "Subscriptions", value: compactNumber(stats.subscriptions), icon: "subs", tint: "bg-accent/15 text-accent" },
    { label: "Open reports", value: String(stats.openReports), icon: "flag", tint: "bg-danger/15 text-danger" },
    { label: "Platform revenue", value: money(stats.revenueCents), icon: "money", tint: "bg-success/15 text-success" },
    { label: "Pending payouts", value: money(stats.pendingCents), icon: "clock", tint: "bg-accent/15 text-accent" },
  ];

  return (
    <div className="min-h-dvh bg-bg pb-16">
      <header className="sticky top-0 z-40 border-b border-line bg-surface/90 glass">
        <div className="mx-auto flex h-14 max-w-6xl items-center gap-2 px-3">
          <Logo size={26} />
          <span className="rounded-full bg-danger/15 px-2 py-0.5 text-[10px] font-bold uppercase text-danger">
            Admin
          </span>
          <span className="ml-auto hidden text-xs text-muted sm:inline">{adminName}</span>
          <ThemeToggle compact />
          <Link href="/home" className="rounded-full p-2 hover:bg-surface2">
            <Icon name="home" size={18} />
          </Link>
        </div>
        <div className="no-scrollbar mx-auto flex max-w-6xl gap-1 overflow-x-auto px-3">
          {TABS.map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={`shrink-0 border-b-2 px-3 py-2.5 text-[13px] font-semibold ${
                tab === t ? "border-brand text-ink" : "border-transparent text-muted"
              }`}
            >
              {t}
            </button>
          ))}
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-3 py-4">
        {tab === "Dashboard" && (
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
            {cards.map((c) => (
              <div key={c.label} className="rounded-2xl bg-surface p-4">
                <span className={`grid h-9 w-9 place-items-center rounded-xl ${c.tint}`}>
                  <Icon name={c.icon} size={18} />
                </span>
                <p className="mt-3 text-xl font-bold leading-none">{c.value}</p>
                <p className="mt-1 text-[11px] text-muted">{c.label}</p>
              </div>
            ))}
          </div>
        )}

        {(tab === "Users" || tab === "Content") && (
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={tab === "Users" ? "Search users by name or email" : "Search videos"}
            className="mb-3 w-full rounded-2xl border border-line bg-surface px-4 py-3 text-sm outline-none focus:border-brand"
          />
        )}

        {tab === "Users" && (
          <div className="space-y-2">
            {filteredUsers.map((u) => (
              <div key={u.id} className="rounded-2xl bg-surface p-3">
                <div className="flex items-center gap-2">
                  <div className="min-w-0 flex-1">
                    <p className="flex items-center gap-1 truncate text-sm font-semibold">
                      {u.name}
                      {u.verified && <Icon name="check" size={12} className="text-secondary" />}
                    </p>
                    <p className="truncate text-[11px] text-muted">
                      @{u.username} · {u.email}
                    </p>
                  </div>
                  <span
                    className={`rounded-full px-2 py-0.5 text-[10px] font-bold uppercase ${
                      u.status === "active" ? "bg-success/15 text-success" : "bg-danger/15 text-danger"
                    }`}
                  >
                    {u.status}
                  </span>
                  <span className="rounded-full bg-surface2 px-2 py-0.5 text-[10px] font-bold uppercase text-muted">
                    {u.role}
                  </span>
                </div>
                <div className="mt-2 flex flex-wrap gap-2">
                  <Button size="sm" variant="outline" onClick={() => act({ action: "user-verify", id: u.id, value: !u.verified })}>
                    {u.verified ? "Unverify" : "Verify creator"}
                  </Button>
                  {u.status === "active" ? (
                    <Button size="sm" variant="outline" onClick={() => act({ action: "user-status", id: u.id, status: "suspended" })}>
                      Suspend
                    </Button>
                  ) : (
                    <Button size="sm" variant="outline" onClick={() => act({ action: "user-status", id: u.id, status: "active" })}>
                      Restore
                    </Button>
                  )}
                  <Button size="sm" variant="danger" onClick={() => act({ action: "user-delete", id: u.id })}>
                    Delete
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}

        {tab === "Content" && (
          <div className="space-y-2">
            {filteredVideos.map((v) => (
              <div key={v.id} className="flex items-center gap-3 rounded-2xl bg-surface p-3">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={v.thumbnailUrl} alt="" className="h-12 w-20 shrink-0 rounded-lg object-cover" />
                <div className="min-w-0 flex-1">
                  <Link href={`/video/${v.id}`} className="line-clamp-2x text-[13px] font-semibold">
                    {v.title}
                  </Link>
                  <p className="text-[11px] text-muted">
                    {v.channelName} · {compactNumber(v.views)} views · {v.isShort ? "Short" : "Video"} · {v.status}
                  </p>
                </div>
                <div className="flex shrink-0 flex-col gap-1">
                  <Button size="sm" variant="outline" onClick={() => act({ action: "video-status", id: v.id, status: "published" })}>
                    Approve
                  </Button>
                  <Button size="sm" variant="danger" onClick={() => act({ action: "video-status", id: v.id, status: "removed" })}>
                    Remove
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}

        {tab === "Comments" && (
          <div className="space-y-2">
            {comments.map((c) => (
              <div key={c.id} className="flex items-center gap-3 rounded-2xl bg-surface p-3">
                <div className="min-w-0 flex-1">
                  <p className="text-[13px]">{c.body}</p>
                  <p className="text-[11px] text-muted">
                    {c.author} · video #{c.videoId} · {c.status}
                  </p>
                </div>
                <Button size="sm" variant="danger" onClick={() => act({ action: "comment-remove", id: c.id })}>
                  Remove
                </Button>
              </div>
            ))}
          </div>
        )}

        {tab === "Reports" && (
          <div className="space-y-2">
            {reports.length === 0 && <p className="p-6 text-center text-sm text-muted">No reports filed.</p>}
            {reports.map((r) => (
              <div key={r.id} className="rounded-2xl bg-surface p-3">
                <div className="flex items-center gap-2">
                  <span className="rounded-full bg-danger/15 px-2 py-0.5 text-[10px] font-bold uppercase text-danger">
                    {r.category}
                  </span>
                  <span className="text-[11px] text-muted">
                    {r.targetType} #{r.targetId} · {timeAgo(r.createdAt)} · by {r.reporter ?? "guest"}
                  </span>
                  <span className="ml-auto text-[11px] font-semibold">{r.status}</span>
                </div>
                {r.note && <p className="mt-1 text-[13px] text-muted">{r.note}</p>}
                <div className="mt-2 flex flex-wrap gap-2">
                  {r.targetType === "video" && (
                    <Button size="sm" variant="danger" onClick={() => act({ action: "video-status", id: r.targetId, status: "removed" })}>
                      Remove video
                    </Button>
                  )}
                  {r.targetType === "comment" && (
                    <Button size="sm" variant="danger" onClick={() => act({ action: "comment-remove", id: r.targetId })}>
                      Remove comment
                    </Button>
                  )}
                  <Button size="sm" variant="outline" onClick={() => act({ action: "report-status", id: r.id, status: "resolved" })}>
                    Mark resolved
                  </Button>
                  <Button size="sm" variant="ghost" onClick={() => act({ action: "report-status", id: r.id, status: "dismissed" })}>
                    Dismiss
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}

        {tab === "Payouts" && (
          <div className="space-y-2">
            {withdrawals.length === 0 && <p className="p-6 text-center text-sm text-muted">No withdrawal requests.</p>}
            {withdrawals.map((w) => (
              <div key={w.id} className="rounded-2xl bg-surface p-3">
                <div className="flex items-center gap-2">
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-bold">{money(w.amountCents)}</p>
                    <p className="truncate text-[11px] text-muted">
                      {w.channelName} · {w.method.toUpperCase()} {w.account} · {timeAgo(w.requestedAt)}
                    </p>
                  </div>
                  <span className="rounded-full bg-surface2 px-2 py-0.5 text-[10px] font-bold uppercase">{w.status}</span>
                </div>
                <div className="mt-2 flex flex-wrap gap-2">
                  <Button size="sm" variant="outline" onClick={() => act({ action: "withdrawal-status", id: w.id, status: "approved" })}>
                    Approve
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => act({ action: "withdrawal-status", id: w.id, status: "paid" })}>
                    Mark paid
                  </Button>
                  <Button size="sm" variant="danger" onClick={() => act({ action: "withdrawal-status", id: w.id, status: "rejected" })}>
                    Reject
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}

        {tab === "Monetization" && (
          <div className="max-w-lg space-y-3 rounded-2xl bg-surface p-4">
            <p className="text-xs text-muted">
              All monetization rules are configurable — nothing is hard-coded in the apps.
            </p>
            {(
              [
                ["minSubscribers", "Minimum subscribers"],
                ["minEligibleViews", "Minimum eligible views"],
                ["minWatchMinutes", "Minimum watch minutes"],
                ["cpmCents", "Revenue per 1,000 views (paise)"],
                ["shortsCpmCents", "Shorts RPM per 1,000 views (paise)"],
                ["creatorSharePercent", "Creator revenue share (%)"],
                ["minWithdrawalCents", "Minimum withdrawal (paise)"],
              ] as const
            ).map(([key, label]) => (
              <label key={key} className="block">
                <span className="text-[11px] font-semibold text-muted">{label}</span>
                <input
                  type="number"
                  value={form[key]}
                  onChange={(e) => setForm({ ...form, [key]: Number(e.target.value) })}
                  className="mt-1 w-full rounded-xl border border-line bg-surface2 px-3 py-2.5 text-sm outline-none focus:border-brand"
                />
              </label>
            ))}
            <label className="flex items-center gap-2 text-sm">
              <input
                type="checkbox"
                checked={form.enabled}
                onChange={(e) => setForm({ ...form, enabled: e.target.checked })}
                className="h-4 w-4 accent-[#FF3B30]"
              />
              Monetization programme enabled
            </label>
            <label className="flex items-center gap-2 text-sm">
              <input
                type="checkbox"
                checked={form.adsEnabled}
                onChange={(e) => setForm({ ...form, adsEnabled: e.target.checked })}
                className="h-4 w-4 accent-[#FF3B30]"
              />
              Serve ads on eligible content
            </label>
            <Button full onClick={() => act({ action: "monetization", config: form })}>
              Save monetization rules
            </Button>
          </div>
        )}
      </main>

      {toast && (
        <div className="fixed bottom-6 left-1/2 z-[90] -translate-x-1/2 rounded-full bg-ink px-4 py-2 text-xs font-medium text-bg shadow-xl">
          {toast}
        </div>
      )}
    </div>
  );
}
