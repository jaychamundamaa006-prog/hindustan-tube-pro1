"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState, type ReactNode } from "react";
import Icon from "./Icon";
import ThemeToggle from "./ThemeToggle";
import AuthGate from "./AuthGate";
import { Avatar } from "./ui";

export type ChromeUser = {
  id: number;
  name: string;
  username: string;
  avatarUrl: string | null;
  role: string;
  channelHandle: string | null;
} | null;

const TABS = [
  { href: "/home", label: "Home", icon: "home" },
  { href: "/shorts", label: "Shorts", icon: "shorts" },
  { href: "/upload", label: "Create", icon: "plus" },
  { href: "/chat", label: "Chat", icon: "chat" },
  { href: "/library", label: "Library", icon: "library" },
];

export function Logo({ size = 28, withText = true }: { size?: number; withText?: boolean }) {
  return (
    <span className="flex items-center gap-2">
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img
        src="/logo.png"
        alt="Hindustan Tube Pro"
        width={size}
        height={size}
        className="shrink-0 rounded-xl object-cover shadow-lg shadow-black/20 ring-1 ring-black/5 dark:ring-white/10"
        style={{ width: size, height: size }}
      />
      {withText ? (
        <span className="text-[15px] font-bold tracking-tight">
          Hindustan<span className="text-brand">Tube</span>
          <span className="ml-1 rounded bg-accent/20 px-1 text-[9px] font-bold uppercase text-accent">
            Pro
          </span>
        </span>
      ) : null}
    </span>
  );
}

function OfflineBar() {
  const [offline, setOffline] = useState(false);
  useEffect(() => {
    const update = () => setOffline(!navigator.onLine);
    update();
    window.addEventListener("online", update);
    window.addEventListener("offline", update);
    return () => {
      window.removeEventListener("online", update);
      window.removeEventListener("offline", update);
    };
  }, []);
  if (!offline) return null;
  return (
    <div className="flex items-center justify-center gap-2 bg-danger px-3 py-1.5 text-xs font-medium text-white">
      <Icon name="wifi" size={14} /> You are offline — showing cached content
    </div>
  );
}

export default function AppChrome({
  user,
  unread,
  children,
}: {
  user: ChromeUser;
  unread: number;
  children: ReactNode;
}) {
  const pathname = usePathname();
  const immersive = pathname.startsWith("/shorts");

  return (
    <div className={`min-h-dvh ${immersive ? "bg-black" : "bg-bg"}`}>
      {!immersive && (
        <header className="sticky top-0 z-50 border-b border-line bg-surface/85 glass">
          <OfflineBar />
          <div className="mx-auto flex h-14 max-w-6xl items-center gap-1 px-3">
            <Link href="/home" className="mr-auto">
              <Logo />
            </Link>
            <Link
              href="/search"
              className="grid h-10 w-10 place-items-center rounded-full hover:bg-surface2"
              aria-label="Search"
            >
              <Icon name="search" size={20} />
            </Link>
            <ThemeToggle />
            <Link
              href="/notifications"
              className="relative grid h-10 w-10 place-items-center rounded-full hover:bg-surface2"
              aria-label="Notifications"
            >
              <Icon name="bell" size={20} />
              {unread > 0 && (
                <span className="absolute right-1 top-1 grid h-4 min-w-4 place-items-center rounded-full bg-brand px-1 text-[9px] font-bold text-white">
                  {unread > 9 ? "9+" : unread}
                </span>
              )}
            </Link>
            {user ? (
              <Link href="/settings" className="ml-1" aria-label="Profile">
                <Avatar src={user.avatarUrl} name={user.name} size={32} />
              </Link>
            ) : (
              <Link
                href="/login"
                className="ml-1 flex h-8 items-center gap-1.5 rounded-full bg-brand px-3 text-xs font-bold text-white shadow-lg shadow-brand/25 active:scale-95"
              >
                <Icon name="user" size={14} /> Sign in
              </Link>
            )}
          </div>
        </header>
      )}

      <main className={immersive ? "" : "mx-auto max-w-6xl pb-24"}>{children}</main>

      <nav className="fixed bottom-0 left-0 right-0 z-50 border-t border-line bg-surface/95 glass">
        <div className="mx-auto flex max-w-6xl items-stretch justify-around px-2 pb-[env(safe-area-inset-bottom)]">
          {TABS.map((tab) => {
            const active = pathname === tab.href || pathname.startsWith(tab.href + "/");
            if (tab.href === "/upload") {
              return (
                <Link
                  key={tab.href}
                  href={tab.href}
                  className="flex flex-1 flex-col items-center justify-center py-1.5"
                >
                  <span className="grid h-9 w-12 place-items-center rounded-xl bg-gradient-to-br from-brand to-[#ff7a3d] text-white shadow-lg shadow-brand/30 transition-transform active:scale-90">
                    <Icon name="plus" size={22} />
                  </span>
                  <span className="mt-0.5 text-[10px] font-medium text-muted">Create</span>
                </Link>
              );
            }
            return (
              <Link
                key={tab.href}
                href={tab.href}
                className={`flex flex-1 flex-col items-center gap-0.5 py-2.5 transition-colors ${
                  active ? "text-brand" : "text-muted"
                }`}
              >
                <Icon name={tab.icon} size={21} filled={active && tab.icon === "shorts"} />
                <span className="text-[10px] font-medium">{tab.label}</span>
              </Link>
            );
          })}
        </div>
      </nav>

      <AuthGate />
    </div>
  );
}
