"use client";

import type { ReactNode } from "react";
import Icon from "./Icon";
import { initials } from "@/lib/format";

export function Avatar({
  src,
  name,
  size = 40,
  ring = false,
}: {
  src?: string | null;
  name: string;
  size?: number;
  ring?: boolean;
}) {
  return src ? (
    // eslint-disable-next-line @next/next/no-img-element
    <img
      src={src}
      alt={name}
      width={size}
      height={size}
      loading="lazy"
      className={`shrink-0 rounded-full object-cover ${ring ? "ring-2 ring-brand" : ""}`}
      style={{ width: size, height: size }}
    />
  ) : (
    <div
      className={`grid shrink-0 place-items-center rounded-full bg-gradient-to-br from-brand to-secondary font-semibold text-white ${
        ring ? "ring-2 ring-brand" : ""
      }`}
      style={{ width: size, height: size, fontSize: size * 0.38 }}
    >
      {initials(name || "?")}
    </div>
  );
}

export function Spinner({ size = 22 }: { size?: number }) {
  return (
    <span
      className="inline-block animate-spin rounded-full border-2 border-brand border-t-transparent"
      style={{ width: size, height: size }}
    />
  );
}

export function StateView({
  icon = "info",
  title,
  message,
  action,
  tone = "muted",
}: {
  icon?: string;
  title: string;
  message?: string;
  action?: ReactNode;
  tone?: "muted" | "error";
}) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 px-6 py-14 text-center">
      <div
        className={`grid h-16 w-16 place-items-center rounded-2xl ${
          tone === "error" ? "bg-danger/10 text-danger" : "bg-surface2 text-muted"
        }`}
      >
        <Icon name={icon} size={30} />
      </div>
      <h3 className="text-base font-semibold">{title}</h3>
      {message ? <p className="max-w-xs text-sm text-muted">{message}</p> : null}
      {action}
    </div>
  );
}

export function Button({
  children,
  onClick,
  variant = "primary",
  size = "md",
  type = "button",
  disabled,
  full,
  className = "",
}: {
  children: ReactNode;
  onClick?: () => void;
  variant?: "primary" | "ghost" | "outline" | "surface" | "danger";
  size?: "sm" | "md" | "lg";
  type?: "button" | "submit";
  disabled?: boolean;
  full?: boolean;
  className?: string;
}) {
  const variants: Record<string, string> = {
    primary: "bg-brand text-white hover:brightness-110 shadow-lg shadow-brand/25",
    danger: "bg-danger text-white hover:brightness-110",
    ghost: "text-ink hover:bg-surface2",
    outline: "border border-line text-ink hover:bg-surface2",
    surface: "bg-surface2 text-ink hover:brightness-95 dark:hover:brightness-125",
  };
  const sizes: Record<string, string> = {
    sm: "h-8 px-3 text-xs",
    md: "h-10 px-4 text-sm",
    lg: "h-12 px-6 text-sm",
  };
  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled}
      className={`inline-flex items-center justify-center gap-2 rounded-full font-semibold transition-all active:scale-95 disabled:cursor-not-allowed disabled:opacity-50 ${
        variants[variant]
      } ${sizes[size]} ${full ? "w-full" : ""} ${className}`}
    >
      {children}
    </button>
  );
}

export function Skeleton({ className = "" }: { className?: string }) {
  return <div className={`skeleton rounded-xl ${className}`} />;
}

export function VideoCardSkeleton() {
  return (
    <div className="space-y-3">
      <Skeleton className="aspect-video w-full rounded-2xl" />
      <div className="flex gap-3 px-1">
        <Skeleton className="h-9 w-9 rounded-full" />
        <div className="flex-1 space-y-2">
          <Skeleton className="h-3.5 w-4/5" />
          <Skeleton className="h-3 w-2/5" />
        </div>
      </div>
    </div>
  );
}

export function Chip({
  active,
  children,
  onClick,
}: {
  active?: boolean;
  children: ReactNode;
  onClick?: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={`shrink-0 rounded-full px-4 py-1.5 text-[13px] font-medium transition-all active:scale-95 ${
        active
          ? "bg-ink text-bg"
          : "bg-surface2 text-ink hover:brightness-95 dark:hover:brightness-125"
      }`}
    >
      {children}
    </button>
  );
}

export function Sheet({
  open,
  onClose,
  title,
  children,
}: {
  open: boolean;
  onClose: () => void;
  title?: string;
  children: ReactNode;
}) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-[80] flex items-end justify-center sm:items-center">
      <div className="absolute inset-0 bg-black/60" onClick={onClose} />
      <div className="fade-up relative max-h-[85vh] w-full overflow-y-auto rounded-t-3xl bg-surface p-5 shadow-2xl sm:max-w-md sm:rounded-3xl">
        <div className="mx-auto mb-4 h-1 w-10 rounded-full bg-line sm:hidden" />
        {title ? (
          <div className="mb-3 flex items-center justify-between">
            <h3 className="text-base font-semibold">{title}</h3>
            <button onClick={onClose} className="rounded-full p-1.5 hover:bg-surface2">
              <Icon name="close" size={18} />
            </button>
          </div>
        ) : null}
        {children}
      </div>
    </div>
  );
}

export function Toggle({ checked, onChange }: { checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      onClick={() => onChange(!checked)}
      className={`relative h-6 w-11 rounded-full transition-colors ${
        checked ? "bg-brand" : "bg-surface2 border border-line"
      }`}
    >
      <span
        className={`absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all ${
          checked ? "left-[22px]" : "left-0.5"
        }`}
      />
    </button>
  );
}
