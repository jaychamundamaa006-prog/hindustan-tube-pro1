"use client";

import Link from "next/link";
import { useState } from "react";
import Icon from "./Icon";
import VideoCard from "./VideoCard";
import { Avatar, Button, StateView } from "./ui";
import { compactNumber, timeAgo } from "@/lib/format";
import type { VideoCard as VideoCardType } from "@/lib/queries";
import { requireSignIn } from "@/lib/client";

export type ChannelInfo = {
  id: number;
  name: string;
  handle: string;
  description: string;
  avatarUrl: string | null;
  bannerUrl: string | null;
  country: string;
  verified: boolean;
  subscriberCount: number;
  createdAt: string;
  totalViews: number;
  videoCount: number;
};

const TABS = ["Home", "Videos", "Shorts", "Playlists", "About"] as const;

export default function ChannelView({
  channel,
  videos,
  shorts,
  playlists,
  subscribed,
  isOwner,
  signedIn,
}: {
  channel: ChannelInfo;
  videos: VideoCardType[];
  shorts: VideoCardType[];
  playlists: { id: number; title: string; count: number; cover: string | null }[];
  subscribed: boolean;
  isOwner: boolean;
  signedIn: boolean;
}) {
  const [tab, setTab] = useState<(typeof TABS)[number]>("Home");
  const [sub, setSub] = useState(subscribed);
  const [count, setCount] = useState(channel.subscriberCount);

  async function toggle() {
    if (!signedIn) return requireSignIn("Sign in to subscribe to this channel.");
    setSub(!sub);
    setCount(count + (sub ? -1 : 1));
    await fetch("/api/engage", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "subscribe", channelId: channel.id }),
    });
  }

  return (
    <div className="pb-8">
      <div className="relative h-28 w-full overflow-hidden bg-gradient-to-r from-brand/40 via-secondary/30 to-accent/30 sm:h-40">
        {channel.bannerUrl ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={channel.bannerUrl} alt="" className="h-full w-full object-cover" />
        ) : null}
      </div>

      <div className="px-3">
        <div className="-mt-8 flex items-end gap-3">
          <Avatar src={channel.avatarUrl} name={channel.name} size={72} ring />
          <div className="min-w-0 flex-1 pb-1">
            <h1 className="flex items-center gap-1 truncate text-lg font-bold">
              {channel.name}
              {channel.verified && <Icon name="check" size={15} className="text-secondary" />}
            </h1>
            <p className="truncate text-xs text-muted">
              @{channel.handle} · {compactNumber(count)} subscribers · {channel.videoCount} videos
            </p>
          </div>
        </div>

        <p className="mt-3 line-clamp-2x text-[13px] text-muted">{channel.description}</p>

        <div className="mt-3 flex gap-2">
          {isOwner ? (
            <>
              <Link href="/studio" className="flex-1">
                <Button full variant="surface">
                  <Icon name="chart" size={16} /> Creator Studio
                </Button>
              </Link>
              <Link href="/upload" className="flex-1">
                <Button full>
                  <Icon name="upload" size={16} /> Upload
                </Button>
              </Link>
            </>
          ) : (
            <>
              <Button full variant={sub ? "surface" : "primary"} onClick={toggle}>
                {sub ? "Subscribed" : "Subscribe"}
              </Button>
              <Button
                variant="outline"
                onClick={() => {
                  const url = `${window.location.origin}/channel/${channel.handle}`;
                  if (navigator.share) void navigator.share({ url, title: channel.name });
                  else void navigator.clipboard.writeText(url);
                }}
              >
                <Icon name="share" size={16} />
              </Button>
            </>
          )}
        </div>
      </div>

      <div className="no-scrollbar mt-4 flex gap-1 overflow-x-auto border-b border-line px-3">
        {TABS.map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`shrink-0 border-b-2 px-4 py-2.5 text-sm font-semibold transition-colors ${
              tab === t ? "border-brand text-ink" : "border-transparent text-muted"
            }`}
          >
            {t}
          </button>
        ))}
      </div>

      <div className="px-3 py-4">
        {tab === "Home" && (
          <div className="space-y-6">
            {videos[0] ? <VideoCard video={videos[0]} /> : null}
            {shorts.length > 0 && (
              <div>
                <h2 className="mb-2 text-sm font-bold">Shorts</h2>
                <div className="no-scrollbar flex gap-3 overflow-x-auto">
                  {shorts.map((s) => (
                    <Link key={s.id} href={`/shorts?v=${s.id}`} className="w-32 shrink-0">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img src={s.thumbnailUrl} alt={s.title} className="aspect-[9/16] w-full rounded-xl object-cover" />
                      <p className="mt-1 line-clamp-2x text-[11px] font-medium">{s.title}</p>
                    </Link>
                  ))}
                </div>
              </div>
            )}
            <div>
              <h2 className="mb-2 text-sm font-bold">Latest uploads</h2>
              <div className="divide-y divide-line/50">
                {videos.slice(1, 6).map((v) => (
                  <VideoCard key={v.id} video={v} compact />
                ))}
              </div>
            </div>
          </div>
        )}

        {tab === "Videos" &&
          (videos.length ? (
            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {videos.map((v) => (
                <VideoCard key={v.id} video={v} />
              ))}
            </div>
          ) : (
            <StateView icon="video" title="No videos yet" message="This channel hasn't published any long-form videos." />
          ))}

        {tab === "Shorts" &&
          (shorts.length ? (
            <div className="grid grid-cols-3 gap-2 sm:grid-cols-5">
              {shorts.map((s) => (
                <Link key={s.id} href={`/shorts?v=${s.id}`}>
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={s.thumbnailUrl} alt={s.title} className="aspect-[9/16] w-full rounded-xl object-cover" />
                  <p className="mt-1 line-clamp-2x text-[11px]">{s.title}</p>
                </Link>
              ))}
            </div>
          ) : (
            <StateView icon="shorts" title="No shorts yet" />
          ))}

        {tab === "Playlists" &&
          (playlists.length ? (
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
              {playlists.map((p) => (
                <div key={p.id} className="overflow-hidden rounded-2xl bg-surface">
                  {p.cover ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img src={p.cover} alt={p.title} className="aspect-video w-full object-cover" />
                  ) : (
                    <div className="grid aspect-video place-items-center bg-surface2 text-muted">
                      <Icon name="list" size={22} />
                    </div>
                  )}
                  <div className="p-2.5">
                    <p className="truncate text-[13px] font-semibold">{p.title}</p>
                    <p className="text-[11px] text-muted">{p.count} videos</p>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <StateView icon="list" title="No public playlists" />
          ))}

        {tab === "About" && (
          <div className="space-y-4 rounded-2xl bg-surface p-4 text-sm">
            <p className="whitespace-pre-wrap leading-relaxed text-muted">{channel.description}</p>
            <div className="grid grid-cols-2 gap-3">
              <Stat label="Joined" value={timeAgo(channel.createdAt)} />
              <Stat label="Country" value={channel.country} />
              <Stat label="Total views" value={compactNumber(channel.totalViews)} />
              <Stat label="Subscribers" value={compactNumber(count)} />
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl bg-surface2 p-3">
      <p className="text-[11px] text-muted">{label}</p>
      <p className="text-sm font-semibold">{value}</p>
    </div>
  );
}
