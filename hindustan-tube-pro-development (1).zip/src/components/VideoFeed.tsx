"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import VideoCard from "./VideoCard";
import Icon from "./Icon";
import { Button, Chip, StateView, VideoCardSkeleton } from "./ui";
import { CATEGORIES } from "@/lib/constants";
import type { VideoCard as VideoCardType } from "@/lib/queries";

const PAGE_SIZE = 8;

export default function VideoFeed({
  initial,
  rail,
}: {
  initial: VideoCardType[];
  rail?: React.ReactNode;
}) {
  const [category, setCategory] = useState("all");
  const [items, setItems] = useState<VideoCardType[]>(initial);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(initial.length < PAGE_SIZE);
  const [error, setError] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [pull, setPull] = useState(0);
  const sentinel = useRef<HTMLDivElement | null>(null);
  const startY = useRef(0);

  const load = useCallback(
    async (nextPage: number, cat: string, replace = false) => {
      setLoading(true);
      setError(false);
      try {
        const shorts = cat === "shorts" ? "true" : "false";
        const res = await fetch(
          `/api/videos?category=${encodeURIComponent(cat)}&page=${nextPage}&limit=${PAGE_SIZE}&shorts=${shorts}`,
        );
        if (!res.ok) throw new Error("failed");
        const data = (await res.json()) as { videos: VideoCardType[] };
        setItems((prev) => (replace ? data.videos : [...prev, ...data.videos]));
        setDone(data.videos.length < PAGE_SIZE);
        setPage(nextPage);
      } catch {
        setError(true);
      } finally {
        setLoading(false);
        setRefreshing(false);
      }
    },
    [],
  );

  useEffect(() => {
    const node = sentinel.current;
    if (!node) return;
    const obs = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && !loading && !done && !error) {
          void load(page + 1, category);
        }
      },
      { rootMargin: "400px" },
    );
    obs.observe(node);
    return () => obs.disconnect();
  }, [page, category, loading, done, error, load]);

  function selectCategory(slug: string) {
    setCategory(slug);
    setItems([]);
    setDone(false);
    void load(1, slug, true);
  }

  function onTouchStart(e: React.TouchEvent) {
    if (window.scrollY <= 0) startY.current = e.touches[0].clientY;
    else startY.current = -1;
  }
  function onTouchMove(e: React.TouchEvent) {
    if (startY.current < 0) return;
    const delta = e.touches[0].clientY - startY.current;
    if (delta > 0) setPull(Math.min(90, delta * 0.5));
  }
  function onTouchEnd() {
    if (pull > 55) {
      setRefreshing(true);
      setItems([]);
      void load(1, category, true);
    }
    setPull(0);
  }

  return (
    <div onTouchStart={onTouchStart} onTouchMove={onTouchMove} onTouchEnd={onTouchEnd}>
      <div className="sticky top-14 z-40 -mx-0 border-b border-line bg-bg/95 glass">
        <div className="no-scrollbar flex gap-2 overflow-x-auto px-3 py-2.5">
          {CATEGORIES.map((c) => (
            <Chip key={c.slug} active={category === c.slug} onClick={() => selectCategory(c.slug)}>
              {c.name}
            </Chip>
          ))}
        </div>
      </div>

      {(pull > 0 || refreshing) && (
        <div
          className="flex items-center justify-center overflow-hidden text-muted transition-all"
          style={{ height: refreshing ? 44 : pull }}
        >
          <Icon name="refresh" size={20} className={refreshing ? "spin-slow" : ""} />
        </div>
      )}

      {rail && category === "all" ? rail : null}

      <div className="grid grid-cols-1 gap-6 px-0 py-4 sm:grid-cols-2 sm:px-3 lg:grid-cols-3">
        {items.map((v) => (
          <VideoCard key={`${v.id}-${v.createdAt}`} video={v} />
        ))}
        {loading &&
          Array.from({ length: 3 }).map((_, i) => (
            <div key={`sk-${i}`} className="px-3 sm:px-0">
              <VideoCardSkeleton />
            </div>
          ))}
      </div>

      {!loading && items.length === 0 && !error && (
        <StateView
          icon="video"
          title="Nothing here yet"
          message="No videos found in this category. Try another one or pull to refresh."
          action={<Button variant="outline" onClick={() => selectCategory("all")}>Browse all</Button>}
        />
      )}

      {error && (
        <StateView
          tone="error"
          icon="wifi"
          title="Couldn't load videos"
          message="Check your connection and try again."
          action={<Button onClick={() => load(page, category, items.length === 0)}>Retry</Button>}
        />
      )}

      <div ref={sentinel} className="h-6" />
      {done && items.length > 0 && (
        <p className="pb-6 text-center text-xs text-muted">You&apos;re all caught up ✦</p>
      )}
    </div>
  );
}
