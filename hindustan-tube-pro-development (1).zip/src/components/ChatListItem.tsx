import Link from "next/link";
import Icon from "./Icon";
import { Avatar } from "./ui";
import { timeAgo, compactNumber } from "@/lib/format";

export function ChatListItem({
  id,
  type,
  name,
  photoUrl,
  lastMessage,
  lastMessageTime,
  lastSenderName,
  memberCount,
  unreadCount,
}: {
  id: number;
  type: "direct" | "group";
  name: string | null;
  photoUrl: string | null;
  lastMessage: string | null;
  lastMessageTime: string | Date | null;
  lastSenderName: string | null;
  memberCount: number;
  unreadCount: number;
}) {
  const title = type === "group" ? (name || "Group") : (lastSenderName || "Unknown");
  const subtitle =
    type === "group"
      ? `${memberCount} members`
      : lastMessage
        ? lastMessage.slice(0, 80)
        : "No messages yet";

  return (
    <Link
      href={`/chat/${id}`}
      className={`flex items-center gap-3 border-b border-line px-3 py-3 transition-colors hover:bg-surface2 ${
        unreadCount > 0 ? "bg-brand/5" : ""
      }`}
    >
      <Avatar src={photoUrl} name={title} size={48} />
      <div className="min-w-0 flex-1">
        <div className="flex items-center justify-between gap-2">
          <p className="truncate text-sm font-semibold">{title}</p>
          {lastMessageTime ? (
            <span className="text-[10px] text-muted">{timeAgo(lastMessageTime)}</span>
          ) : null}
        </div>
        <p className="line-clamp-2x text-[12px] text-muted">{subtitle}</p>
        {type === "group" && (
          <span className="mt-0.5 flex items-center gap-1 text-[10px] text-muted">
            <Icon name="users" size={11} /> {memberCount} members
          </span>
        )}
      </div>
      {unreadCount > 0 && (
        <span className="grid min-w-6 place-items-center rounded-full bg-brand px-1.5 text-[10px] font-bold text-white">
          {unreadCount > 99 ? "99+" : unreadCount}
        </span>
      )}
    </Link>
  );
}
