import Link from "next/link";
import Icon from "./Icon";
import { compactNumber } from "@/lib/format";
import type { VideoCard } from "@/lib/queries";

export default function ShortsRail({ shorts }: { shorts: VideoCard[] }) {
  if (!shorts.length) return null;
  return (
    <section className="border-y border-line py-4">
      <div className="mb-3 flex items-center justify-between px-3">
        <h2 className="flex items-center gap-2 text-base font-bold">
          <span className="grid h-6 w-6 place-items-center rounded-lg bg-brand text-white">
            <Icon name="shorts" size={14} filled />
          </span>
          Shorts
        </h2>
        <Link href="/shorts" className="text-xs font-semibold text-brand">
          See all
        </Link>
      </div>
      <div className="no-scrollbar flex gap-3 overflow-x-auto px-3 pb-1">
        {shorts.map((s) => (
          <Link
            key={s.id}
            href={`/shorts?v=${s.id}`}
            className="group relative aspect-[9/16] w-[8.5rem] shrink-0 overflow-hidden rounded-2xl bg-surface2"
          >
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={s.thumbnailUrl}
              alt={s.title}
              loading="lazy"
              className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
            />
            <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/85 to-transparent p-2">
              <p className="line-clamp-2x text-[11px] font-semibold leading-tight text-white">{s.title}</p>
              <p className="mt-0.5 text-[10px] text-white/70">{compactNumber(s.views)} views</p>
            </div>
          </Link>
        ))}
      </div>
    </section>
  );
}
