"use client";

import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import Icon from "./Icon";
import { Button, Sheet, Spinner } from "./ui";
import { AUTH_EVENT, type AuthPromptDetail } from "@/lib/client";

/** API paths that legitimately answer 401 for guests without needing a prompt. */
const SILENT = ["/api/auth", "/api/notifications", "/api/health"];

export default function AuthGate() {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [next, setNext] = useState("/home");
  const [reason, setReason] = useState<string | undefined>();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    const handler = (event: Event) => {
      const detail = (event as CustomEvent<AuthPromptDetail>).detail;
      setNext(detail?.next ?? "/home");
      setReason(detail?.reason);
      setError("");
      setOpen(true);
    };
    window.addEventListener(AUTH_EVENT, handler);

    // Safety net: any 401 coming back from our own API opens the same sheet,
    // so no interaction can ever fail silently or dead-end the user.
    const original = window.fetch;
    window.fetch = async (...args: Parameters<typeof fetch>) => {
      const res = await original(...args);
      try {
        const input = args[0];
        const url =
          typeof input === "string"
            ? input
            : input instanceof URL
              ? input.toString()
              : input.url;
        if (res.status === 401 && url.includes("/api/") && !SILENT.some((s) => url.includes(s))) {
          window.dispatchEvent(
            new CustomEvent<AuthPromptDetail>(AUTH_EVENT, {
              detail: { next: `${window.location.pathname}${window.location.search}` },
            }),
          );
        }
      } catch {
        /* ignore */
      }
      return res;
    };

    return () => {
      window.removeEventListener(AUTH_EVENT, handler);
      window.fetch = original;
    };
  }, []);

  async function quickSignIn(email: string, password: string) {
    setBusy(true);
    setError("");
    try {
      const res = await fetch("/api/auth", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "login", email, password }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        setError(data.error ?? "Could not sign in. Try the full sign-in page.");
        return;
      }
      setOpen(false);
      router.refresh();
    } catch {
      setError("Network error. Please check your connection.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <Sheet open={open} onClose={() => setOpen(false)}>
      <div className="pb-1 text-center">
        <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-brand/12 text-brand">
          <Icon name="lock" size={26} />
        </div>
        <h3 className="mt-3 text-base font-bold">Sign in to continue</h3>
        <p className="mx-auto mt-1 max-w-xs text-[13px] leading-relaxed text-muted">
          {reason ??
            "Browsing is free for everyone. Sign in to like, comment, subscribe, save to playlists and upload."}
        </p>
      </div>

      <div className="mt-5 space-y-2.5">
        <Button full size="lg" disabled={busy} onClick={() => quickSignIn("aarav@htp.app", "password123")}>
          {busy ? <Spinner size={18} /> : <Icon name="sparkle" size={16} />}
          {busy ? "Signing you in…" : "Continue with demo creator"}
        </Button>
        <Button
          full
          size="lg"
          variant="outline"
          onClick={() => {
            setOpen(false);
            router.push(`/login?next=${encodeURIComponent(next)}`);
          }}
        >
          Sign in with email or phone
        </Button>
        <Button
          full
          size="lg"
          variant="ghost"
          onClick={() => {
            setOpen(false);
            router.push("/signup");
          }}
        >
          Create a free account
        </Button>

        {error ? (
          <p className="rounded-xl bg-danger/10 px-3 py-2 text-center text-xs text-danger">{error}</p>
        ) : null}

        <button onClick={() => setOpen(false)} className="w-full py-2 text-xs font-semibold text-muted">
          Keep browsing as guest
        </button>
      </div>
    </Sheet>
  );
}
