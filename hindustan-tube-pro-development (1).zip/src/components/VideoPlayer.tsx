"use client";

import { useEffect, useRef, useState } from "react";
import Icon from "./Icon";
import { formatDuration } from "@/lib/format";

const SPEEDS = [0.5, 0.75, 1, 1.25, 1.5, 2];
const QUALITIES = ["Auto", "1080p", "720p", "480p", "360p", "144p"];

type PipVideo = HTMLVideoElement & {
  requestPictureInPicture?: () => Promise<unknown>;
};

export default function VideoPlayer({
  src,
  poster,
  startAt = 0,
  onProgress,
  onEnded,
}: {
  src: string;
  poster: string;
  startAt?: number;
  onProgress?: (seconds: number) => void;
  onEnded?: () => void;
}) {
  const wrapRef = useRef<HTMLDivElement | null>(null);
  const ref = useRef<HTMLVideoElement | null>(null);
  const [playing, setPlaying] = useState(false);
  const [current, setCurrent] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(1);
  const [speed, setSpeed] = useState(1);
  const [quality, setQuality] = useState("Auto");
  const [captions, setCaptions] = useState(false);
  const [menu, setMenu] = useState<"none" | "speed" | "quality">("none");
  const [chrome, setChrome] = useState(true);
  const [buffering, setBuffering] = useState(false);
  const [failed, setFailed] = useState(false);
  const hideTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    const el = ref.current;
    if (el && startAt > 0) el.currentTime = startAt;
  }, [startAt, src]);

  useEffect(() => {
    const id = setInterval(() => {
      if (ref.current && !ref.current.paused) onProgress?.(Math.floor(ref.current.currentTime));
    }, 10000);
    return () => clearInterval(id);
  }, [onProgress]);

  function bump() {
    setChrome(true);
    if (hideTimer.current) clearTimeout(hideTimer.current);
    hideTimer.current = setTimeout(() => setChrome(false), 3200);
  }

  function toggle() {
    const el = ref.current;
    if (!el) return;
    if (el.paused) void el.play();
    else el.pause();
    bump();
  }

  function skip(seconds: number) {
    const el = ref.current;
    if (!el) return;
    el.currentTime = Math.max(0, Math.min(el.duration || 0, el.currentTime + seconds));
    bump();
  }

  async function fullscreen() {
    const node = wrapRef.current;
    if (!node) return;
    if (document.fullscreenElement) await document.exitFullscreen();
    else await node.requestFullscreen().catch(() => undefined);
  }

  async function pip() {
    const el = ref.current as PipVideo | null;
    if (!el?.requestPictureInPicture) return;
    try {
      if (document.pictureInPictureElement) await document.exitPictureInPicture();
      else await el.requestPictureInPicture();
    } catch {
      /* unsupported */
    }
  }

  if (failed) {
    return (
      <div className="flex aspect-video w-full flex-col items-center justify-center gap-3 bg-black text-white">
        <Icon name="wifi" size={30} />
        <p className="text-sm">Playback error — the stream could not be loaded.</p>
        <button
          onClick={() => {
            setFailed(false);
            ref.current?.load();
          }}
          className="rounded-full bg-brand px-4 py-2 text-xs font-semibold"
        >
          Retry
        </button>
      </div>
    );
  }

  return (
    <div
      ref={wrapRef}
      onMouseMove={bump}
      onClick={bump}
      className="group relative aspect-video w-full select-none overflow-hidden bg-black sm:rounded-2xl"
    >
      <video
        ref={ref}
        src={src}
        poster={poster}
        playsInline
        preload="metadata"
        className="h-full w-full object-contain"
        onPlay={() => setPlaying(true)}
        onPause={() => setPlaying(false)}
        onWaiting={() => setBuffering(true)}
        onPlaying={() => setBuffering(false)}
        onLoadedMetadata={(e) => setDuration(e.currentTarget.duration || 0)}
        onTimeUpdate={(e) => setCurrent(e.currentTarget.currentTime)}
        onError={() => setFailed(true)}
        onEnded={() => {
          setPlaying(false);
          onEnded?.();
        }}
        onClick={toggle}
      />

      {buffering && (
        <div className="pointer-events-none absolute inset-0 grid place-items-center">
          <span className="h-10 w-10 animate-spin rounded-full border-[3px] border-white/30 border-t-brand" />
        </div>
      )}

      {captions && playing && (
        <div className="pointer-events-none absolute bottom-20 left-1/2 -translate-x-1/2 rounded bg-black/70 px-3 py-1 text-center text-[12px] text-white">
          [Auto-generated captions enabled]
        </div>
      )}

      <div
        className={`absolute inset-0 transition-opacity duration-300 ${
          chrome || !playing ? "opacity-100" : "opacity-0"
        }`}
      >
        <div className="absolute inset-0 flex items-center justify-center gap-8">
          <button onClick={() => skip(-10)} className="grid h-12 w-12 place-items-center rounded-full bg-black/45 text-white active:scale-90">
            <Icon name="back10" size={24} />
          </button>
          <button onClick={toggle} className="grid h-16 w-16 place-items-center rounded-full bg-brand text-white shadow-xl active:scale-90">
            <Icon name={playing ? "pause" : "play"} size={28} filled={!playing} />
          </button>
          <button onClick={() => skip(10)} className="grid h-12 w-12 place-items-center rounded-full bg-black/45 text-white active:scale-90">
            <Icon name="forward10" size={24} />
          </button>
        </div>

        <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/85 to-transparent px-3 pb-2 pt-8">
          <input
            type="range"
            className="seek w-full"
            min={0}
            max={duration || 0}
            step={0.1}
            value={current}
            onChange={(e) => {
              const el = ref.current;
              if (el) el.currentTime = Number(e.target.value);
              setCurrent(Number(e.target.value));
            }}
          />
          <div className="mt-1 flex items-center gap-3 text-white">
            <span className="text-[11px] tabular-nums">
              {formatDuration(current)} / {formatDuration(duration)}
            </span>
            <button
              onClick={() => {
                const el = ref.current;
                if (!el) return;
                const next = volume > 0 ? 0 : 1;
                el.volume = next;
                setVolume(next);
              }}
            >
              <Icon name={volume > 0 ? "volume" : "mute"} size={18} />
            </button>
            <input
              type="range"
              className="seek hidden w-20 sm:block"
              min={0}
              max={1}
              step={0.05}
              value={volume}
              onChange={(e) => {
                const el = ref.current;
                const v = Number(e.target.value);
                if (el) el.volume = v;
                setVolume(v);
              }}
            />
            <div className="ml-auto flex items-center gap-3">
              <button onClick={() => setCaptions((c) => !c)} className={captions ? "text-accent" : ""}>
                <Icon name="cc" size={18} />
              </button>
              <button onClick={() => setMenu(menu === "speed" ? "none" : "speed")}>
                <span className="text-[11px] font-bold">{speed}x</span>
              </button>
              <button onClick={() => setMenu(menu === "quality" ? "none" : "quality")}>
                <span className="text-[11px] font-bold">{quality}</span>
              </button>
              <button onClick={pip} className="hidden sm:block">
                <Icon name="pip" size={18} />
              </button>
              <button onClick={fullscreen}>
                <Icon name="fullscreen" size={18} />
              </button>
            </div>
          </div>
        </div>
      </div>

      {menu !== "none" && (
        <div className="absolute bottom-16 right-3 w-36 overflow-hidden rounded-xl bg-black/90 py-1 text-white">
          {(menu === "speed" ? SPEEDS : QUALITIES).map((option) => (
            <button
              key={String(option)}
              onClick={() => {
                if (menu === "speed") {
                  const el = ref.current;
                  if (el) el.playbackRate = Number(option);
                  setSpeed(Number(option));
                } else {
                  setQuality(String(option));
                }
                setMenu("none");
              }}
              className="flex w-full items-center justify-between px-3 py-2 text-xs hover:bg-white/10"
            >
              {menu === "speed" ? `${option}x` : option}
              {(menu === "speed" ? speed === option : quality === option) && <Icon name="check" size={13} />}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
