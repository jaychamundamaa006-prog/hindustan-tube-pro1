"use client";

import { useState } from "react";
import { Button, Sheet } from "./ui";
import { REPORT_CATEGORIES } from "@/lib/constants";

export default function ReportDialog({
  open,
  onClose,
  targetType,
  targetId,
}: {
  open: boolean;
  onClose: () => void;
  targetType: "video" | "comment" | "user";
  targetId: number;
}) {
  const [category, setCategory] = useState("spam");
  const [note, setNote] = useState("");
  const [state, setState] = useState<"idle" | "sending" | "done" | "error">("idle");

  async function submit() {
    setState("sending");
    const res = await fetch("/api/engage", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "report", targetType, targetId, category, note }),
    });
    setState(res.ok ? "done" : "error");
    if (res.ok) setTimeout(onClose, 1400);
  }

  return (
    <Sheet open={open} onClose={onClose} title="Report content">
      {state === "done" ? (
        <p className="py-6 text-center text-sm text-success">
          Thanks — our moderation team will review this shortly.
        </p>
      ) : (
        <div className="space-y-3">
          {REPORT_CATEGORIES.map((c) => (
            <label key={c.value} className="flex items-center gap-3 rounded-xl px-2 py-2.5 text-sm hover:bg-surface2">
              <input
                type="radio"
                name="report-category"
                checked={category === c.value}
                onChange={() => setCategory(c.value)}
                className="h-4 w-4 accent-[#FF3B30]"
              />
              {c.label}
            </label>
          ))}
          <textarea
            value={note}
            onChange={(e) => setNote(e.target.value)}
            placeholder="Add details (optional)"
            rows={3}
            className="w-full rounded-xl border border-line bg-surface2 p-3 text-sm outline-none focus:border-brand"
          />
          {state === "error" && <p className="text-xs text-danger">Could not submit. Please retry.</p>}
          <Button full onClick={submit} disabled={state === "sending"}>
            {state === "sending" ? "Submitting…" : "Submit report"}
          </Button>
        </div>
      )}
    </Sheet>
  );
}
