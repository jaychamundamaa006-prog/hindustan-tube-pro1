"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import Icon from "./Icon";
import VideoCard from "./VideoCard";
import { Button, Sheet, StateView } from "./ui";
import type { VideoCard as VideoCardType } from "@/lib/queries";

type HistoryItem = VideoCardType & { progressSec: number };
type Playlist = { id: number; title: string; visibility: string; system: string | null; count: number; cover: string | null };

const TABS = ["History", "Playlists", "Liked", "Watch Later", "Your videos", "Downloads"] as const;

export default function LibraryView({
  history,
  playlists,
  liked,
  watchLater,
  yourVideos,
}: {
  history: HistoryItem[];
  playlists: Playlist[];
  liked: VideoCardType[];
  watchLater: VideoCardType[];
  yourVideos: VideoCardType[];
}) {
  const router = useRouter();
  const [tab, setTab] = useState<(typeof TABS)[number]>("History");
  const [items, setItems] = useState(history);
  const [lists, setLists] = useState(playlists);
  const [creating, setCreating] = useState(false);
  const [name, setName] = useState("");
  const [visibility, setVisibility] = useState("public");
  const [editing, setEditing] = useState<Playlist | null>(null);

  async function engage(payload: Record<string, unknown>) {
    await fetch("/api/engage", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
  }

  async function createPlaylist() {
    const res = await fetch("/api/playlists", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "create", title: name, visibility }),
    });
    if (res.ok) {
      const data = await res.json();
      setLists([...lists, { id: data.id, title: name, visibility, system: null, count: 0, cover: null }]);
      setName("");
      setCreating(false);
      router.refresh();
    }
  }

  async function savePlaylist() {
    if (!editing) return;
    await fetch("/api/playlists", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: editing.id, title: editing.title, visibility: editing.visibility }),
    });
    setLists(lists.map((l) => (l.id === editing.id ? editing : l)));
    setEditing(null);
  }

  async function deletePlaylist(id: number) {
    await fetch(`/api/playlists?id=${id}`, { method: "DELETE" });
    setLists(lists.filter((l) => l.id !== id));
    setEditing(null);
  }

  function grid(videos: VideoCardType[], emptyTitle: string, emptyMsg: string, icon = "video") {
    if (!videos.length) return <StateView icon={icon} title={emptyTitle} message={emptyMsg} />;
    return (
      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {videos.map((v) => (
          <VideoCard key={v.id} video={v} />
        ))}
      </div>
    );
  }

  return (
    <div className="pb-6">
      <div className="no-scrollbar flex gap-1 overflow-x-auto border-b border-line px-3">
        {TABS.map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`shrink-0 border-b-2 px-3 py-3 text-sm font-semibold transition-colors ${
              tab === t ? "border-brand text-ink" : "border-transparent text-muted"
            }`}
          >
            {t}
          </button>
        ))}
      </div>

      <div className="p-3">
        {tab === "History" && (
          <>
            {items.length > 0 && (
              <div className="mb-3 flex items-center justify-between">
                <h2 className="text-sm font-bold">Continue watching</h2>
                <button
                  onClick={async () => {
                    await engage({ action: "history-clear" });
                    setItems([]);
                  }}
                  className="text-xs font-semibold text-brand"
                >
                  Clear all
                </button>
              </div>
            )}
            {items.length === 0 ? (
              <StateView icon="clock" title="No watch history" message="Videos you watch will show up here." />
            ) : (
              <div className="space-y-1">
                {items.map((h) => (
                  <div key={h.id} className="flex items-center gap-2">
                    <div className="min-w-0 flex-1">
                      <VideoCard video={h} compact />
                      {h.progressSec > 0 && (
                        <div className="mb-2 ml-40 h-1 overflow-hidden rounded-full bg-surface2">
                          <div
                            className="h-full bg-brand"
                            style={{ width: `${Math.min(100, (h.progressSec / (h.durationSec || 1)) * 100)}%` }}
                          />
                        </div>
                      )}
                    </div>
                    <button
                      onClick={async () => {
                        await engage({ action: "history-remove", videoId: h.id });
                        setItems(items.filter((i) => i.id !== h.id));
                      }}
                      className="text-muted hover:text-danger"
                    >
                      <Icon name="close" size={16} />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </>
        )}

        {tab === "Playlists" && (
          <>
            <Button className="mb-4" onClick={() => setCreating(true)}>
              <Icon name="plus" size={16} /> New playlist
            </Button>
            {lists.length === 0 ? (
              <StateView icon="list" title="No playlists" message="Group videos into public or private playlists." />
            ) : (
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
                {lists.map((p) => (
                  <div key={p.id} className="overflow-hidden rounded-2xl bg-surface">
                    {p.cover ? (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img src={p.cover} alt="" className="aspect-video w-full object-cover" />
                    ) : (
                      <div className="grid aspect-video place-items-center bg-surface2 text-muted">
                        <Icon name="list" size={22} />
                      </div>
                    )}
                    <div className="flex items-start gap-1 p-2.5">
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-[13px] font-semibold">{p.title}</p>
                        <p className="flex items-center gap-1 text-[11px] text-muted">
                          <Icon name={p.visibility === "private" ? "lock" : "globe"} size={11} />
                          {p.count} videos
                        </p>
                      </div>
                      {!p.system && (
                        <button onClick={() => setEditing(p)} className="text-muted">
                          <Icon name="more" size={16} />
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </>
        )}

        {tab === "Liked" && grid(liked, "No liked videos", "Tap like on a video to save it here.", "like")}
        {tab === "Watch Later" && grid(watchLater, "Watch Later is empty", "Save videos to watch when you have time.", "clock")}
        {tab === "Your videos" &&
          (yourVideos.length ? (
            <>
              <Link href="/studio" className="mb-3 inline-block">
                <Button variant="surface" size="sm">
                  <Icon name="chart" size={15} /> Open Creator Studio
                </Button>
              </Link>
              {grid(yourVideos, "", "")}
            </>
          ) : (
            <StateView
              icon="upload"
              title="No uploads yet"
              message="Publish your first video to build your channel."
              action={
                <Link href="/upload">
                  <Button>Upload a video</Button>
                </Link>
              }
            />
          ))}

        {tab === "Downloads" && (
          <StateView
            icon="download"
            title="Offline downloads"
            message="Downloaded videos will be stored on your device. This feature ships in the next release — the UI is ready."
            action={<Button variant="outline">Manage storage</Button>}
          />
        )}
      </div>

      <Sheet open={creating} onClose={() => setCreating(false)} title="New playlist">
        <div className="space-y-3">
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Playlist name"
            className="w-full rounded-2xl border border-line bg-surface2 px-4 py-3 text-sm outline-none focus:border-brand"
          />
          <select
            value={visibility}
            onChange={(e) => setVisibility(e.target.value)}
            className="w-full rounded-2xl border border-line bg-surface2 px-4 py-3 text-sm outline-none"
          >
            <option value="public">Public</option>
            <option value="private">Private</option>
          </select>
          <Button full onClick={createPlaylist} disabled={name.trim().length < 2}>
            Create playlist
          </Button>
        </div>
      </Sheet>

      <Sheet open={editing !== null} onClose={() => setEditing(null)} title="Edit playlist">
        {editing && (
          <div className="space-y-3">
            <input
              value={editing.title}
              onChange={(e) => setEditing({ ...editing, title: e.target.value })}
              className="w-full rounded-2xl border border-line bg-surface2 px-4 py-3 text-sm outline-none focus:border-brand"
            />
            <select
              value={editing.visibility}
              onChange={(e) => setEditing({ ...editing, visibility: e.target.value })}
              className="w-full rounded-2xl border border-line bg-surface2 px-4 py-3 text-sm outline-none"
            >
              <option value="public">Public</option>
              <option value="private">Private</option>
            </select>
            <Button full onClick={savePlaylist}>
              Save changes
            </Button>
            <Button full variant="danger" onClick={() => deletePlaylist(editing.id)}>
              Delete playlist
            </Button>
          </div>
        )}
      </Sheet>
    </div>
  );
}
