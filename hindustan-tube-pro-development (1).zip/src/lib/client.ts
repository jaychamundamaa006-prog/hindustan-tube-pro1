"use client";

/** Broadcast channel used to open the global sign-in sheet. */
export const AUTH_EVENT = "htp:auth-required";

export type AuthPromptDetail = { next: string; reason?: string };

/**
 * Ask the user to sign in without throwing them out of the page they are on.
 * The AuthGate mounted in the app shell listens for this event.
 */
export function requireSignIn(reason?: string): void {
  if (typeof window === "undefined") return;
  const next = `${window.location.pathname}${window.location.search}`;
  window.dispatchEvent(
    new CustomEvent<AuthPromptDetail>(AUTH_EVENT, { detail: { next, reason } }),
  );
}

/** POST JSON helper that never throws and surfaces the API message. */
export async function postJSON<T = Record<string, unknown>>(
  url: string,
  body: unknown,
): Promise<{ ok: boolean; status: number; data: T & { message?: string; error?: string } }> {
  try {
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    const data = await res.json().catch(() => ({}));
    return { ok: res.ok, status: res.status, data };
  } catch {
    return { ok: false, status: 0, data: {} as T & { message?: string; error?: string } };
  }
}
