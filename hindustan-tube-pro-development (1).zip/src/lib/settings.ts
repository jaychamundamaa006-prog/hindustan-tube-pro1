import { eq } from "drizzle-orm";
import { db } from "@/db";
import { settings } from "@/db/schema";

export type MonetizationConfig = {
  enabled: boolean;
  minSubscribers: number;
  minEligibleViews: number;
  minWatchMinutes: number;
  cpmCents: number; // revenue per 1000 eligible views, in paise/cents
  creatorSharePercent: number;
  minWithdrawalCents: number;
  adsEnabled: boolean;
  shortsCpmCents: number;
};

export const DEFAULT_MONETIZATION: MonetizationConfig = {
  enabled: true,
  minSubscribers: 1000,
  minEligibleViews: 10000,
  minWatchMinutes: 4000,
  cpmCents: 12000,
  creatorSharePercent: 55,
  minWithdrawalCents: 100000,
  adsEnabled: true,
  shortsCpmCents: 3000,
};

export const MONETIZATION_KEY = "monetization";

export async function getMonetizationConfig(): Promise<MonetizationConfig> {
  try {
    const rows = await db
      .select()
      .from(settings)
      .where(eq(settings.key, MONETIZATION_KEY))
      .limit(1);
    if (!rows[0]) return DEFAULT_MONETIZATION;
    return { ...DEFAULT_MONETIZATION, ...(rows[0].value as Partial<MonetizationConfig>) };
  } catch {
    return DEFAULT_MONETIZATION;
  }
}

export async function saveMonetizationConfig(value: MonetizationConfig): Promise<void> {
  await db
    .insert(settings)
    .values({ key: MONETIZATION_KEY, value, updatedAt: new Date() })
    .onConflictDoUpdate({
      target: settings.key,
      set: { value, updatedAt: new Date() },
    });
}

export function computeEarnings(
  config: MonetizationConfig,
  eligibleViews: number,
  isShorts = false,
): number {
  const cpm = isShorts ? config.shortsCpmCents : config.cpmCents;
  const gross = (eligibleViews / 1000) * cpm;
  return Math.round((gross * config.creatorSharePercent) / 100);
}
