export const CATEGORIES = [
  { slug: "all", name: "All" },
  { slug: "trending", name: "Trending" },
  { slug: "music", name: "Music" },
  { slug: "gaming", name: "Gaming" },
  { slug: "news", name: "News" },
  { slug: "comedy", name: "Comedy" },
  { slug: "education", name: "Education" },
  { slug: "technology", name: "Technology" },
  { slug: "movies", name: "Movies" },
  { slug: "sports", name: "Sports" },
  { slug: "shorts", name: "Shorts" },
] as const;

export const REPORT_CATEGORIES = [
  { value: "spam", label: "Spam or misleading" },
  { value: "harassment", label: "Harassment or hate" },
  { value: "copyright", label: "Copyright violation" },
  { value: "misleading", label: "Misleading content" },
  { value: "other", label: "Something else" },
] as const;

export const SORT_OPTIONS = [
  { value: "latest", label: "Latest" },
  { value: "views", label: "Most viewed" },
  { value: "likes", label: "Most liked" },
  { value: "duration", label: "Longest" },
] as const;

export const APP_NAME = "Hindustan Tube Pro";
