import { and, asc, desc, eq, ilike, inArray, isNull, ne, or, sql, type SQL } from "drizzle-orm";
import { db } from "@/db";
import {
  channels,
  comments,
  playlistItems,
  playlists,
  reactions,
  subscriptions,
  users,
  videos,
  watchHistory,
} from "@/db/schema";

export type VideoCard = {
  id: number;
  title: string;
  description: string;
  thumbnailUrl: string;
  videoUrl: string;
  durationSec: number;
  views: number;
  likeCount: number;
  dislikeCount: number;
  commentCount: number;
  category: string;
  tags: string[];
  isShort: boolean;
  audioTitle: string | null;
  visibility: string;
  status: string;
  createdAt: string;
  channelId: number;
  channelName: string;
  channelHandle: string;
  channelAvatar: string | null;
  channelVerified: boolean;
  subscriberCount: number;
};

const videoColumns = {
  id: videos.id,
  title: videos.title,
  description: videos.description,
  thumbnailUrl: videos.thumbnailUrl,
  videoUrl: videos.videoUrl,
  durationSec: videos.durationSec,
  views: videos.views,
  likeCount: videos.likeCount,
  dislikeCount: videos.dislikeCount,
  commentCount: videos.commentCount,
  category: videos.category,
  tags: videos.tags,
  isShort: videos.isShort,
  audioTitle: videos.audioTitle,
  visibility: videos.visibility,
  status: videos.status,
  createdAt: videos.createdAt,
  channelId: channels.id,
  channelName: channels.name,
  channelHandle: channels.handle,
  channelAvatar: channels.avatarUrl,
  channelVerified: channels.verified,
  subscriberCount: channels.subscriberCount,
};

type RawVideoRow = {
  createdAt: Date | string;
  tags: string[] | null;
} & Omit<VideoCard, "createdAt" | "tags">;

function normalise(rows: RawVideoRow[]): VideoCard[] {
  return rows.map((r) => ({
    ...r,
    tags: r.tags ?? [],
    createdAt: new Date(r.createdAt).toISOString(),
  }));
}

export type FeedOptions = {
  category?: string;
  query?: string;
  sort?: string;
  shorts?: boolean | "any";
  channelId?: number;
  page?: number;
  limit?: number;
  includeAllVisibility?: boolean;
};

function sortClause(sort?: string): SQL {
  switch (sort) {
    case "views":
      return desc(videos.views);
    case "likes":
      return desc(videos.likeCount);
    case "duration":
      return desc(videos.durationSec);
    case "oldest":
      return asc(videos.createdAt);
    default:
      return desc(videos.createdAt);
  }
}

export async function listVideos(opts: FeedOptions = {}): Promise<VideoCard[]> {
  const {
    category,
    query,
    sort,
    shorts = false,
    channelId,
    page = 1,
    limit = 12,
    includeAllVisibility = false,
  } = opts;

  const filters: SQL[] = [];
  if (!includeAllVisibility) {
    filters.push(eq(videos.visibility, "public"));
    filters.push(eq(videos.status, "published"));
  }
  if (shorts !== "any") filters.push(eq(videos.isShort, shorts));
  if (channelId) filters.push(eq(videos.channelId, channelId));
  if (category && category !== "all" && category !== "shorts") {
    filters.push(eq(videos.category, category));
  }
  if (query) {
    const like = `%${query}%`;
    const match = or(
      ilike(videos.title, like),
      ilike(videos.description, like),
      ilike(channels.name, like),
      sql`array_to_string(${videos.tags}, ',') ILIKE ${like}`,
    );
    if (match) filters.push(match);
  }

  const rows = await db
    .select(videoColumns)
    .from(videos)
    .innerJoin(channels, eq(channels.id, videos.channelId))
    .where(filters.length ? and(...filters) : undefined)
    .orderBy(sortClause(sort))
    .limit(limit)
    .offset((page - 1) * limit);

  return normalise(rows);
}

export async function getVideoById(id: number): Promise<VideoCard | null> {
  const rows = await db
    .select(videoColumns)
    .from(videos)
    .innerJoin(channels, eq(channels.id, videos.channelId))
    .where(eq(videos.id, id))
    .limit(1);
  const list = normalise(rows);
  return list[0] ?? null;
}

export async function getRelatedVideos(video: VideoCard, limit = 8): Promise<VideoCard[]> {
  const rows = await db
    .select(videoColumns)
    .from(videos)
    .innerJoin(channels, eq(channels.id, videos.channelId))
    .where(
      and(
        ne(videos.id, video.id),
        eq(videos.visibility, "public"),
        eq(videos.status, "published"),
        eq(videos.isShort, false),
      ),
    )
    .orderBy(desc(sql`CASE WHEN ${videos.category} = ${video.category} THEN 1 ELSE 0 END`), desc(videos.views))
    .limit(limit);
  return normalise(rows);
}

export async function getChannelByHandleOrId(key: string) {
  const numeric = Number(key);
  const clause = Number.isFinite(numeric) && String(numeric) === key
    ? eq(channels.id, numeric)
    : eq(channels.handle, key.replace(/^@/, ""));
  const rows = await db
    .select({
      id: channels.id,
      userId: channels.userId,
      name: channels.name,
      handle: channels.handle,
      description: channels.description,
      avatarUrl: channels.avatarUrl,
      bannerUrl: channels.bannerUrl,
      country: channels.country,
      verified: channels.verified,
      monetized: channels.monetized,
      subscriberCount: channels.subscriberCount,
      createdAt: channels.createdAt,
      ownerName: users.name,
    })
    .from(channels)
    .innerJoin(users, eq(users.id, channels.userId))
    .where(clause)
    .limit(1);
  return rows[0] ?? null;
}

export async function searchChannels(query: string, limit = 8) {
  if (!query) return [];
  return db
    .select({
      id: channels.id,
      name: channels.name,
      handle: channels.handle,
      avatarUrl: channels.avatarUrl,
      verified: channels.verified,
      subscriberCount: channels.subscriberCount,
      description: channels.description,
    })
    .from(channels)
    .where(or(ilike(channels.name, `%${query}%`), ilike(channels.handle, `%${query}%`)))
    .orderBy(desc(channels.subscriberCount))
    .limit(limit);
}

export type CommentNode = {
  id: number;
  body: string;
  likeCount: number;
  createdAt: string;
  status: string;
  userId: number;
  userName: string;
  userAvatar: string | null;
  parentId: number | null;
  replies: CommentNode[];
};

export async function getComments(videoId: number, sort: "top" | "new" = "top") {
  const rows = await db
    .select({
      id: comments.id,
      body: comments.body,
      likeCount: comments.likeCount,
      createdAt: comments.createdAt,
      status: comments.status,
      parentId: comments.parentId,
      userId: users.id,
      userName: users.name,
      userAvatar: users.avatarUrl,
    })
    .from(comments)
    .innerJoin(users, eq(users.id, comments.userId))
    .where(and(eq(comments.videoId, videoId), eq(comments.status, "visible")))
    .orderBy(sort === "top" ? desc(comments.likeCount) : desc(comments.createdAt))
    .limit(200);

  const map = new Map<number, CommentNode>();
  const roots: CommentNode[] = [];
  for (const r of rows) {
    map.set(r.id, {
      ...r,
      createdAt: new Date(r.createdAt).toISOString(),
      replies: [],
    });
  }
  for (const node of map.values()) {
    if (node.parentId && map.has(node.parentId)) {
      map.get(node.parentId)!.replies.push(node);
    } else if (!node.parentId) {
      roots.push(node);
    }
  }
  return roots;
}

export async function getViewerReaction(userId: number, videoId: number) {
  const rows = await db
    .select({ type: reactions.type })
    .from(reactions)
    .where(and(eq(reactions.userId, userId), eq(reactions.videoId, videoId)))
    .limit(1);
  return rows[0]?.type ?? null;
}

export async function isSubscribed(userId: number, channelId: number) {
  const rows = await db
    .select({ id: subscriptions.id })
    .from(subscriptions)
    .where(and(eq(subscriptions.userId, userId), eq(subscriptions.channelId, channelId)))
    .limit(1);
  return rows.length > 0;
}

export async function getSubscribedChannels(userId: number) {
  return db
    .select({
      id: channels.id,
      name: channels.name,
      handle: channels.handle,
      avatarUrl: channels.avatarUrl,
      verified: channels.verified,
      subscriberCount: channels.subscriberCount,
      notify: subscriptions.notify,
    })
    .from(subscriptions)
    .innerJoin(channels, eq(channels.id, subscriptions.channelId))
    .where(eq(subscriptions.userId, userId))
    .orderBy(asc(channels.name));
}

export async function getSubscriptionFeed(userId: number, limit = 20) {
  const subs = await db
    .select({ channelId: subscriptions.channelId })
    .from(subscriptions)
    .where(eq(subscriptions.userId, userId));
  if (!subs.length) return [];
  const rows = await db
    .select(videoColumns)
    .from(videos)
    .innerJoin(channels, eq(channels.id, videos.channelId))
    .where(
      and(
        inArray(videos.channelId, subs.map((s) => s.channelId)),
        eq(videos.visibility, "public"),
        eq(videos.status, "published"),
      ),
    )
    .orderBy(desc(videos.createdAt))
    .limit(limit);
  return normalise(rows);
}

export async function getWatchHistory(userId: number, limit = 30) {
  const rows = await db
    .select({ ...videoColumns, progressSec: watchHistory.progressSec, watchedAt: watchHistory.watchedAt })
    .from(watchHistory)
    .innerJoin(videos, eq(videos.id, watchHistory.videoId))
    .innerJoin(channels, eq(channels.id, videos.channelId))
    .where(eq(watchHistory.userId, userId))
    .orderBy(desc(watchHistory.watchedAt))
    .limit(limit);
  return rows.map((r) => ({
    ...normalise([r])[0],
    progressSec: r.progressSec,
    watchedAt: new Date(r.watchedAt).toISOString(),
  }));
}

export async function getLikedVideos(userId: number, limit = 30) {
  const rows = await db
    .select(videoColumns)
    .from(reactions)
    .innerJoin(videos, eq(videos.id, reactions.videoId))
    .innerJoin(channels, eq(channels.id, videos.channelId))
    .where(and(eq(reactions.userId, userId), eq(reactions.type, "like")))
    .orderBy(desc(reactions.createdAt))
    .limit(limit);
  return normalise(rows);
}

export async function getPlaylists(userId: number) {
  const rows = await db
    .select({
      id: playlists.id,
      title: playlists.title,
      visibility: playlists.visibility,
      system: playlists.system,
      createdAt: playlists.createdAt,
      count: sql<number>`(select count(*)::int from playlist_items pit where pit.playlist_id = playlists.id)`,
      cover: sql<
        string | null
      >`(select v.thumbnail_url from playlist_items pit join videos v on v.id = pit.video_id where pit.playlist_id = playlists.id order by pit.position asc limit 1)`,
    })
    .from(playlists)
    .where(eq(playlists.userId, userId))
    .orderBy(asc(playlists.id));
  return rows.map((r) => ({ ...r, createdAt: new Date(r.createdAt).toISOString() }));
}

export async function getPlaylistItems(playlistId: number) {
  const rows = await db
    .select({ ...videoColumns, position: playlistItems.position, itemId: playlistItems.id })
    .from(playlistItems)
    .innerJoin(videos, eq(videos.id, playlistItems.videoId))
    .innerJoin(channels, eq(channels.id, videos.channelId))
    .where(eq(playlistItems.playlistId, playlistId))
    .orderBy(asc(playlistItems.position));
  return rows.map((r) => ({ ...normalise([r])[0], position: r.position, itemId: r.itemId }));
}

export async function getSuggestions(query: string, limit = 8) {
  if (!query.trim()) return [];
  const rows = await db
    .select({ title: videos.title })
    .from(videos)
    .where(and(ilike(videos.title, `%${query}%`), eq(videos.visibility, "public")))
    .orderBy(desc(videos.views))
    .limit(limit);
  return rows.map((r) => r.title);
}

export async function getRootCommentCount(videoId: number) {
  const rows = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(comments)
    .where(and(eq(comments.videoId, videoId), isNull(comments.parentId)));
  return rows[0]?.count ?? 0;
}
