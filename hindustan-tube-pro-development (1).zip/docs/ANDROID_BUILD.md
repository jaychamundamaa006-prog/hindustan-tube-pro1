# Android Build Quick Reference

## Build a release APK
```bash
bash scripts/build-android.sh
```

Outputs:
- `android/app/build/outputs/apk/release/app-release.apk`
- `android/app/build/outputs/bundle/release/app-release.aab`

## Install on a device
```bash
adb install android/app/build/outputs/apk/release/app-release.apk
```

## Customise
- App id: `app/build.gradle` → `applicationId`
- Launch URL: `app/build.gradle` → `manifestPlaceholders.hostName`
- Keystore: generate one with `keytool` (see `android/keystore/README.md`)

## TWA verification (Android 12+)
Publish `public/.well-known/assetlinks.json` to your domain with the
SHA-256 fingerprint of the signing certificate. The fingerprint can be
retrieved with:
```bash
keytool -list -v -keystore android/keystore/release.keystore \
  -alias htp -storepass htp-storepass | grep SHA256
```
