# Generate the release keystore (run once per CI / machine)

```bash
keytool -genkey -v \
  -keystore android/keystore/release.keystore \
  -alias htp \
  -keyalg RSA -keysize 2048 -validity 36500 \
  -storepass htp-storepass \
  -keypass   htp-keypass \
  -dname "CN=Hindustan Tube Pro, OU=Mobile, O=Hindustan Tube Labs, L=Mumbai, S=MH, C=IN"
```

The bundled `build.gradle` reads the credentials from environment variables
(HTP_KEYSTORE, HTP_KEYSTORE_PWD, HTP_KEY_ALIAS, HTP_KEY_PWD) with these
matching defaults so the first build "just works".

To override the host, set `HTP_HOST` before `assembleRelease`. The `manifestPlaceholders`
default to `hindustantube.pro` (your production domain) — change it to your preview
host when building the development APK.
