#!/usr/bin/env bash
# Hindustan Tube Pro — full release pipeline
# 1) Builds the Next.js web app (static export + images)
# 2) Generates a release APK + AAB (Trusted Web Activity shell)
#
# Requires:  Node 18+, JDK 17, Android SDK 34+ (or Android Studio Koala+)
#
# Environment variables (optional — defaults supplied):
#   HTP_HOST              Production host (default: hindustantube.pro)
#   HTP_KEYSTORE          Keystore file path (default: android/keystore/release.keystore)
#   HTP_KEYSTORE_PWD      Storepass
#   HTP_KEY_ALIAS         Key alias (default: htp)
#   HTP_KEY_PWD           Keypass

set -euo pipefail

HTP_HOST=${HTP_HOST:-hindustantube.pro}
SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
ROOT_DIR=$(cd "$SCRIPT_DIR/.." && pwd)
ANDROID_DIR="$ROOT_DIR/android"

echo ""
echo "╔══════════════════════════════════════════════╗"
echo "║  Hindustan Tube Pro · release pipeline        ║"
echo "╚══════════════════════════════════════════════╝"
echo "  host:  $HTP_HOST"
echo "  android: $ANDROID_DIR"
echo ""

# ---- 1. Web build (already happens via next build) -----------------
echo "▸ Step 1/3  Building Next.js production bundle…"
(cd "$ROOT_DIR" && npm run build) || {
  echo "✖ Web build failed" >&2
  exit 1
}
echo "✔ Web build complete"
echo ""

# ---- 2. Ensure keystore exists -------------------------------------
echo "▸ Step 2/3  Preparing signing keystore…"
mkdir -p "$ANDROID_DIR/keystore"
if [ ! -f "$ANDROID_DIR/keystore/release.keystore" ]; then
  echo "  ↳ No keystore found, generating a new one (validity 36500 days)…"
  keytool -genkey -noprompt -v \
    -keystore "$ANDROID_DIR/keystore/release.keystore" \
    -alias "${HTP_KEY_ALIAS:-htp}" \
    -keyalg RSA -keysize 2048 -validity 36500 \
    -storepass "${HTP_KEYSTORE_PWD:-htp-storepass}" \
    -keypass   "${HTP_KEY_PWD:-htp-keypass}" \
    -dname "CN=Hindustan Tube Pro, O=Hindustan Tube Labs, C=IN"
else
  echo "  ↳ Existing keystore found, reusing"
fi
echo "✔ Keystore ready"
echo ""

# ---- 3. Build the APK + AAB ----------------------------------------
echo "▸ Step 3/3  Building APK + AAB (this may take a few minutes)…"
(cd "$ANDROID_DIR" && ./gradlew clean assembleRelease bundleRelease --no-daemon)

APK_PATH="$ANDROID_DIR/app/build/outputs/apk/release/app-release.apk"
AAB_PATH="$ANDROID_DIR/app/build/outputs/bundle/release/app-release.aab"

echo ""
echo "╔══════════════════════════════════════════════╗"
echo "║  Build complete                              ║"
echo "╠══════════════════════════════════════════════╣"
if [ -f "$APK_PATH" ]; then
  APK_SIZE=$(du -h "$APK_PATH" | cut -f1)
  echo "║  ✔ APK  →  $APK_PATH ($APK_SIZE)"
fi
if [ -f "$AAB_PATH" ]; then
  AAB_SIZE=$(du -h "$AAB_PATH" | cut -f1)
  echo "║  ✔ AAB  →  $AAB_PATH ($AAB_SIZE)"
fi
echo "╚══════════════════════════════════════════════╝"
echo ""
echo "Next steps:"
echo "  1. Install on a device:  adb install $APK_PATH"
echo "  2. Upload AAB to Play Store"
echo "  3. Publish .well-known/assetlinks.json to https://$HTP_HOST"
echo ""
