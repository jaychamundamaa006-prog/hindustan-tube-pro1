import { randomBytes, scryptSync } from "node:crypto";
import { readFileSync } from "node:fs";
import pg from "pg";

const envFile = (() => {
  try {
    return readFileSync(new URL("../.env", import.meta.url), "utf8");
  } catch {
    return "";
  }
})();
const envUrl = /DATABASE_URL\s*=\s*"?([^"\n]+)"?/.exec(envFile)?.[1];
const connectionString =
  process.env.DATABASE_URL ?? envUrl ?? "postgresql://postgres:postgres@127.0.0.1:5432/app_db";

const client = new pg.Client({ connectionString });

function hash(password) {
  const salt = randomBytes(16).toString("hex");
  return `${salt}:${scryptSync(password, salt, 64).toString("hex")}`;
}

const V = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/";
const pic = (seed) => `https://picsum.photos/seed/${seed}/1280/720`;

const CREATORS = [
  {
    name: "Aarav Mehta",
    username: "aarav",
    email: "aarav@htp.app",
    channel: "Aarav Builds",
    handle: "aaravbuilds",
    desc: "Deep dives into Android, Flutter and everything that ships to a billion phones. New build logs every Tuesday.",
    subs: 184000,
    avatar: "https://i.pravatar.cc/200?img=12",
    banner: pic("aarav-banner"),
  },
  {
    name: "Priya Sharma",
    username: "priya",
    email: "priya@htp.app",
    channel: "Priya Beats",
    handle: "priyabeats",
    desc: "Independent music, studio sessions and live acoustic covers recorded across India.",
    subs: 921000,
    avatar: "https://i.pravatar.cc/200?img=45",
    banner: pic("priya-banner"),
  },
  {
    name: "Rohan Verma",
    username: "rohan",
    email: "rohan@htp.app",
    channel: "Rohan Plays",
    handle: "rohanplays",
    desc: "Competitive gameplay, ranked grinds and honest reviews. No sponsor fluff.",
    subs: 432000,
    avatar: "https://i.pravatar.cc/200?img=33",
    banner: pic("rohan-banner"),
  },
  {
    name: "Ananya Iyer",
    username: "ananya",
    email: "ananya@htp.app",
    channel: "Ananya Learns",
    handle: "ananyalearns",
    desc: "Physics, maths and exam strategy explained in plain language for students across India.",
    subs: 76000,
    avatar: "https://i.pravatar.cc/200?img=28",
    banner: pic("ananya-banner"),
  },
  {
    name: "Kabir Singh",
    username: "kabir",
    email: "kabir@htp.app",
    channel: "Kabir Laughs",
    handle: "kabirlaughs",
    desc: "Stand-up clips, street interviews and sketches shot on the streets of Delhi.",
    subs: 1250000,
    avatar: "https://i.pravatar.cc/200?img=52",
    banner: pic("kabir-banner"),
  },
  {
    name: "Meera Nair",
    username: "meera",
    email: "meera@htp.app",
    channel: "Meera Travels",
    handle: "meeratravels",
    desc: "Slow travel films from the Western Ghats to the Himalayas. Shot on a single lens.",
    subs: 58000,
    avatar: "https://i.pravatar.cc/200?img=20",
    banner: pic("meera-banner"),
  },
];

const LONG = [
  ["Building a 60fps video feed in Android", "technology", `${V}BigBuckBunny.mp4`, 596, ["android", "performance", "ui"]],
  ["Why your app feels slow (and how to fix it)", "technology", `${V}ElephantsDream.mp4`, 653, ["profiling", "jank"]],
  ["Material 3 from scratch — full walkthrough", "technology", `${V}ForBiggerBlazes.mp4`, 15, ["material3", "design"]],
  ["Late night acoustic session in Bandra", "music", `${V}ForBiggerEscapes.mp4`, 15, ["acoustic", "live"]],
  ["Studio diary: mixing our first EP", "music", `${V}ForBiggerFun.mp4`, 60, ["studio", "mixing"]],
  ["Monsoon melodies — full concert", "music", `${V}ForBiggerJoyrides.mp4`, 15, ["concert", "indie"]],
  ["Ranked grind to the top 500", "gaming", `${V}ForBiggerMeltdowns.mp4`, 15, ["ranked", "fps"]],
  ["This budget controller changed my aim", "gaming", `${V}Sintel.mp4`, 888, ["gear", "review"]],
  ["Rotational motion made ridiculously simple", "education", `${V}SubaruOutbackOnStreetAndDirt.mp4`, 594, ["physics", "jee"]],
  ["How to revise 3 chapters in one evening", "education", `${V}TearsOfSteel.mp4`, 734, ["studytips", "exams"]],
  ["Auto rickshaw stand-up — uncut set", "comedy", `${V}VolkswagenGTIReview.mp4`, 170, ["standup", "delhi"]],
  ["We asked strangers the worst question", "comedy", `${V}WeAreGoingOnBullrun.mp4`, 47, ["sketch", "street"]],
  ["48 hours in the Western Ghats", "movies", `${V}WhatCarCanYouGetForAGrand.mp4`, 147, ["travel", "film"]],
  ["Sunrise at Nandi Hills — a short film", "movies", `${V}BigBuckBunny.mp4`, 596, ["cinematic", "karnataka"]],
  ["India vs the world: match breakdown", "sports", `${V}ElephantsDream.mp4`, 653, ["cricket", "analysis"]],
  ["Morning news roundup — what actually matters", "news", `${V}Sintel.mp4`, 888, ["news", "daily"]],
  ["The truth about creator payouts", "trending", `${V}TearsOfSteel.mp4`, 734, ["creators", "money"]],
  ["I rebuilt my studio for ₹40,000", "technology", `${V}ForBiggerJoyrides.mp4`, 15, ["setup", "budget"]],
];

const SHORTS = [
  ["One tip that fixed my recycler lag", "technology", "https://videos.pexels.com/video-files/4540400/4540400-hd_1080_1920_25fps.mp4", "https://images.pexels.com/videos/4540400/dance-dancer-dancing-female-4540400.jpeg?auto=compress&cs=tinysrgb&h=1200&w=630", "Original audio · Aarav Builds"],
  ["Hook of the week 🎧", "music", "https://videos.pexels.com/video-files/4540343/4540343-hd_1080_1920_25fps.mp4", "https://images.pexels.com/videos/4540343/dance-dancer-dancing-female-4540343.jpeg?auto=compress&cs=tinysrgb&h=1200&w=630", "Monsoon Melody · Priya Beats"],
  ["Street dance takeover", "comedy", "https://videos.pexels.com/video-files/8928293/8928293-hd_1080_1920_30fps.mp4", "https://images.pexels.com/videos/8928293/pexels-photo-8928293.jpeg?auto=compress&cs=tinysrgb&h=1200&w=630", "Dhol Remix · Kabir Laughs"],
  ["Clutch in the last 3 seconds", "gaming", "https://videos.pexels.com/video-files/4540339/4540339-hd_1080_1920_25fps.mp4", "https://images.pexels.com/videos/4540339/dance-dancer-dancing-female-4540339.jpeg?auto=compress&cs=tinysrgb&h=1200&w=630", "Original audio · Rohan Plays"],
  ["Formula you keep forgetting", "education", "https://videos.pexels.com/video-files/7677455/7677455-hd_1080_1920_25fps.mp4", "https://images.pexels.com/videos/7677455/adult-airport-architecture-art-7677455.jpeg?auto=compress&cs=tinysrgb&h=1200&w=630", "Original audio · Ananya Learns"],
  ["Airport to Alleppey in 30 seconds", "movies", "https://videos.pexels.com/video-files/10251172/10251172-uhd_2160_4096_25fps.mp4", "https://images.pexels.com/videos/10251172/adult-bearded-bench-bridge-10251172.jpeg?auto=compress&cs=tinysrgb&h=1200&w=630", "Kerala Lo-fi · Meera Travels"],
  ["Beat drop challenge", "music", "https://videos.pexels.com/video-files/4540330/4540330-uhd_2160_3840_25fps.mp4", "https://images.pexels.com/videos/4540330/dance-dancer-dancing-female-4540330.jpeg?auto=compress&cs=tinysrgb&h=1200&w=630", "Bass Line 04 · Priya Beats"],
  ["Hip hop reel — take 12", "comedy", "https://videos.pexels.com/video-files/10264586/10264586-uhd_2160_4096_25fps.mp4", "https://images.pexels.com/videos/10264586/pexels-photo-10264586.jpeg?auto=compress&cs=tinysrgb&h=1200&w=630", "Original audio · Kabir Laughs"],
];

const COMMENT_BODIES = [
  "This is exactly what I needed today, thank you 🙏",
  "The editing on this is genuinely next level.",
  "Watched twice. The second half is worth the wait.",
  "Please make a part two of this!",
  "Finally someone explaining it without 10 minutes of intro.",
  "Sharing this with my whole batch.",
  "Underrated channel, algorithm please do your thing.",
  "That transition at the halfway mark 🔥",
  "Quick question — which mic are you using?",
  "The audio mix here is so clean.",
];

async function main() {
  await client.connect();

  const existing = await client.query("select count(*)::int as c from users");
  if (existing.rows[0].c > 0) {
    console.log("Seed skipped — users already exist.");
    await client.end();
    return;
  }

  await client.query(
    `insert into categories (name, slug, sort_order) values
      ('Trending','trending',1),('Music','music',2),('Gaming','gaming',3),('News','news',4),
      ('Comedy','comedy',5),('Education','education',6),('Technology','technology',7),
      ('Movies','movies',8),('Sports','sports',9)
     on conflict (slug) do nothing`,
  );

  const admin = await client.query(
    `insert into users (name, username, email, phone, password_hash, avatar_url, role, verified)
     values ($1,$2,$3,$4,$5,$6,'admin',true) returning id`,
    ["Platform Admin", "admin", "admin@htp.app", "+919000000000", hash("admin12345"), "https://i.pravatar.cc/200?img=7"],
  );
  const adminId = admin.rows[0].id;

  const viewer = await client.query(
    `insert into users (name, username, email, password_hash, avatar_url, role)
     values ($1,$2,$3,$4,$5,'user') returning id`,
    ["Nikhil Rao", "nikhil", "nikhil@htp.app", hash("password123"), "https://i.pravatar.cc/200?img=15"],
  );
  const viewerId = viewer.rows[0].id;

  const channelIds = [];
  const userIds = [];
  for (const c of CREATORS) {
    const u = await client.query(
      `insert into users (name, username, email, phone, password_hash, avatar_url, role, verified)
       values ($1,$2,$3,$4,$5,$6,'creator',$7) returning id`,
      [c.name, c.username, c.email, null, hash("password123"), c.avatar, c.subs > 100000],
    );
    const uid = u.rows[0].id;
    userIds.push(uid);
    const ch = await client.query(
      `insert into channels (user_id, name, handle, description, avatar_url, banner_url, verified, monetized, subscriber_count)
       values ($1,$2,$3,$4,$5,$6,$7,true,$8) returning id`,
      [uid, c.channel, c.handle, c.desc, c.avatar, c.banner, c.subs > 100000, c.subs],
    );
    channelIds.push(ch.rows[0].id);

    await client.query(
      `insert into playlists (user_id, title, visibility, system) values
        ($1,'Watch Later','private','watch_later'),($1,'Liked Videos','private','liked')`,
      [uid],
    );
  }

  await client.query(
    `insert into playlists (user_id, title, visibility, system) values
      ($1,'Watch Later','private','watch_later'),($1,'Liked Videos','private','liked'),
      ($1,'Weekend binge','public',null)`,
    [viewerId],
  );

  const videoIds = [];
  let i = 0;
  for (const [title, category, url, duration, tags] of LONG) {
    const channelId = channelIds[i % channelIds.length];
    const daysAgo = Math.floor(Math.random() * 120) + 1;
    const views = Math.floor(Math.random() * 900000) + 5000;
    const likes = Math.floor(views * (0.03 + Math.random() * 0.05));
    const r = await client.query(
      `insert into videos (channel_id, title, description, video_url, thumbnail_url, category, tags, duration_sec,
        is_short, visibility, status, views, like_count, dislike_count, watch_minutes, created_at)
       values ($1,$2,$3,$4,$5,$6,$7,$8,false,'public','published',$9,$10,$11,$12, now() - ($13 || ' days')::interval)
       returning id`,
      [
        channelId,
        title,
        `${title}.\n\nIn this episode we go end to end — planning, shooting and shipping. Timestamps, links and the full gear list are below.\n\nChapters:\n00:00 Intro\n01:20 The problem\n04:10 Walkthrough\n09:30 Results\n\n#HindustanTubePro`,
        url,
        pic(`htp-${i}-${category}`),
        category,
        tags,
        duration,
        views,
        likes,
        Math.floor(likes * 0.04),
        Math.floor((views * duration) / 60 / 3),
        daysAgo,
      ],
    );
    videoIds.push(r.rows[0].id);
    i += 1;
  }

  let s = 0;
  for (const [title, category, url, thumb, audio] of SHORTS) {
    const channelId = channelIds[s % channelIds.length];
    const views = Math.floor(Math.random() * 2500000) + 20000;
    const r = await client.query(
      `insert into videos (channel_id, title, description, video_url, thumbnail_url, category, tags, duration_sec,
        is_short, audio_title, visibility, status, views, like_count, watch_minutes, created_at)
       values ($1,$2,$3,$4,$5,$6,$7,$8,true,$9,'public','published',$10,$11,$12, now() - ($13 || ' days')::interval)
       returning id`,
      [
        channelId,
        title,
        "Full version on the channel 👀",
        url,
        thumb,
        category,
        [category, "shorts"],
        Math.floor(Math.random() * 40) + 12,
        audio,
        views,
        Math.floor(views * 0.08),
        Math.floor(views / 60),
        Math.floor(Math.random() * 40) + 1,
      ],
    );
    videoIds.push(r.rows[0].id);
    s += 1;
  }

  // Comments
  const commenters = [viewerId, adminId, ...userIds];
  for (const videoId of videoIds) {
    const n = Math.floor(Math.random() * 4) + 1;
    for (let k = 0; k < n; k += 1) {
      const author = commenters[Math.floor(Math.random() * commenters.length)];
      const parent = await client.query(
        `insert into comments (video_id, user_id, body, like_count, created_at)
         values ($1,$2,$3,$4, now() - ($5 || ' hours')::interval) returning id`,
        [
          videoId,
          author,
          COMMENT_BODIES[Math.floor(Math.random() * COMMENT_BODIES.length)],
          Math.floor(Math.random() * 400),
          Math.floor(Math.random() * 400),
        ],
      );
      if (Math.random() > 0.6) {
        await client.query(
          `insert into comments (video_id, user_id, parent_id, body, like_count)
           values ($1,$2,$3,$4,$5)`,
          [videoId, userIds[Math.floor(Math.random() * userIds.length)], parent.rows[0].id, "Appreciate it — noted for the next one!", Math.floor(Math.random() * 60)],
        );
      }
    }
    await client.query(
      `update videos set comment_count = (select count(*) from comments where video_id = $1) where id = $1`,
      [videoId],
    );
  }

  // Subscriptions
  for (const channelId of channelIds) {
    await client.query(
      `insert into subscriptions (user_id, channel_id) values ($1,$2) on conflict do nothing`,
      [viewerId, channelId],
    );
  }
  for (let k = 1; k < channelIds.length; k += 1) {
    await client.query(
      `insert into subscriptions (user_id, channel_id) values ($1,$2) on conflict do nothing`,
      [userIds[0], channelIds[k]],
    );
  }

  // Watch history + reactions for the demo viewer accounts
  for (const uid of [viewerId, userIds[0]]) {
    for (const videoId of videoIds.slice(0, 6)) {
      await client.query(
        `insert into watch_history (user_id, video_id, progress_sec, watched_at)
         values ($1,$2,$3, now() - ($4 || ' hours')::interval) on conflict do nothing`,
        [uid, videoId, Math.floor(Math.random() * 200), Math.floor(Math.random() * 100)],
      );
      if (Math.random() > 0.5) {
        await client.query(
          `insert into reactions (user_id, video_id, type) values ($1,$2,'like') on conflict do nothing`,
          [uid, videoId],
        );
      }
    }
  }

  // Daily analytics for the last 30 days
  for (const channelId of channelIds) {
    for (let d = 29; d >= 0; d -= 1) {
      const base = 800 + Math.floor(Math.random() * 5200);
      await client.query(
        `insert into analytics_daily (channel_id, day, views, watch_minutes, subscribers_gained, likes, eligible_views)
         values ($1, (current_date - $2::int), $3, $4, $5, $6, $7) on conflict do nothing`,
        [
          channelId,
          d,
          base,
          Math.floor(base * (1.4 + Math.random())),
          Math.floor(Math.random() * 260),
          Math.floor(base * 0.06),
          Math.floor(base * 0.86),
        ],
      );
    }
  }

  // Notifications for the first creator
  await client.query(
    `insert into notifications (user_id, type, title, body, link) values
      ($1,'system','Welcome to Hindustan Tube Pro 🎉','Your creator dashboard is ready.','/studio'),
      ($1,'subscriber','New subscriber','Nikhil Rao subscribed to your channel','/studio'),
      ($1,'comment','New comment on your video','"That transition at the halfway mark 🔥"','/home')`,
    [userIds[0]],
  );
  await client.query(
    `insert into notifications (user_id, type, title, body, link) values
      ($1,'system','Moderation queue','2 reports are waiting for review.','/admin')`,
    [adminId],
  );

  // Reports and payouts
  await client.query(
    `insert into reports (reporter_id, target_type, target_id, category, note) values
      ($1,'video',$2,'copyright','Background music appears to be licensed.'),
      ($1,'video',$3,'spam','Description is full of unrelated links.')`,
    [viewerId, videoIds[2], videoIds[5]],
  );
  await client.query(
    `insert into withdrawals (channel_id, amount_cents, method, account, status) values
      ($1, 250000, 'upi', 'aarav@upi', 'pending'),
      ($2, 780000, 'bank', 'HDFC ****4412', 'paid')`,
    [channelIds[0], channelIds[1]],
  );

  await client.query(
    `insert into settings (key, value) values ('monetization', $1)
     on conflict (key) do nothing`,
    [
      JSON.stringify({
        enabled: true,
        minSubscribers: 1000,
        minEligibleViews: 10000,
        minWatchMinutes: 4000,
        cpmCents: 12000,
        shortsCpmCents: 3000,
        creatorSharePercent: 55,
        minWithdrawalCents: 100000,
        adsEnabled: true,
      }),
    ],
  );

  console.log(`Seeded ${CREATORS.length} channels and ${videoIds.length} videos.`);
  await client.end();
}

main().catch(async (err) => {
  console.error(err);
  try {
    await client.end();
  } catch {
    /* ignore */
  }
  process.exit(1);
});
