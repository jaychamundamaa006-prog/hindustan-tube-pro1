# Hindustan Tube Pro

A premium, original video-sharing platform — long-form videos **and** vertical Shorts — with a full
creator studio, monetization framework and secure admin console.

The app is delivered as a **mobile-first, installable web application** (Next.js App Router +
PostgreSQL/Drizzle) so it runs on Android, iOS and desktop from a single codebase, and it ships with
the Firebase security-rule set and Android packaging configuration described below.

---

## 1. Feature map

| Area | Route | Highlights |
| --- | --- | --- |
| Splash | `/splash` | Animated brand splash, first-run detection |
| Onboarding | `/onboarding` | 3-slide tour, skip, guest mode |
| Auth | `/login`, `/signup` | Email + password, phone **OTP**, Google, forgot-password, guest browsing |
| Home | `/home` | Category chips, Shorts rail, infinite scroll, pull-to-refresh, skeletons |
| Search | `/search` | Suggestions, history (+clear), filter by videos/shorts/channels, sort by latest/views/likes/duration |
| Watch | `/video/:id` | Custom player: play/pause, seek, ±10s, volume, speed, quality, captions, PiP, fullscreen, autoplay-next, related |
| Shorts | `/shorts` | Full-screen 9:16, snap swipe, autoplay, like/comment/share/save/follow/report, audio credit |
| Upload | `/upload` | Real file upload with progress, cancel, retry, validation, visibility, tags, Shorts toggle |
| Studio | `/studio` | Views/watch-time/subscriber graphs, top videos, audience overview, content CRUD, earnings + withdrawals |
| Channel | `/channel/:handle` | Banner, avatar, tabs: Home / Videos / Shorts / Playlists / About |
| Library | `/library` | History (+progress), Playlists CRUD, Liked, Watch Later, Your videos, Downloads UI |
| Subscriptions | `/subscriptions` | Subscribed rail, new shorts, latest uploads |
| Notifications | `/notifications` | Subscriber/like/comment/reply/upload/system, mark read, mark all, delete |
| Settings | `/settings` | Account, appearance (dark/light), notifications, playback, privacy, security, language, help, about, logout |
| Admin | `/admin` | Dashboard KPIs, user management, content moderation, comments, reports, payouts, **configurable monetization** |

Every screen implements **loading, empty, error, retry and offline** states — no blank screens.

---

## 2. Design system

* Material-3 inspired, original branding (no third-party marks).
* Poppins typography, rounded 2xl cards, 60fps CSS transitions and spring-like easing.
* Palette: primary `#FF3B30`, secondary `#1E88E5`, accent `#FFC107`, dark bg `#0F1115`,
  surface `#181A20`, success `#00C853`, error `#FF1744`.
* Class-based dark/light theming with a no-flash inline theme bootstrap script.
* Persistent 5-tab bottom navigation: Home · Shorts · Create · Subscriptions · Library.

---

## 3. Architecture

```
src/
├── app/
│   ├── (main)/            # authenticated shell: home, shorts, video, channel, upload,
│   │                      # studio, library, subscriptions, notifications, settings, search
│   ├── admin/             # secure admin console
│   ├── api/               # route handlers (auth, videos, media, comments, engage,
│   │                      # playlists, notifications, search, studio, admin, health)
│   ├── login|signup|onboarding|splash/
│   └── layout.tsx globals.css
├── components/            # UI layer (AppChrome, VideoCard, VideoFeed, VideoPlayer,
│                          # ShortsPlayer, CommentsPanel, StudioView, AdminView, …)
├── db/                    # Drizzle schema + pooled client
├── lib/                   # auth, api helpers, repositories (queries), settings, formatters
└── scripts/seed.mjs       # deterministic demo data
```

Concerns are separated exactly as requested: **UI** (`components`), **business logic / services**
(`lib`), **repositories** (`lib/queries.ts`), **data models** (`db/schema.ts`), **navigation**
(App Router route groups) and **state** (colocated React state + server components).

---

## 4. Data model

`users → channels → videos → {comments, reactions, watch_history, playlist_items, reports}`,
plus `subscriptions`, `playlists`, `notifications`, `analytics_daily`, `withdrawals`, `settings`,
`search_history`, `categories` and a binary `media` store used for real uploads.
All hot paths are indexed (`videos_channel_idx`, `videos_category_idx`, `videos_created_idx`,
`comments_video_idx`, unique composite indexes on reactions/subscriptions/history) and every list
endpoint is paginated.

---

## 5. Security

* Server-side sessions (`scrypt` password hashing, HTTP-only SameSite cookies, 30-day expiry).
* Role verification for **admin** and **creator** actions on every mutating endpoint.
* Ownership checks on video edit/delete, playlist mutation and comment deletion.
* Input validation + length clamping on all payloads; upload MIME/size allow-list.
* In-memory sliding-window rate limiting per IP for auth, uploads, comments and reports.
* Full report/moderation pipeline (spam, harassment, copyright, misleading, other).
* No secrets in client code — everything sensitive lives in route handlers.

Firebase parity is shipped in [`firebase/firestore.rules`](firebase/firestore.rules) and
[`firebase/storage.rules`](firebase/storage.rules), covering the collections
`users, videos, shorts, channels, comments, likes, subscriptions, playlists, watch_history,
notifications, reports, analytics, earnings, withdrawals, categories, settings`.

---

## 6. Monetization (fully configurable — nothing hard-coded)

Admin → **Monetization** tab controls:
eligibility (min subscribers, eligible views, watch minutes), revenue per 1,000 views, separate
Shorts RPM, creator revenue share %, minimum withdrawal, programme + ads on/off.
Creators see eligible views, estimated/total/pending/withdrawn earnings and withdrawal history;
admins approve, reject or mark payouts as paid.

---

## 7. Android packaging

The app is PWA-installable. To ship an APK/AAB, wrap it with a Trusted Web Activity:

```gradle
// android/app/build.gradle
android {
    namespace "app.htp.pro"
    compileSdk 35
    defaultConfig {
        applicationId "app.htp.pro"
        minSdk 24
        targetSdk 35
        versionCode 100
        versionName "1.0.0"
        manifestPlaceholders = [
            hostName            : "your-deployment-host",
            defaultUrl          : "https://your-deployment-host/splash",
            launcherName        : "Hindustan Tube Pro",
            statusBarColor      : "@color/colorPrimaryDark"
        ]
    }
    buildTypes {
        release {
            minifyEnabled true
            shrinkResources true
            signingConfig signingConfigs.release
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
        }
    }
    bundle { language { enableSplit = true } }
}
dependencies { implementation "com.google.androidbrowser:browser:1.8.0" }
```

`./gradlew assembleRelease` → APK, `./gradlew bundleRelease` → Play Store AAB.

---

## 8. Demo accounts

| Role | Email | Password |
| --- | --- | --- |
| Admin | `admin@htp.app` | `admin12345` |
| Creator | `aarav@htp.app` | `password123` |
| Viewer | `nikhil@htp.app` | `password123` |

Phone OTP sign-in works end to end — the sandbox echoes the generated code in the UI.

---

## 9. Local development

```bash
npm install
npx drizzle-kit push     # apply schema
node scripts/seed.mjs    # demo content (idempotent)
npm run dev
```
