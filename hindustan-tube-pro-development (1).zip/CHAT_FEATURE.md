# Chat & Messaging System — Hindustan Tube Pro

A production-ready real-time chat system integrated into the video platform.

## Features Implemented

### 1. Direct Messaging
- Text messages between any two registered users
- Auto-create chat on first message
- Block/unblock users to prevent messages
- See online/offline status

### 2. Group Chats
- Create group conversations
- Add/remove members
- Admin controls (rename, change photo, manage members)
- Leave group without deleting history

### 3. Message Types
- **Text** — plain text with emoji support
- **Video Share** — send video preview card with title, thumbnail, quick open button
- **Short Share** — share vertical shorts to chat
- **Media** — images stored in Firebase Storage

### 4. Real-time Features
- Typing indicators
- Read receipts (message-level)
- Online presence (shows "Online" or "Last seen X ago")
- Auto-delete presence after 5 seconds of inactivity

### 5. Message Management
- Delete own messages (soft-delete, visible as "[Deleted]")
- Reply to specific messages
- Copy message text
- Report inappropriate messages

### 6. Chat UI
- Message list grouped by date
- Infinite scroll (pagination)
- Optimistic sending (show message immediately, retry on fail)
- Auto-scroll to latest
- Smooth animations
- Dark and light theme support

### 7. Navigation
- **Chat Tab** in bottom navigation (replaces subscriptions, between Create and Library)
- Chat list with unread badge, last message preview, timestamp
- Online indicator next to user name

### 8. Notifications
When disabled notifications are on:
- "New message from [User]" with preview
- Sent when user is not actively reading the chat
- Tappable to open chat and mark as read

### 9. Settings
Users control:
- Mute chat (8 hours, 24 hours, 1 week, or forever)
- Read receipts (on/off per user)
- Online visibility (show/hide status)
- Archive chat (hides from list, keeps history)
- Block user

### 10. Search & Discovery
- Search chats by user name
- Recent contacts list
- Suggested chats (mutual followers)

---

## Database Schema (PostgreSQL + Drizzle)

```
chats (1-to-many with messages and chatMembers)
├── id, type (direct/group), name, photoUrl, creatorId
├── lastMessageId, lastMessageTime
└── createdAt

chatMembers (join table)
├── chatId, userId, role (member/admin)
├── mutedUntil, leftAt, joinedAt

messages
├── chatId, senderId, type (text/image/video_share)
├── body, mediaUrl, videoId, replyToId
├── deletedAt (soft-delete)
└── createdAt

messageReads (read receipt)
├── messageId, userId, readAt

blockedUsers
├── userId, blockedUserId
└── createdAt

userPresence
├── userId (PK)
├── online, lastSeenAt
```

Every query includes `where status != 'suspended'` to hide suspended accounts.

---

## API Endpoints

### `POST /api/chat`

**Actions:**

1. **send-direct** — Create/send to 1:1 chat
   - `recipientId`, `text`, optional `replyToId`
   - Returns `{ chatId, messageId }`

2. **send-video-share** — Share video to chat
   - `chatId`, `videoId`, optional `caption`

3. **delete** — Soft-delete own message
   - `messageId`

4. **block** — Block a user
   - `userId`

5. **unblock** — Unblock a user
   - `userId`

6. **create-group** — Create group chat
   - `name`, `members` (array of user IDs)
   - Returns `{ chatId }`

7. **mute** — Mute notifications
   - `chatId`, `hours`

8. **leave** — Leave a group

### `GET /api/chat`

**Modes:**

1. **list** (default) — Get user's chats
   - Query: `?mode=list&limit=20&offset=0`
   - Returns: `{ chats: [...] }`
   - Includes unread count, last message preview, member count

2. **messages** — Get messages in a chat
   - Query: `?mode=messages&chatId=1&limit=50&offset=0`
   - Returns: `{ messages: [...] }`
   - Auto-marks messages as read by current user

### `GET /api/chat/search`

- Query: `?q=username`
- Returns list of users to start chat with
- Requires min 2 characters

---

## Firebase Realtime Integration

If migrating to Firebase for real-time:

### Firestore Collections

```
chats/{chatId}
├── type, name, photoUrl, lastMessage, lastMessageTime
├── members/{userId} → { role, joinedAt, online }
├── messages/{messageId} → { senderId, type, text, createdAt, deletedAt }
├── typing/{userId} → { uid, timestamp } (auto-delete after 5s)
└── presence/{userId} → { uid, online, lastSeen }
```

### Security Rules

See `firebase/chat-firestore.rules` and `firebase/chat-storage.rules` for:
- Members-only access to chats and messages
- Users can only delete their own messages
- Admins can manage group settings
- Block list prevents receiving messages
- Presence is ephemeral and user-specific

---

## Frontend Components

### `<ChatListItem />`
Displays one chat in the list:
- Avatar, name/title
- Last message preview, timestamp
- Unread badge
- Member count (for groups)

### `<ChatView />`
Full chat interface:
- Message history with infinite scroll
- Message grouping by date
- Reply indicator
- Video share preview cards
- Input field with emoji
- Delete/report buttons
- Typing indicator
- Read receipt (checkmark)
- Menu: mute, share, clear, delete

### Chat Page (`/chat`)
- Search bar (search users)
- Chat list (sorted by most recent)
- Unread count per chat
- Start new chat modal

### Chat Detail Page (`/chat/:id`)
- Full chat view
- Input area with send button
- Menu options

---

## Performance & Optimization

### Database
- Indexes on `chatId`, `userId`, `createdAt`
- Pagination (default 50 messages per load)
- Lazy load older messages
- Mark reads in background (non-blocking)

### Frontend
- Message virtualization (show ~20 visible, load more on scroll)
- Optimistic send (show message immediately)
- Debounce typing indicator (not on every keystroke)
- Cache user profiles to avoid re-fetching
- Image compression before upload

### Firebase (if used)
- Real-time listeners only on active chat
- Presence data auto-deletes
- Typing collection auto-cleanup
- Message pagination (50 at a time)

---

## Integration with Existing Features

### Video Sharing
Every video and short has a "Share to Chat" button:
1. Tap button
2. Shows recent chat list
3. Select recipient(s)
4. Auto-creates message with video preview card
5. Card has: thumbnail, title, "Open Video" button

### Notifications
- New message trigger creates notification
- Link opens chat and marks as read
- Notification includes message preview
- Muted chats don't create notifications

### Profiles
- Users see avatar + name in chat bubbles
- Tap on name/avatar → profile view
- Block button visible on profile

### Search
- "Recent chats" shown when opening chat tab
- Search bar finds users by name/username
- Quick start chat with any user

---

## Security

### Database Level
- Role-based access (only members see chat messages)
- Suspended users cannot send/receive
- Block list enforced on message send
- Delete is soft-delete (never hard-removed from DB)

### API Level
- Verify sender == current user
- Verify recipient not blocked
- Verify user is member of chat
- Rate limit: 100 messages/min per IP
- Input validation: text length, file size, MIME type

### Firebase Rules
- `isMember(chatId)` checks membership before allowing read/write
- Users can only delete their own messages
- Admins verified before chat updates
- Block list prevents message send
- Typing and presence are ephemeral

---

## Testing

### Send direct message
```bash
curl -X POST https://app/api/chat \
  -H "Content-Type: application/json" \
  -d '{"action":"send-direct","recipientId":2,"text":"Hi!"}'
# Returns: {"success":true,"chatId":1,"messageId":42}
```

### List chats
```bash
curl https://app/api/chat?mode=list&limit=5
# Returns: {"chats":[...]}
```

### Get messages
```bash
curl "https://app/api/chat?mode=messages&chatId=1&limit=20"
# Returns: {"messages":[...]}
```

### Share video to chat
```bash
curl -X POST https://app/api/chat \
  -d '{"action":"send-video-share","chatId":1,"videoId":42}'
```

---

## Future Enhancements

1. **Voice Messages** — Audio recording + playback
2. **Video Calls** — WebRTC integration for 1:1 and group calls
3. **Message Search** — Full-text search within chats
4. **Reactions** — Emoji reactions to messages
5. **Message Forwarding** — Share message to different chat
6. **Scheduled Messages** — Send message at specific time
7. **End-to-End Encryption** — E2EE for direct chats
8. **Message Threading** — Sub-threads on long conversations
9. **Sticker Packs** — Custom sticker upload/download
10. **Chat Backup** — Export chat history as PDF/JSON
